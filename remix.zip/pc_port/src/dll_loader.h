/* SPDX-License-Identifier: GPL-3.0-or-later */
/*
 * dll_loader.h — Thin OS abstraction for loading shared libraries.
 *
 * Deliberately includes NO game headers so it can safely include
 * <windows.h> / <dlfcn.h> without conflicting with PSX decomp types.
 */
#ifndef DLL_LOADER_H
#define DLL_LOADER_H

/* Opaque handle to a loaded shared library. */
typedef void* DllHandle;

/* Load a shared library. Returns NULL on failure. */
DllHandle DllLoader_Open(const char* path);

/* Look up a symbol by name. Returns NULL if not found. */
void* DllLoader_GetSymbol(DllHandle handle, const char* name);

/* Handle to the running executable itself, for looking up its own exported
 * globals (the exe is linked with --export-all-symbols / -rdynamic). */
DllHandle DllLoader_Self(void);

/* Unload a previously loaded library. Safe to call with NULL. */
void DllLoader_Close(DllHandle handle);

/* Return a human-readable error string for the last failure. */
/* Enumerate plugin DLLs (plugins folder) into paths (each 260 bytes). Windows-only; returns
 * 0 elsewhere and when the folder is absent. */
int DllLoader_ListPlugins(char paths[][260], int maxCount);

const char* DllLoader_GetError(void);

#endif /* DLL_LOADER_H */
