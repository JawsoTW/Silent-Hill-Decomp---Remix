using System;
using System.Windows.Forms;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    private PictureBox banner;
    private ComboBox comboFullscreen;
    private RadioButton radioVsyncYes;
    private RadioButton radioVsyncNo;
    private Button btnManager;
    private Button btnPlay;
    private Button btnUpdate;
    private Button btnChangelog;
    private Label  lblUpdateStatus;
    private ProgressBar progUpdate;

    private ComboBox comboResolution;
    private ComboBox comboSkipIntros;
    private RadioButton radioDecalsYes;
    private RadioButton radioDecalsNo;
    private Panel decalsPanel;
    private Label decalsLabel;
    private RadioButton radioPreloadYes;
    private RadioButton radioPreloadNo;
    private ComboBox comboPillarbox;

    private Label skipIntrosLabel;
    private Label fullscreenLabel;
    private Label vsyncLabel;
    private Label resolutionLabel;
    private Label refreshLabel;

    private Panel vsyncPanel;
    private Panel skipIntrosPanel;
    private Panel preloadPanel;
    private Panel pillarboxPanel;

    private Label fpsLabel;
    private ComboBox comboFps;

    private Label filteringLabel;
    private ComboBox comboFiltering;
    private ComboBox comboDithering;
    private Label ditheringLabel;
    private ComboBox comboScaling;
    private Label scalingLabel;

    private Label pgxpLabel;
    private Panel pgxpPanel;
    private RadioButton pgxpYes;
    private RadioButton pgxpNo;

    private Label loggingLabel;
    private Panel loggingPanel;
    private RadioButton loggingYes;
    private RadioButton loggingNo;

    private Label consoleLabel;
    private Panel consolePanel;
    private RadioButton consoleYes;
    private RadioButton consoleNo;
    private Label aaLabel;
    private ComboBox comboAA;
    private Label postLabel;
    private ComboBox comboPost;
    private Label toneLabel;
    private ComboBox comboTone;
    private Label flashLabel;
    private ComboBox comboFlash;
    private Label lblFog;
    private TrackBar trackFog;
    private Label lblFogValue;
    private Label lblLineGap;
    private ComboBox comboLineGap;
    private Label regionLabel;
    private ComboBox comboMap;
    private ComboBox comboDisc;
    private Label lblDisc;
    private Label audioLabel;
    private ComboBox comboAudioOut;



    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
            components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
            this.comboFullscreen = new System.Windows.Forms.ComboBox();
            this.vsyncPanel = new System.Windows.Forms.Panel();
            this.radioVsyncYes = new System.Windows.Forms.RadioButton();
            this.radioVsyncNo = new System.Windows.Forms.RadioButton();
            this.skipIntrosPanel = new System.Windows.Forms.Panel();
            this.comboSkipIntros = new System.Windows.Forms.ComboBox();
            this.decalsPanel = new System.Windows.Forms.Panel();
            this.radioDecalsYes = new System.Windows.Forms.RadioButton();
            this.radioDecalsNo = new System.Windows.Forms.RadioButton();
            this.decalsLabel = new System.Windows.Forms.Label();
            this.preloadPanel = new System.Windows.Forms.Panel();
            this.radioPreloadYes = new System.Windows.Forms.RadioButton();
            this.radioPreloadNo = new System.Windows.Forms.RadioButton();
            this.pillarboxPanel = new System.Windows.Forms.Panel();
            this.comboPillarbox = new System.Windows.Forms.ComboBox();
            this.btnManager = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnChangelog = new System.Windows.Forms.Button();
            this.lblUpdateStatus = new System.Windows.Forms.Label();
            this.progUpdate = new System.Windows.Forms.ProgressBar();
            this.comboResolution = new System.Windows.Forms.ComboBox();
            this.banner = new System.Windows.Forms.PictureBox();
            this.skipIntrosLabel = new System.Windows.Forms.Label();
            this.fullscreenLabel = new System.Windows.Forms.Label();
            this.vsyncLabel = new System.Windows.Forms.Label();
            this.resolutionLabel = new System.Windows.Forms.Label();
            this.refreshLabel = new System.Windows.Forms.Label();
            this.fpsLabel = new System.Windows.Forms.Label();
            this.chunksLabel = new System.Windows.Forms.Label();
            this.comboFps = new System.Windows.Forms.ComboBox();
            this.filteringLabel = new System.Windows.Forms.Label();
            this.comboFiltering = new System.Windows.Forms.ComboBox();
            this.comboDithering = new System.Windows.Forms.ComboBox();
            this.ditheringLabel = new System.Windows.Forms.Label();
            this.comboScaling = new System.Windows.Forms.ComboBox();
            this.scalingLabel = new System.Windows.Forms.Label();
            this.pgxpLabel = new System.Windows.Forms.Label();
            this.pgxpPanel = new System.Windows.Forms.Panel();
            this.pgxpYes = new System.Windows.Forms.RadioButton();
            this.pgxpNo = new System.Windows.Forms.RadioButton();
            this.loggingLabel = new System.Windows.Forms.Label();
            this.loggingPanel = new System.Windows.Forms.Panel();
            this.loggingYes = new System.Windows.Forms.RadioButton();
            this.loggingNo = new System.Windows.Forms.RadioButton();
            this.consoleLabel = new System.Windows.Forms.Label();
            this.consolePanel = new System.Windows.Forms.Panel();
            this.consoleYes = new System.Windows.Forms.RadioButton();
            this.consoleNo = new System.Windows.Forms.RadioButton();
            this.aaLabel = new System.Windows.Forms.Label();
            this.comboAA = new System.Windows.Forms.ComboBox();
            this.postLabel = new System.Windows.Forms.Label();
            this.comboPost = new System.Windows.Forms.ComboBox();
            this.toneLabel = new System.Windows.Forms.Label();
            this.comboTone = new System.Windows.Forms.ComboBox();
            this.flashLabel = new System.Windows.Forms.Label();
            this.comboFlash = new System.Windows.Forms.ComboBox();
            this.regionLabel = new System.Windows.Forms.Label();
            this.comboMap = new System.Windows.Forms.ComboBox();
            this.comboDisc = new System.Windows.Forms.ComboBox();
            this.lblDisc = new System.Windows.Forms.Label();
            this.audioLabel = new System.Windows.Forms.Label();
            this.comboAudioOut = new System.Windows.Forms.ComboBox();
            this.btnControls = new System.Windows.Forms.Button();
            this.btnBuildSettings = new System.Windows.Forms.Button();
            this.downloadBuild = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.btnBug = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.comboRefresh = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.chkUncensored = new System.Windows.Forms.CheckBox();
            this.lblUncensored = new System.Windows.Forms.Label();
            this.lblMenuType = new System.Windows.Forms.Label();
            this.comboMenuType = new System.Windows.Forms.ComboBox();
            this.lblGameLang = new System.Windows.Forms.Label();
            this.comboGameLang = new System.Windows.Forms.ComboBox();
            this.lblMenu = new System.Windows.Forms.Label();
            this.btnRA = new System.Windows.Forms.Button();
            this.comboRender = new System.Windows.Forms.ComboBox();
            this.lblRender = new System.Windows.Forms.Label();
            this.lblShadow = new System.Windows.Forms.Label();
            this.comboShadow = new System.Windows.Forms.ComboBox();
            this.lblFog = new System.Windows.Forms.Label();
            this.trackFog = new System.Windows.Forms.TrackBar();
            this.lblFogValue = new System.Windows.Forms.Label();
            this.lblLineGap = new System.Windows.Forms.Label();
            this.comboLineGap = new System.Windows.Forms.ComboBox();
            this.lblMinimap = new System.Windows.Forms.Label();
            this.comboMinimap = new System.Windows.Forms.ComboBox();
            this.vsyncPanel.SuspendLayout();
            this.skipIntrosPanel.SuspendLayout();
            this.decalsPanel.SuspendLayout();
            this.preloadPanel.SuspendLayout();
            this.pillarboxPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.banner)).BeginInit();
            this.pgxpPanel.SuspendLayout();
            this.loggingPanel.SuspendLayout();
            this.consolePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackFog)).BeginInit();
            this.SuspendLayout();
            // 
            // comboFullscreen
            // 
            this.comboFullscreen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFullscreen.Items.AddRange(new object[] {
            "Fullscreen",
            "Windowed",
            "Borderless"});
            this.comboFullscreen.Location = new System.Drawing.Point(94, 117);
            this.comboFullscreen.Name = "comboFullscreen";
            this.comboFullscreen.Size = new System.Drawing.Size(135, 21);
            this.comboFullscreen.TabIndex = 16;
            // 
            // vsyncPanel
            // 
            this.vsyncPanel.Controls.Add(this.radioVsyncYes);
            this.vsyncPanel.Controls.Add(this.radioVsyncNo);
            this.vsyncPanel.Location = new System.Drawing.Point(94, 224);
            this.vsyncPanel.Name = "vsyncPanel";
            this.vsyncPanel.Size = new System.Drawing.Size(135, 30);
            this.vsyncPanel.TabIndex = 17;
            // 
            // radioVsyncYes
            // 
            this.radioVsyncYes.Location = new System.Drawing.Point(5, 5);
            this.radioVsyncYes.Name = "radioVsyncYes";
            this.radioVsyncYes.Size = new System.Drawing.Size(51, 24);
            this.radioVsyncYes.TabIndex = 9;
            this.radioVsyncYes.Text = "Yes";
            // 
            // radioVsyncNo
            // 
            this.radioVsyncNo.Location = new System.Drawing.Point(60, 5);
            this.radioVsyncNo.Name = "radioVsyncNo";
            this.radioVsyncNo.Size = new System.Drawing.Size(47, 24);
            this.radioVsyncNo.TabIndex = 10;
            this.radioVsyncNo.Text = "No";
            // 
            // skipIntrosPanel
            // 
            this.skipIntrosPanel.Controls.Add(this.comboSkipIntros);
            this.skipIntrosPanel.Location = new System.Drawing.Point(309, 139);
            this.skipIntrosPanel.Name = "skipIntrosPanel";
            this.skipIntrosPanel.Size = new System.Drawing.Size(152, 30);
            this.skipIntrosPanel.TabIndex = 18;
            // 
            // comboSkipIntros
            // 
            this.comboSkipIntros.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboSkipIntros.Items.AddRange(new object[] {
            "Don\'t Skip",
            "Skip to Menu",
            "Skip to Game"});
            this.comboSkipIntros.Location = new System.Drawing.Point(1, 6);
            this.comboSkipIntros.Name = "comboSkipIntros";
            this.comboSkipIntros.Size = new System.Drawing.Size(138, 21);
            this.comboSkipIntros.TabIndex = 2;
            // 
            // decalsPanel
            // 
            this.decalsPanel.Controls.Add(this.radioDecalsYes);
            this.decalsPanel.Controls.Add(this.radioDecalsNo);
            this.decalsPanel.Location = new System.Drawing.Point(331, 196);
            this.decalsPanel.Name = "decalsPanel";
            this.decalsPanel.Size = new System.Drawing.Size(100, 30);
            this.decalsPanel.TabIndex = 94;
            // 
            // radioDecalsYes
            // 
            this.radioDecalsYes.AutoSize = true;
            this.radioDecalsYes.Location = new System.Drawing.Point(4, 5);
            this.radioDecalsYes.Name = "radioDecalsYes";
            this.radioDecalsYes.Size = new System.Drawing.Size(43, 17);
            this.radioDecalsYes.TabIndex = 0;
            this.radioDecalsYes.Text = "Yes";
            this.radioDecalsYes.UseVisualStyleBackColor = true;
            // 
            // radioDecalsNo
            // 
            this.radioDecalsNo.AutoSize = true;
            this.radioDecalsNo.Location = new System.Drawing.Point(59, 5);
            this.radioDecalsNo.Name = "radioDecalsNo";
            this.radioDecalsNo.Size = new System.Drawing.Size(39, 17);
            this.radioDecalsNo.TabIndex = 1;
            this.radioDecalsNo.Text = "No";
            this.radioDecalsNo.UseVisualStyleBackColor = true;
            // 
            // decalsLabel
            // 
            this.decalsLabel.AutoSize = true;
            this.decalsLabel.Location = new System.Drawing.Point(235, 205);
            this.decalsLabel.Name = "decalsLabel";
            this.decalsLabel.Size = new System.Drawing.Size(72, 13);
            this.decalsLabel.TabIndex = 95;
            this.decalsLabel.Text = "Bullet Decals:";
            // 
            // preloadPanel
            // 
            this.preloadPanel.Controls.Add(this.radioPreloadYes);
            this.preloadPanel.Controls.Add(this.radioPreloadNo);
            this.preloadPanel.Location = new System.Drawing.Point(331, 223);
            this.preloadPanel.Name = "preloadPanel";
            this.preloadPanel.Size = new System.Drawing.Size(100, 30);
            this.preloadPanel.TabIndex = 20;
            this.preloadPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.preloadPanel_Paint);
            // 
            // radioPreloadYes
            // 
            this.radioPreloadYes.Location = new System.Drawing.Point(4, 6);
            this.radioPreloadYes.Name = "radioPreloadYes";
            this.radioPreloadYes.Size = new System.Drawing.Size(45, 24);
            this.radioPreloadYes.TabIndex = 4;
            this.radioPreloadYes.Text = "Yes";
            this.radioPreloadYes.CheckedChanged += new System.EventHandler(this.radioPreloadYes_CheckedChanged);
            // 
            // radioPreloadNo
            // 
            this.radioPreloadNo.Location = new System.Drawing.Point(59, 6);
            this.radioPreloadNo.Name = "radioPreloadNo";
            this.radioPreloadNo.Size = new System.Drawing.Size(53, 24);
            this.radioPreloadNo.TabIndex = 5;
            this.radioPreloadNo.Text = "No";
            // 
            // pillarboxPanel
            // 
            this.pillarboxPanel.Controls.Add(this.comboPillarbox);
            this.pillarboxPanel.Location = new System.Drawing.Point(94, 254);
            this.pillarboxPanel.Name = "pillarboxPanel";
            this.pillarboxPanel.Size = new System.Drawing.Size(135, 30);
            this.pillarboxPanel.TabIndex = 21;
            this.pillarboxPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.pillarboxPanel_Paint);
            // 
            // comboPillarbox
            // 
            this.comboPillarbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPillarbox.Items.AddRange(new object[] {
            "Yes",
            "No",
            "Menus Only"});
            this.comboPillarbox.Location = new System.Drawing.Point(0, 4);
            this.comboPillarbox.Name = "comboPillarbox";
            this.comboPillarbox.Size = new System.Drawing.Size(135, 21);
            this.comboPillarbox.TabIndex = 4;
            // 
            // btnManager
            // 
            this.btnManager.BackgroundImage = global::SilentHillPC_Launcher.Properties.Resources.manager;
            this.btnManager.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManager.FlatAppearance.BorderSize = 0;
            this.btnManager.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManager.Location = new System.Drawing.Point(246, 376);
            this.btnManager.Name = "btnManager";
            this.btnManager.Size = new System.Drawing.Size(203, 49);
            this.btnManager.TabIndex = 11;
            this.btnManager.UseVisualStyleBackColor = true;
            this.btnManager.Click += new System.EventHandler(this.btnManager_Click);
            this.btnManager.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnManager_MouseDown);
            this.btnManager.MouseLeave += new System.EventHandler(this.btnManager_MouseLeave);
            this.btnManager.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnManager_MouseUp);
            // 
            // btnPlay
            // 
            this.btnPlay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlay.Location = new System.Drawing.Point(352, 491);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(97, 23);
            this.btnPlay.TabIndex = 12;
            this.btnPlay.Text = "Play!";
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(244, 434);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(104, 23);
            this.btnUpdate.TabIndex = 13;
            this.btnUpdate.Text = "Check for Updates";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnChangelog
            // 
            this.btnChangelog.Location = new System.Drawing.Point(244, 463);
            this.btnChangelog.Name = "btnChangelog";
            this.btnChangelog.Size = new System.Drawing.Size(104, 23);
            this.btnChangelog.TabIndex = 16;
            this.btnChangelog.Text = "Changelog";
            this.btnChangelog.UseVisualStyleBackColor = true;
            this.btnChangelog.Click += new System.EventHandler(this.btnChangelog_Click);
            // 
            // lblUpdateStatus
            // 
            this.lblUpdateStatus.Location = new System.Drawing.Point(209, 619);
            this.lblUpdateStatus.Name = "lblUpdateStatus";
            this.lblUpdateStatus.Size = new System.Drawing.Size(207, 15);
            this.lblUpdateStatus.TabIndex = 14;
            // 
            // progUpdate
            // 
            this.progUpdate.Location = new System.Drawing.Point(238, 585);
            this.progUpdate.Name = "progUpdate";
            this.progUpdate.Size = new System.Drawing.Size(205, 23);
            this.progUpdate.TabIndex = 15;
            this.progUpdate.Visible = false;
            this.progUpdate.Click += new System.EventHandler(this.progUpdate_Click);
            // 
            // comboResolution
            // 
            this.comboResolution.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboResolution.Location = new System.Drawing.Point(94, 144);
            this.comboResolution.Name = "comboResolution";
            this.comboResolution.Size = new System.Drawing.Size(135, 21);
            this.comboResolution.TabIndex = 0;
            this.comboResolution.SelectedIndexChanged += new System.EventHandler(this.comboResolution_SelectedIndexChanged);
            // 
            // banner
            // 
            this.banner.BackColor = System.Drawing.Color.DarkSlateGray;
            this.banner.Cursor = System.Windows.Forms.Cursors.Hand;
            this.banner.Dock = System.Windows.Forms.DockStyle.Top;
            this.banner.Image = global::SilentHillPC_Launcher.Properties.Resources.launcher;
            this.banner.Location = new System.Drawing.Point(0, 0);
            this.banner.Name = "banner";
            this.banner.Size = new System.Drawing.Size(454, 111);
            this.banner.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.banner.TabIndex = 6;
            this.banner.TabStop = false;
            this.banner.Click += new System.EventHandler(this.banner_Click);
            // 
            // skipIntrosLabel
            // 
            this.skipIntrosLabel.AutoSize = true;
            this.skipIntrosLabel.Location = new System.Drawing.Point(235, 149);
            this.skipIntrosLabel.Name = "skipIntrosLabel";
            this.skipIntrosLabel.Size = new System.Drawing.Size(60, 13);
            this.skipIntrosLabel.TabIndex = 0;
            this.skipIntrosLabel.Text = "Skip Intros:";
            // 
            // fullscreenLabel
            // 
            this.fullscreenLabel.AutoSize = true;
            this.fullscreenLabel.Location = new System.Drawing.Point(6, 119);
            this.fullscreenLabel.Name = "fullscreenLabel";
            this.fullscreenLabel.Size = new System.Drawing.Size(44, 13);
            this.fullscreenLabel.TabIndex = 2;
            this.fullscreenLabel.Text = "Display:";
            // 
            // vsyncLabel
            // 
            this.vsyncLabel.AutoSize = true;
            this.vsyncLabel.Location = new System.Drawing.Point(8, 232);
            this.vsyncLabel.Name = "vsyncLabel";
            this.vsyncLabel.Size = new System.Drawing.Size(41, 13);
            this.vsyncLabel.TabIndex = 3;
            this.vsyncLabel.Text = "VSync:";
            // 
            // resolutionLabel
            // 
            this.resolutionLabel.AutoSize = true;
            this.resolutionLabel.Location = new System.Drawing.Point(6, 148);
            this.resolutionLabel.Name = "resolutionLabel";
            this.resolutionLabel.Size = new System.Drawing.Size(60, 13);
            this.resolutionLabel.TabIndex = 13;
            this.resolutionLabel.Text = "Resolution:";
            // 
            // refreshLabel
            // 
            this.refreshLabel.AutoSize = true;
            this.refreshLabel.Location = new System.Drawing.Point(7, 262);
            this.refreshLabel.Name = "refreshLabel";
            this.refreshLabel.Size = new System.Drawing.Size(63, 13);
            this.refreshLabel.TabIndex = 14;
            this.refreshLabel.Text = "Pillarboxing:";
            // 
            // fpsLabel
            // 
            this.fpsLabel.AutoSize = true;
            this.fpsLabel.Location = new System.Drawing.Point(235, 291);
            this.fpsLabel.Name = "fpsLabel";
            this.fpsLabel.Size = new System.Drawing.Size(54, 13);
            this.fpsLabel.TabIndex = 30;
            this.fpsLabel.Text = "FPS Limit:";
            // 
            // chunksLabel
            // 
            this.chunksLabel.AutoSize = true;
            this.chunksLabel.Location = new System.Drawing.Point(235, 234);
            this.chunksLabel.Name = "chunksLabel";
            this.chunksLabel.Size = new System.Drawing.Size(85, 13);
            this.chunksLabel.TabIndex = 1;
            this.chunksLabel.Text = "Preload Chunks:";
            // 
            // comboFps
            // 
            this.comboFps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFps.Items.AddRange(new object[] {
            "0",
            "30",
            "60",
            "120",
            "240"});
            this.comboFps.Location = new System.Drawing.Point(311, 287);
            this.comboFps.Name = "comboFps";
            this.comboFps.Size = new System.Drawing.Size(138, 21);
            this.comboFps.TabIndex = 31;
            // 
            // filteringLabel
            // 
            this.filteringLabel.AutoSize = true;
            this.filteringLabel.Location = new System.Drawing.Point(8, 293);
            this.filteringLabel.Name = "filteringLabel";
            this.filteringLabel.Size = new System.Drawing.Size(46, 13);
            this.filteringLabel.TabIndex = 40;
            this.filteringLabel.Text = "Filtering:";
            // 
            // comboFiltering
            // 
            this.comboFiltering.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFiltering.Items.AddRange(new object[] {
            "Off",
            "Bilinear",
            "Trilinear",
            "Anisotropic 2x",
            "Anisotropic 4x",
            "Anisotropic 8x",
            "Anisotropic 16x"});
            this.comboFiltering.Location = new System.Drawing.Point(94, 288);
            this.comboFiltering.Name = "comboFiltering";
            this.comboFiltering.Size = new System.Drawing.Size(96, 21);
            this.comboFiltering.TabIndex = 41;
            // 
            // comboDithering
            // 
            this.comboDithering.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboDithering.Items.AddRange(new object[] {
            "Off",
            "On"});
            this.comboDithering.Location = new System.Drawing.Point(310, 172);
            this.comboDithering.Name = "comboDithering";
            this.comboDithering.Size = new System.Drawing.Size(138, 21);
            this.comboDithering.TabIndex = 123;
            // 
            // ditheringLabel
            // 
            this.ditheringLabel.AutoSize = true;
            this.ditheringLabel.Location = new System.Drawing.Point(235, 176);
            this.ditheringLabel.Name = "ditheringLabel";
            this.ditheringLabel.Size = new System.Drawing.Size(52, 13);
            this.ditheringLabel.TabIndex = 122;
            this.ditheringLabel.Text = "Dithering:";
            // 
            // comboScaling
            // 
            this.comboScaling.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboScaling.Items.AddRange(new object[] {
            "Integer",
            "Nearest Neighbor",
            "Bilinear",
            "Sharp Bilinear"});
            this.comboScaling.Location = new System.Drawing.Point(94, 172);
            this.comboScaling.Name = "comboScaling";
            this.comboScaling.Size = new System.Drawing.Size(135, 21);
            this.comboScaling.TabIndex = 121;
            // 
            // scalingLabel
            // 
            this.scalingLabel.AutoSize = true;
            this.scalingLabel.Location = new System.Drawing.Point(6, 176);
            this.scalingLabel.Name = "scalingLabel";
            this.scalingLabel.Size = new System.Drawing.Size(45, 13);
            this.scalingLabel.TabIndex = 120;
            this.scalingLabel.Text = "Scaling:";
            // 
            // pgxpLabel
            // 
            this.pgxpLabel.AutoSize = true;
            this.pgxpLabel.Location = new System.Drawing.Point(8, 322);
            this.pgxpLabel.Name = "pgxpLabel";
            this.pgxpLabel.Size = new System.Drawing.Size(61, 13);
            this.pgxpLabel.TabIndex = 46;
            this.pgxpLabel.Text = "Use PGXP:";
            // 
            // pgxpPanel
            // 
            this.pgxpPanel.Controls.Add(this.pgxpYes);
            this.pgxpPanel.Controls.Add(this.pgxpNo);
            this.pgxpPanel.Location = new System.Drawing.Point(94, 314);
            this.pgxpPanel.Name = "pgxpPanel";
            this.pgxpPanel.Size = new System.Drawing.Size(135, 30);
            this.pgxpPanel.TabIndex = 49;
            // 
            // pgxpYes
            // 
            this.pgxpYes.Location = new System.Drawing.Point(5, 5);
            this.pgxpYes.Name = "pgxpYes";
            this.pgxpYes.Size = new System.Drawing.Size(49, 24);
            this.pgxpYes.TabIndex = 47;
            this.pgxpYes.Text = "Yes";
            this.pgxpYes.CheckedChanged += new System.EventHandler(this.pgxpYes_CheckedChanged);
            // 
            // pgxpNo
            // 
            this.pgxpNo.Location = new System.Drawing.Point(59, 5);
            this.pgxpNo.Name = "pgxpNo";
            this.pgxpNo.Size = new System.Drawing.Size(45, 24);
            this.pgxpNo.TabIndex = 48;
            this.pgxpNo.Text = "No";
            // 
            // loggingLabel
            // 
            this.loggingLabel.AutoSize = true;
            this.loggingLabel.Location = new System.Drawing.Point(235, 262);
            this.loggingLabel.Name = "loggingLabel";
            this.loggingLabel.Size = new System.Drawing.Size(84, 13);
            this.loggingLabel.TabIndex = 32;
            this.loggingLabel.Text = "Enable Logging:";
            // 
            // loggingPanel
            // 
            this.loggingPanel.Controls.Add(this.loggingYes);
            this.loggingPanel.Controls.Add(this.loggingNo);
            this.loggingPanel.Location = new System.Drawing.Point(331, 253);
            this.loggingPanel.Name = "loggingPanel";
            this.loggingPanel.Size = new System.Drawing.Size(100, 30);
            this.loggingPanel.TabIndex = 35;
            // 
            // loggingYes
            // 
            this.loggingYes.Location = new System.Drawing.Point(4, 6);
            this.loggingYes.Name = "loggingYes";
            this.loggingYes.Size = new System.Drawing.Size(49, 24);
            this.loggingYes.TabIndex = 33;
            this.loggingYes.Text = "Yes";
            // 
            // loggingNo
            // 
            this.loggingNo.Location = new System.Drawing.Point(59, 6);
            this.loggingNo.Name = "loggingNo";
            this.loggingNo.Size = new System.Drawing.Size(45, 24);
            this.loggingNo.TabIndex = 34;
            this.loggingNo.Text = "No";
            // 
            // consoleLabel
            // 
            this.consoleLabel.AutoSize = true;
            this.consoleLabel.Location = new System.Drawing.Point(210, 643);
            this.consoleLabel.Name = "consoleLabel";
            this.consoleLabel.Size = new System.Drawing.Size(89, 13);
            this.consoleLabel.TabIndex = 36;
            this.consoleLabel.Text = "External Console:";
            this.consoleLabel.Click += new System.EventHandler(this.consoleLabel_Click);
            // 
            // consolePanel
            // 
            this.consolePanel.Controls.Add(this.consoleYes);
            this.consolePanel.Controls.Add(this.consoleNo);
            this.consolePanel.Location = new System.Drawing.Point(296, 640);
            this.consolePanel.Name = "consolePanel";
            this.consolePanel.Size = new System.Drawing.Size(120, 33);
            this.consolePanel.TabIndex = 56;
            // 
            // consoleYes
            // 
            this.consoleYes.Location = new System.Drawing.Point(7, 5);
            this.consoleYes.Name = "consoleYes";
            this.consoleYes.Size = new System.Drawing.Size(49, 24);
            this.consoleYes.TabIndex = 0;
            this.consoleYes.Text = "Yes";
            // 
            // consoleNo
            // 
            this.consoleNo.Location = new System.Drawing.Point(61, 5);
            this.consoleNo.Name = "consoleNo";
            this.consoleNo.Size = new System.Drawing.Size(45, 24);
            this.consoleNo.TabIndex = 1;
            this.consoleNo.Text = "No";
            // 
            // aaLabel
            // 
            this.aaLabel.AutoSize = true;
            this.aaLabel.Location = new System.Drawing.Point(9, 354);
            this.aaLabel.Name = "aaLabel";
            this.aaLabel.Size = new System.Drawing.Size(63, 13);
            this.aaLabel.TabIndex = 57;
            this.aaLabel.Text = "Antialiasing:";
            // 
            // comboAA
            // 
            this.comboAA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboAA.Items.AddRange(new object[] {
            "Off",
            "2x",
            "4x",
            "8x"});
            this.comboAA.Location = new System.Drawing.Point(94, 350);
            this.comboAA.Name = "comboAA";
            this.comboAA.Size = new System.Drawing.Size(135, 21);
            this.comboAA.TabIndex = 58;
            // 
            // postLabel
            // 
            this.postLabel.AutoSize = true;
            this.postLabel.Location = new System.Drawing.Point(9, 384);
            this.postLabel.Name = "postLabel";
            this.postLabel.Size = new System.Drawing.Size(62, 13);
            this.postLabel.TabIndex = 59;
            this.postLabel.Text = "Post Effect:";
            // 
            // comboPost
            // 
            this.comboPost.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboPost.Items.AddRange(new object[] {
            "Off",
            "CRT",
            "Scanlines",
            "Vignette",
            "Color Grade",
            "Film Grain",
            "Sharpen",
            "PSX Retro",
            "Cinematic"});
            this.comboPost.Location = new System.Drawing.Point(94, 380);
            this.comboPost.Name = "comboPost";
            this.comboPost.Size = new System.Drawing.Size(135, 21);
            this.comboPost.TabIndex = 59;
            // 
            // toneLabel
            // 
            this.toneLabel.AutoSize = true;
            this.toneLabel.Location = new System.Drawing.Point(8, 414);
            this.toneLabel.Name = "toneLabel";
            this.toneLabel.Size = new System.Drawing.Size(59, 13);
            this.toneLabel.TabIndex = 60;
            this.toneLabel.Text = "Tone Map:";
            // 
            // comboTone
            // 
            this.comboTone.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboTone.Items.AddRange(new object[] {
            "Off",
            "Reinhard",
            "ACES",
            "Filmic"});
            this.comboTone.Location = new System.Drawing.Point(94, 410);
            this.comboTone.Name = "comboTone";
            this.comboTone.Size = new System.Drawing.Size(135, 21);
            this.comboTone.TabIndex = 60;
            // 
            // flashLabel
            // 
            this.flashLabel.AutoSize = true;
            this.flashLabel.Location = new System.Drawing.Point(9, 444);
            this.flashLabel.Name = "flashLabel";
            this.flashLabel.Size = new System.Drawing.Size(54, 13);
            this.flashLabel.TabIndex = 61;
            this.flashLabel.Text = "Flashlight:";
            // 
            // comboFlash
            // 
            this.comboFlash.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboFlash.Items.AddRange(new object[] {
            "Classic",
            "Classic + Shadows",
            "Modern",
            "Modern + Shadows"});
            this.comboFlash.Location = new System.Drawing.Point(94, 440);
            this.comboFlash.Name = "comboFlash";
            this.comboFlash.Size = new System.Drawing.Size(135, 21);
            this.comboFlash.TabIndex = 61;
            // 
            // regionLabel
            // 
            this.regionLabel.AutoSize = true;
            this.regionLabel.Location = new System.Drawing.Point(9, 501);
            this.regionLabel.Name = "regionLabel";
            this.regionLabel.Size = new System.Drawing.Size(63, 13);
            this.regionLabel.TabIndex = 62;
            this.regionLabel.Text = "Disk Image:";
            this.regionLabel.Click += new System.EventHandler(this.regionLabel_Click);
            // 
            // comboMap
            // 
            this.comboMap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboMap.DropDownWidth = 400;
            this.comboMap.Location = new System.Drawing.Point(51, 585);
            this.comboMap.Name = "comboMap";
            this.comboMap.Size = new System.Drawing.Size(178, 21);
            this.comboMap.TabIndex = 63;
            // 
            // comboDisc
            // 
            this.comboDisc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboDisc.DropDownWidth = 320;
            this.comboDisc.Location = new System.Drawing.Point(94, 498);
            this.comboDisc.Name = "comboDisc";
            this.comboDisc.Size = new System.Drawing.Size(135, 21);
            this.comboDisc.TabIndex = 64;
            this.comboDisc.SelectedIndexChanged += new System.EventHandler(this.comboDisc_SelectedIndexChanged);
            // 
            // lblDisc
            // 
            this.lblDisc.AutoEllipsis = true;
            this.lblDisc.Location = new System.Drawing.Point(11, 555);
            this.lblDisc.Name = "lblDisc";
            this.lblDisc.Size = new System.Drawing.Size(193, 18);
            this.lblDisc.TabIndex = 65;
            // 
            // audioLabel
            // 
            this.audioLabel.AutoSize = true;
            this.audioLabel.Location = new System.Drawing.Point(236, 351);
            this.audioLabel.Name = "audioLabel";
            this.audioLabel.Size = new System.Drawing.Size(57, 13);
            this.audioLabel.TabIndex = 67;
            this.audioLabel.Text = "Audio Out:";
            // 
            // comboAudioOut
            // 
            this.comboAudioOut.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboAudioOut.DropDownWidth = 150;
            this.comboAudioOut.Items.AddRange(new object[] {
            "Auto",
            "Stereo",
            "Quad",
            "5.1 Surround",
            "7.1 Surround",
            "HRTF (Headphones)"});
            this.comboAudioOut.Location = new System.Drawing.Point(311, 347);
            this.comboAudioOut.Name = "comboAudioOut";
            this.comboAudioOut.Size = new System.Drawing.Size(138, 21);
            this.comboAudioOut.TabIndex = 68;
            // 
            // btnControls
            // 
            this.btnControls.Location = new System.Drawing.Point(353, 434);
            this.btnControls.Name = "btnControls";
            this.btnControls.Size = new System.Drawing.Size(97, 23);
            this.btnControls.TabIndex = 50;
            this.btnControls.Text = "Controls";
            this.btnControls.UseVisualStyleBackColor = true;
            this.btnControls.Click += new System.EventHandler(this.btnControls_Click);
            // 
            // btnBuildSettings
            // 
            this.btnBuildSettings.Location = new System.Drawing.Point(352, 463);
            this.btnBuildSettings.Name = "btnBuildSettings";
            this.btnBuildSettings.Size = new System.Drawing.Size(98, 23);
            this.btnBuildSettings.TabIndex = 51;
            this.btnBuildSettings.Text = "Build Settings";
            this.btnBuildSettings.UseVisualStyleBackColor = true;
            this.btnBuildSettings.Click += new System.EventHandler(this.btnBuildSettings_Click);
            // 
            // downloadBuild
            // 
            this.downloadBuild.Location = new System.Drawing.Point(243, 491);
            this.downloadBuild.Name = "downloadBuild";
            this.downloadBuild.Size = new System.Drawing.Size(104, 23);
            this.downloadBuild.TabIndex = 52;
            this.downloadBuild.Text = "Download Build";
            this.downloadBuild.UseVisualStyleBackColor = true;
            this.downloadBuild.Click += new System.EventHandler(this.downloadBuild_Click);
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(4, 617);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(39, 23);
            this.btnHelp.TabIndex = 53;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBug
            // 
            this.btnBug.Location = new System.Drawing.Point(98, 617);
            this.btnBug.Name = "btnBug";
            this.btnBug.Size = new System.Drawing.Size(70, 23);
            this.btnBug.TabIndex = 54;
            this.btnBug.Text = "Report Bug";
            this.btnBug.UseVisualStyleBackColor = true;
            this.btnBug.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(44, 617);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(53, 23);
            this.btnReset.TabIndex = 55;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboRefresh
            // 
            this.comboRefresh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboRefresh.Location = new System.Drawing.Point(296, 379);
            this.comboRefresh.Name = "comboRefresh";
            this.comboRefresh.Size = new System.Drawing.Size(120, 21);
            this.comboRefresh.TabIndex = 1;
            this.comboRefresh.Visible = false;
            this.comboRefresh.SelectedIndexChanged += new System.EventHandler(this.comboRefresh_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 589);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 66;
            this.label1.Text = "Level:";
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(217, 291);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(18, 17);
            this.checkBox1.TabIndex = 69;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chkUncensored
            // 
            this.chkUncensored.Location = new System.Drawing.Point(26, 528);
            this.chkUncensored.Name = "chkUncensored";
            this.chkUncensored.Size = new System.Drawing.Size(16, 17);
            this.chkUncensored.TabIndex = 91;
            this.chkUncensored.UseVisualStyleBackColor = true;
            this.chkUncensored.CheckedChanged += new System.EventHandler(this.chkUncensored_CheckedChanged);
            // 
            // lblUncensored
            // 
            this.lblUncensored.AutoSize = true;
            this.lblUncensored.Location = new System.Drawing.Point(7, 529);
            this.lblUncensored.Name = "lblUncensored";
            this.lblUncensored.Size = new System.Drawing.Size(19, 13);
            this.lblUncensored.TabIndex = 90;
            this.lblUncensored.Text = "🚫";
            this.lblUncensored.Click += new System.EventHandler(this.lblUncensored_Click);
            // 
            // lblMenuType
            // 
            this.lblMenuType.AutoSize = true;
            this.lblMenuType.Location = new System.Drawing.Point(62, 529);
            this.lblMenuType.Name = "lblMenuType";
            this.lblMenuType.Size = new System.Drawing.Size(64, 13);
            this.lblMenuType.TabIndex = 93;
            this.lblMenuType.Text = "Menu Type:";
            // 
            // comboMenuType
            // 
            this.comboMenuType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboMenuType.Items.AddRange(new object[] {
            "Auto",
            "US",
            "EU",
            "JP"});
            this.comboMenuType.Location = new System.Drawing.Point(152, 525);
            this.comboMenuType.Name = "comboMenuType";
            this.comboMenuType.Size = new System.Drawing.Size(77, 21);
            this.comboMenuType.TabIndex = 94;
            // 
            // lblGameLang
            // 
            this.lblGameLang.AutoSize = true;
            this.lblGameLang.Location = new System.Drawing.Point(235, 528);
            this.lblGameLang.Name = "lblGameLang";
            this.lblGameLang.Size = new System.Drawing.Size(89, 13);
            this.lblGameLang.TabIndex = 95;
            this.lblGameLang.Text = "Game Language:";
            // 
            // comboGameLang
            // 
            this.comboGameLang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboGameLang.Location = new System.Drawing.Point(330, 525);
            this.comboGameLang.Name = "comboGameLang";
            this.comboGameLang.Size = new System.Drawing.Size(118, 21);
            this.comboGameLang.TabIndex = 96;
            // 
            // lblMenu
            // 
            this.lblMenu.AutoSize = true;
            this.lblMenu.Location = new System.Drawing.Point(196, 293);
            this.lblMenu.Name = "lblMenu";
            this.lblMenu.Size = new System.Drawing.Size(21, 13);
            this.lblMenu.TabIndex = 70;
            this.lblMenu.Text = "UI:";
            // 
            // btnRA
            // 
            this.btnRA.Location = new System.Drawing.Point(170, 617);
            this.btnRA.Name = "btnRA";
            this.btnRA.Size = new System.Drawing.Size(30, 23);
            this.btnRA.TabIndex = 92;
            this.btnRA.Text = "RA";
            this.btnRA.UseVisualStyleBackColor = true;
            this.btnRA.Click += new System.EventHandler(this.btnRA_Click);
            // 
            // comboRender
            // 
            this.comboRender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboRender.Location = new System.Drawing.Point(94, 200);
            this.comboRender.Name = "comboRender";
            this.comboRender.Size = new System.Drawing.Size(135, 21);
            this.comboRender.TabIndex = 93;
            // 
            // lblRender
            // 
            this.lblRender.AutoSize = true;
            this.lblRender.Location = new System.Drawing.Point(6, 204);
            this.lblRender.Name = "lblRender";
            this.lblRender.Size = new System.Drawing.Size(54, 13);
            this.lblRender.TabIndex = 94;
            this.lblRender.Text = "Renderer:";
            this.lblRender.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblShadow
            // 
            this.lblShadow.AutoSize = true;
            this.lblShadow.Location = new System.Drawing.Point(9, 473);
            this.lblShadow.Name = "lblShadow";
            this.lblShadow.Size = new System.Drawing.Size(71, 13);
            this.lblShadow.TabIndex = 96;
            this.lblShadow.Text = "Shadow Res:";
            // 
            // comboShadow
            // 
            this.comboShadow.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboShadow.Items.AddRange(new object[] {
            "Classic",
            "Classic + Shadows",
            "Modern",
            "Modern + Shadows"});
            this.comboShadow.Location = new System.Drawing.Point(94, 469);
            this.comboShadow.Name = "comboShadow";
            this.comboShadow.Size = new System.Drawing.Size(135, 21);
            this.comboShadow.TabIndex = 97;
            // 
            // lblFog
            // 
            this.lblFog.AutoSize = true;
            this.lblFog.Location = new System.Drawing.Point(236, 555);
            this.lblFog.Name = "lblFog";
            this.lblFog.Size = new System.Drawing.Size(100, 13);
            this.lblFog.TabIndex = 100;
            this.lblFog.Text = "Fog/World Visibility:";
            // 
            // trackFog
            // 
            this.trackFog.AutoSize = false;
            this.trackFog.LargeChange = 2;
            this.trackFog.Location = new System.Drawing.Point(369, 554);
            this.trackFog.Maximum = 24;
            this.trackFog.Name = "trackFog";
            this.trackFog.Size = new System.Drawing.Size(80, 24);
            this.trackFog.TabIndex = 101;
            this.trackFog.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackFog.Value = 22;
            // 
            // lblFogValue
            // 
            this.lblFogValue.Location = new System.Drawing.Point(338, 555);
            this.lblFogValue.Name = "lblFogValue";
            this.lblFogValue.Size = new System.Drawing.Size(32, 13);
            this.lblFogValue.TabIndex = 102;
            this.lblFogValue.Text = "1.10";
            this.lblFogValue.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblLineGap
            // 
            this.lblLineGap.AutoSize = true;
            this.lblLineGap.Location = new System.Drawing.Point(236, 321);
            this.lblLineGap.Name = "lblLineGap";
            this.lblLineGap.Size = new System.Drawing.Size(73, 13);
            this.lblLineGap.TabIndex = 103;
            this.lblLineGap.Text = "Dialog Pause:";
            // 
            // comboLineGap
            // 
            this.comboLineGap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboLineGap.Items.AddRange(new object[] {
            "Off",
            "Short",
            "Normal",
            "Long"});
            this.comboLineGap.Location = new System.Drawing.Point(311, 317);
            this.comboLineGap.Name = "comboLineGap";
            this.comboLineGap.Size = new System.Drawing.Size(138, 21);
            this.comboLineGap.TabIndex = 104;
            // 
            // lblMinimap
            // 
            this.lblMinimap.AutoSize = true;
            this.lblMinimap.Location = new System.Drawing.Point(236, 120);
            this.lblMinimap.Name = "lblMinimap";
            this.lblMinimap.Size = new System.Drawing.Size(49, 13);
            this.lblMinimap.TabIndex = 98;
            this.lblMinimap.Text = "Minimap:";
            // 
            // comboMinimap
            // 
            this.comboMinimap.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboMinimap.Items.AddRange(new object[] {
            "Fullscreen",
            "Windowed",
            "Borderless"});
            this.comboMinimap.Location = new System.Drawing.Point(311, 117);
            this.comboMinimap.Name = "comboMinimap";
            this.comboMinimap.Size = new System.Drawing.Size(138, 21);
            this.comboMinimap.TabIndex = 99;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(454, 642);
            this.Controls.Add(this.lblFog);
            this.Controls.Add(this.trackFog);
            this.Controls.Add(this.lblFogValue);
            this.Controls.Add(this.lblLineGap);
            this.Controls.Add(this.comboLineGap);
            this.Controls.Add(this.lblMinimap);
            this.Controls.Add(this.comboMinimap);
            this.Controls.Add(this.lblShadow);
            this.Controls.Add(this.comboShadow);
            this.Controls.Add(this.comboRender);
            this.Controls.Add(this.lblRender);
            this.Controls.Add(this.btnRA);
            this.Controls.Add(this.lblMenu);
            this.Controls.Add(this.lblUncensored);
            this.Controls.Add(this.lblMenuType);
            this.Controls.Add(this.comboMenuType);
            this.Controls.Add(this.lblGameLang);
            this.Controls.Add(this.comboGameLang);
            this.Controls.Add(this.chkUncensored);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.regionLabel);
            this.Controls.Add(this.comboMap);
            this.Controls.Add(this.comboDisc);
            this.Controls.Add(this.lblDisc);
            this.Controls.Add(this.audioLabel);
            this.Controls.Add(this.comboAudioOut);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnBug);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.downloadBuild);
            this.Controls.Add(this.btnBuildSettings);
            this.Controls.Add(this.btnControls);
            this.Controls.Add(this.skipIntrosLabel);
            this.Controls.Add(this.chunksLabel);
            this.Controls.Add(this.fullscreenLabel);
            this.Controls.Add(this.vsyncLabel);
            this.Controls.Add(this.comboResolution);
            this.Controls.Add(this.comboRefresh);
            this.Controls.Add(this.pillarboxPanel);
            this.Controls.Add(this.banner);
            this.Controls.Add(this.btnManager);
            this.Controls.Add(this.btnPlay);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnChangelog);
            this.Controls.Add(this.lblUpdateStatus);
            this.Controls.Add(this.progUpdate);
            this.Controls.Add(this.resolutionLabel);
            this.Controls.Add(this.refreshLabel);
            this.Controls.Add(this.comboFullscreen);
            this.Controls.Add(this.vsyncPanel);
            this.Controls.Add(this.skipIntrosPanel);
            this.Controls.Add(this.decalsPanel);
            this.Controls.Add(this.decalsLabel);
            this.Controls.Add(this.preloadPanel);
            this.Controls.Add(this.fpsLabel);
            this.Controls.Add(this.comboFps);
            this.Controls.Add(this.filteringLabel);
            this.Controls.Add(this.comboFiltering);
            this.Controls.Add(this.comboDithering);
            this.Controls.Add(this.ditheringLabel);
            this.Controls.Add(this.comboScaling);
            this.Controls.Add(this.scalingLabel);
            this.Controls.Add(this.loggingLabel);
            this.Controls.Add(this.loggingPanel);
            this.Controls.Add(this.consoleLabel);
            this.Controls.Add(this.consolePanel);
            this.Controls.Add(this.aaLabel);
            this.Controls.Add(this.comboAA);
            this.Controls.Add(this.postLabel);
            this.Controls.Add(this.comboPost);
            this.Controls.Add(this.toneLabel);
            this.Controls.Add(this.comboTone);
            this.Controls.Add(this.flashLabel);
            this.Controls.Add(this.comboFlash);
            this.Controls.Add(this.pgxpLabel);
            this.Controls.Add(this.pgxpPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Silent Hill Launcher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.vsyncPanel.ResumeLayout(false);
            this.skipIntrosPanel.ResumeLayout(false);
            this.decalsPanel.ResumeLayout(false);
            this.decalsPanel.PerformLayout();
            this.preloadPanel.ResumeLayout(false);
            this.pillarboxPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.banner)).EndInit();
            this.pgxpPanel.ResumeLayout(false);
            this.loggingPanel.ResumeLayout(false);
            this.consolePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackFog)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    private Label chunksLabel;
    private Button btnControls;
    private Button btnBuildSettings;
    private Button downloadBuild;
    private Button btnHelp;
    private Button btnBug;
    private Button btnReset;
    private ComboBox comboRefresh;
    private Label label1;
    private CheckBox checkBox1;
    private CheckBox chkUncensored;
    private Label lblUncensored;
    private Label lblMenuType;
    private ComboBox comboMenuType;
    private Label lblGameLang;
    private ComboBox comboGameLang;
    private Label lblMenu;
    private Button btnRA;
    private ComboBox comboRender;
    private Label lblRender;
    private Label lblShadow;
    private ComboBox comboShadow;
    private Label lblMinimap;
    private ComboBox comboMinimap;
}
