using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using SilentHillPC_Launcher;

public partial class Form1 : Form
{
    private ConfigManager config;

    // Detected discs (filled by CheckDiscImage). The Disc dropdown is the
    // whole disc UI now — region comes from each image's boot serial, and
    // the `region` config key is only honored as a hand-set auto-pick
    // preference. PAL text language stays a config-only key
    // (`language = en/de/fr/es/it`).
    private List<DiscProbe.Disc> _discs = new List<DiscProbe.Disc>();
    // comboDisc entry -> config `disc_image` value ("" = auto pick).
    private readonly List<string> _discIds = new List<string>();
    private bool _regionUiUpdating;

    // Level select (comboMap): map overlay id -> friendly name. Canonical
    // names from the upstream README (the pre-Mod-Manager dropdown parsed
    // these from config.cfg comments, which no longer carry them). Only the
    // id before the separator is persisted to the `map` config key.
    private static readonly string[] s_mapEntries = {
        "map0_s00  -  Old Silent Hill - intro sequence",
        "map0_s01  -  Old Silent Hill - cafe",
        "map0_s02  -  Old Silent Hill - bonus unlockable areas",
        "map1_s00  -  School - 1F, courtyard, basement",
        "map1_s01  -  School - 2F",
        "map1_s02  -  School Otherworld - 1F and courtyard",
        "map1_s03  -  School Otherworld - 2F and roof",
        "map1_s04  -  Unused",
        "map1_s05  -  School - boss fight (Split Head)",
        "map1_s06  -  School - 1F and basement after the boss",
        "map2_s00  -  Old Silent Hill - streets",
        "map2_s01  -  Church",
        "map2_s02  -  Central Silent Hill - streets",
        "map2_s03  -  Unused",
        "map2_s04  -  Police station (Central Silent Hill)",
        "map3_s00  -  Hospital - until Kaufmann meeting",
        "map3_s01  -  Hospital - 1F and basement after Kaufmann",
        "map3_s02  -  Hospital - antique shop cutscene",
        "map3_s03  -  Hospital Otherworld - 3F and 2F",
        "map3_s04  -  Hospital Otherworld - 1F",
        "map3_s05  -  Hospital Otherworld - basement",
        "map3_s06  -  Hospital - 1F after Otherworld",
        "map4_s00  -  Unused",
        "map4_s01  -  Green Lion Antiques (normal + Otherworld)",
        "map4_s02  -  Central Silent Hill Otherworld - streets",
        "map4_s03  -  Mall and boss fight",
        "map4_s04  -  Hospital - 1F (Lisa cutscene)",
        "map4_s05  -  Central SH Otherworld - Floatstinger boss",
        "map4_s06  -  Unused",
        "map5_s00  -  Sewers - lower and upper levels",
        "map5_s01  -  Resort Area",
        "map5_s02  -  Annie's Bar and Indian Runner (Resort Area)",
        "map5_s03  -  Norman's Motel (Resort Area)",
        "map6_s00  -  Resort Area Otherworld",
        "map6_s01  -  Boat at Lakeside Pier",
        "map6_s02  -  Lakeside Pier and Lighthouse",
        "map6_s03  -  Sewer to Lakeside Amusement Park",
        "map6_s04  -  Amusement Park - Cybil boss, Alessa kidnapping",
        "map6_s05  -  Unused",
        "map7_s00  -  Nowhere - hospital 1F, Lisa cutscene",
        "map7_s01  -  Nowhere",
        "map7_s02  -  Nowhere - Alessa vs. Dahlia cutscene",
        "map7_s03  -  Nowhere - final boss",
    };

    private static string RegionDisplayName(string region)
    {
        switch (region)
        {
            case "USA": return Loc.T("NTSC-U (USA)");
            case "PAL": return Loc.T("PAL (Europe)");
            case "JAP": return Loc.T("NTSC-J (Japan)");
            default:    return region;
        }
    }

    public Form1()
    {
        InitializeComponent();
        this.Icon = SilentHillPC_Launcher.Properties.Resources.launchericon;
        PopulateDisplayOptions();
        LoadConfig();
        SetupTooltips();
        SetupLanguageButton();
        trackFog.ValueChanged += (s, e) => UpdateFogValueLabel();
        // On release, not while dragging, and never from LoadConfig setting
        // the slider.
        trackFog.MouseUp += (s, e) => AskPgxpForDistantWorld();
        trackFog.KeyUp   += (s, e) => AskPgxpForDistantWorld();
        this.Shown += (s, e) =>
        {
            CleanupOldFiles();
            UpdateChecker.CleanupStaleTemp();
            CheckDiscImage();
            FfmpegCheck.WarnIfNeeded(this, AppDomain.CurrentDomain.BaseDirectory);
            SilentAutoCheckForUpdates();
        };
    }


    // ---- launcher language -------------------------------------------------

    private Button btnLang;
    private readonly ToolTip _langTip = new ToolTip();

    /// <summary>
    /// The flag button in the bottom-right corner, sitting in the space the
    /// update progress bar gave up. Clicking it opens the language picker; the
    /// flag itself is the current language's, so the setting is readable at a
    /// glance without opening anything.
    /// </summary>
    private void SetupLanguageButton()
    {
        try { Loc.Current = LauncherSettings.Load(config).Language; }
        catch { Loc.Current = LauncherLang.English; }

        LocalizeValueLists();

        btnLang = new Button
        {
            /* Bottom-right corner, on the Help/Reset/Report Bug row;
             * lblUpdateStatus was narrowed to end before it. Created in code
             * rather than the designer (the flag is custom-painted), so it
             * cannot be nudged from the design surface; re-check this against
             * Form1.Designer.cs after any layout change. */
            Location = new System.Drawing.Point(420, 616),
            Size = new System.Drawing.Size(30, 22),
            Text = "",
            FlatStyle = FlatStyle.Standard,
            TabStop = false
        };
        // The flag is PAINTED, not typed: emoji flags are regional-indicator
        // pairs that only DirectWrite ligates, so GDI would draw "US".
        btnLang.Paint += (s2, e2) =>
        {
            var box = new System.Drawing.Rectangle(4, 4, btnLang.Width - 9, btnLang.Height - 9);
            FlagIcon.Draw(e2.Graphics, box, Loc.Current);
        };
        btnLang.Click += btnLang_Click;
        Controls.Add(btnLang);
        btnLang.BringToFront();
        _langTip.SetToolTip(btnLang, Loc.T("Launcher language"));

        Loc.Changed += OnLanguageChanged;
        if (Loc.Current != LauncherLang.English) OnLanguageChanged();
    }

    private readonly Dictionary<Control, Func<string>> _dynText =
        new Dictionary<Control, Func<string>>();

    /// <summary>
    /// Set a control's text from its English, and remember how to redo it.
    ///
    /// Loc.Apply can only restore the text a control was BORN with, so anything
    /// the update flow rewrites at runtime ("Update available!", the status
    /// line) would snap back to its designer text on a language switch. These
    /// are re-applied after Apply instead.
    /// </summary>
    private void SetText(Control c, string english, params object[] args)
    {
        if (c == null) return;
        Func<string> f = () => (args == null || args.Length == 0)
            ? Loc.T(english)
            : string.Format(Loc.T(english), args);
        _dynText[c] = f;
        c.Text = f();
    }

    /// <summary>
    /// Combos whose items are words rather than data. Only these get owner-draw
    /// translation — resolution, refresh rate, FPS cap, disc image and level are
    /// left alone because their selected text is what gets written to config.cfg.
    /// </summary>
    /// Codes parallel to comboGameLang's items. Never read the item text: it is
    /// translated, the codes are not.
    private readonly List<string> _gameLangCodes = new List<string>();

    /* The "Native (PSX)" resolution entry: config native_resolution = 1, with
     * width/height kept as the WINDOW size the game scales its own modes into. */
    private string _nativeResText;

    /// Build the Game Language row: Automatic, the languages every disc family
    /// carries, then whatever packs are installed in gamedata/lang.
    ///
    /// The launcher does not know which disc will be mounted, so it offers all
    /// of them and lets the game decide -- it already falls back to Automatic
    /// for anything this disc cannot render, and says so in its log.
    /// The dropdown's current code -- the user's intent, saved or not.
    private string CurrentGameLanguageCode()
    {
        int i = comboGameLang.SelectedIndex;
        return (i >= 0 && i < _gameLangCodes.Count) ? _gameLangCodes[i] : config.Get("language", "auto");
    }

    private void BuildGameLangList()
    {
        comboGameLang.Items.Clear();
        _gameLangCodes.Clear();

        void Add(string name, string code)
        {
            if (_gameLangCodes.Any(c => string.Equals(c, code, StringComparison.OrdinalIgnoreCase)))
                return;
            comboGameLang.Items.Add(name);
            _gameLangCodes.Add(code);
        }

        // "en" is NOT PAL English: it is the disc's own, so on a USA disc it is
        // US English and on every disc it is what Automatic already gives. The
        // PAL script travels as the en_pal pack, and that is its code anywhere.
        Add("Automatic",   "auto");
        Add("US English",  "en_us");
        Add("PAL English", "en_pal");
        Add("German",      "de");
        Add("French",      "fr");
        Add("Spanish",     "es");
        Add("Italian",     "it");

        try
        {
            string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "gamedata", "lang");

            if (Directory.Exists(dir))
            {
                foreach (string f in Directory.GetFiles(dir, "*.lang").OrderBy(x => x))
                {
                    string code = null, name = null;

                    // Only the headers, which the format puts first.
                    foreach (string line in File.ReadLines(f, Encoding.UTF8).Take(16))
                    {
                        if (line.StartsWith("!code=")) code = line.Substring(6).Trim();
                        else if (line.StartsWith("!name=")) name = line.Substring(6).Trim();
                        if (code != null && name != null) break;
                    }

                    if (!string.IsNullOrEmpty(code))
                        Add(string.IsNullOrEmpty(name) ? code : name, code);
                }
            }
        }
        catch
        {
            // An unreadable pack folder costs the extra rows, nothing else.
        }
    }

    private void LocalizeValueLists()
    {
        // "はい"/"いいえ" and "Nein" are wider than "Yes"/"No", and each of these
        // sits at the end of its row with free space to the right.
        foreach (var r in new[] { radioVsyncYes, radioVsyncNo, radioDecalsYes, radioDecalsNo, radioPreloadYes, radioPreloadNo,
                                  pgxpYes, pgxpNo, loggingYes, loggingNo, consoleYes, consoleNo })
            r.AutoSize = true;

        Loc.LocalizeItems(comboGameLang);
        Loc.LocalizeItems(comboFullscreen);
        Loc.LocalizeItems(comboSkipIntros);
        Loc.LocalizeItems(comboPillarbox);
        Loc.LocalizeItems(comboFiltering);
        Loc.LocalizeItems(comboDithering);
        Loc.LocalizeItems(comboScaling);
        Loc.LocalizeItems(comboAA);
        Loc.LocalizeItems(comboPost);
        Loc.LocalizeItems(comboTone);
        Loc.LocalizeItems(comboFlash);
        Loc.LocalizeItems(comboLineGap);
        Loc.LocalizeItems(comboAudioOut);
        Loc.LocalizeItems(comboRender);
        Loc.LocalizeItems(comboMinimap);
        Loc.LocalizeItems(comboDisc);
        // Only the description after the id is words; the id itself is what
        // SaveConfig splits off and writes.
        Loc.LocalizeItems(comboMap, item =>
        {
            int sep = item.IndexOf("  -  ", StringComparison.Ordinal);
            return sep < 0 ? Loc.T(item) : item.Substring(0, sep + 5) + Loc.T(item.Substring(sep + 5));
        });
    }

    private readonly Dictionary<Label, int> _labelHome = new Dictionary<Label, int>();

    /// <summary>
    /// Nudge a label left when its translation would otherwise run under the
    /// control beside it — the labels are AutoSize, so a longer word grows to
    /// the right and paints over the combo it belongs to.
    ///
    /// A label is never moved past whatever is to its left, and never past its
    /// designed position, so this only ever consumes slack the row already had.
    /// </summary>
    private void FitLabels(Control root)
    {
        foreach (Control c in root.Controls)
        {
            var lbl = c as Label;
            if (lbl == null) { FitLabels(c); continue; }

            int home;
            if (!_labelHome.TryGetValue(lbl, out home)) { home = lbl.Left; _labelHome[lbl] = home; }
            lbl.Left = home;

            int rightX = int.MaxValue, leftEdge = 4;
            foreach (Control o in root.Controls)
            {
                if (ReferenceEquals(o, lbl) || Math.Abs(o.Top - lbl.Top) > 12) continue;
                if (o.Left > home && o.Left < rightX) rightX = o.Left;
                if (o.Right <= home && o.Right + 4 > leftEdge) leftEdge = o.Right + 4;
            }
            if (rightX == int.MaxValue) continue;

            int w = TextRenderer.MeasureText(lbl.Text, lbl.Font).Width;
            int want = rightX - 4 - w;
            if (want < home) lbl.Left = Math.Max(leftEdge, want);
        }
    }

    private void OnLanguageChanged()
    {
        Loc.Apply(this);
        SetupTooltips();
        foreach (var kv in _dynText) kv.Key.Text = kv.Value();
        UpdateDiscUi();
        if (!btnUpdate.Enabled) btnPlay.Enabled = false; // an update is running
        FitLabels(this);
        if (btnLang != null)
        {
            btnLang.Invalidate();
            _langTip.SetToolTip(btnLang, Loc.T("Launcher language"));
        }
    }

    private void btnLang_Click(object sender, EventArgs e)
    {
        var before = Loc.Current;
        using (var dlg = new LanguageDialog(Loc.Current))
        {
            dlg.ShowDialog(this);
            Loc.Set(dlg.Selected);
        }
        if (Loc.Current == before) return;

        try
        {
            var st = LauncherSettings.Load(config);
            st.Language = Loc.Current;
            st.Save(config);
        }
        catch { /* config not writable - the choice still applies this session */ }
    }

    /// <summary>
    /// Delete *.old leftovers from a previous self-update (a running exe
    /// can't be overwritten, so ReplaceFile renames it aside; by the next
    /// launcher start the old process is gone and the file is unlocked).
    /// </summary>
    private void CleanupOldFiles()
    {
        try
        {
            string dir = AppDomain.CurrentDomain.BaseDirectory;
            foreach (var f in Directory.GetFiles(dir, "*.old"))
                try { File.Delete(f); } catch { /* still locked — next time */ }

            string maps = Path.Combine(dir, "maps");
            if (Directory.Exists(maps))
                foreach (var f in Directory.GetFiles(maps, "*.old"))
                    try { File.Delete(f); } catch { }
        }
        catch { /* best effort */ }
    }

    /// <summary>
    /// Detect the disc image(s) at startup (creating gamedata/ if needed) and
    /// show the identified serial/region in lblDisc; warn only when no
    /// recognizable .bin exists at all. Any filename is accepted — discs are
    /// identified by their ISO boot serial exactly like the game does. Gated
    /// on SilentHillPC.exe being present so dev runs from bin\Release don't
    /// nag or scaffold stray folders.
    /// </summary>
    private void CheckDiscImage()
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        if (!File.Exists(Path.Combine(dir, "SilentHillPC.exe"))) return;

        string gamedata = Path.Combine(dir, "gamedata");
        try { if (!Directory.Exists(gamedata)) Directory.CreateDirectory(gamedata); }
        catch { return; }

        _discs = DiscProbe.Scan(gamedata);

        _regionUiUpdating = true;
        comboDisc.Items.Clear();
        _discIds.Clear();
        comboDisc.Enabled = false;

        if (_discs.Count == 0)
        {
            _regionUiUpdating = false;
            SetText(lblDisc, "No disc image found in gamedata\\");
            MessageBox.Show(this,
                Loc.T("No Silent Hill disc image found.\n\n" +
                      "Please put a Silent Hill .bin (USA or PAL/European release)\n" +
                      "in the gamedata folder!"),
                "Silent Hill PC",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // Disc dropdown: Auto (the game's region rules) plus every detected
        // image. Picking a specific file writes `disc_image`, which is how a
        // fan-translated / modified copy gets selected over the vanilla one.
        comboDisc.Items.Add("Disc: Auto");
        _discIds.Add("");
        foreach (var d in _discs)
        {
            comboDisc.Items.Add(d.FileName + (d.Modified ? "  [modified]" : ""));
            _discIds.Add(d.FileName);
        }
        comboDisc.Enabled = _discs.Count > 0;

        // Restore the saved filename case-insensitively (NTFS is; the game's
        // fopen is too). A saved value whose file is gone/renamed gets its own
        // "[missing]" entry so a hand-set config value is preserved on Play
        // instead of being silently reset to Auto.
        string savedDisc = config.Get("disc_image", "");
        int discIdx = _discIds.FindIndex(
            id => string.Equals(id, savedDisc, StringComparison.OrdinalIgnoreCase));
        if (discIdx < 0 && savedDisc.Length > 0)
        {
            comboDisc.Items.Add(savedDisc + "  [missing]");
            _discIds.Add(savedDisc);
            discIdx = _discIds.Count - 1;
        }
        comboDisc.SelectedIndex = discIdx >= 0 ? discIdx : 0;
        _regionUiUpdating = false;

        UpdateDiscUi();
    }

    /// <summary>
    /// Representative disc for a region ("USA"/"PAL"/"JAP"): mirror the
    /// game's pick order — known filenames first, then the first probed
    /// disc of that region.
    /// </summary>
    private DiscProbe.Disc DiscForRegion(string region)
    {
        string[] knownNames = {
            "Silent Hill (USA).bin",
            "Silent Hill (PAL).bin",
            "Silent Hill (Europe) (En,Fr,De,Es,It).bin",
            "Silent Hill (Japan).bin",
        };
        foreach (var kn in knownNames)
        {
            var d = _discs.FirstOrDefault(x => x.Region == region &&
                        x.FileName.Equals(kn, StringComparison.OrdinalIgnoreCase));
            if (d != null) return d;
        }
        return _discs.FirstOrDefault(x => x.Region == region);
    }

    /// <summary>
    /// The disc the game's Auto rules would boot: a hand-set `region`
    /// config preference first (the UI no longer writes the key), then
    /// USA > PAL > JAP priority.
    /// </summary>
    private DiscProbe.Disc AutoPickDisc()
    {
        string pref       = config.Get("region", "auto");
        string prefRegion = pref == "usa" ? "USA" : pref == "pal" ? "PAL" : pref == "jap" ? "JAP" : null;

        if (prefRegion != null)
        {
            var d = DiscForRegion(prefRegion);
            if (d != null) return d;
        }
        foreach (var region in new[] { "USA", "PAL", "JAP" })
        {
            var d = DiscForRegion(region);
            if (d != null) return d;
        }
        return null;
    }

    /// <summary>Explicitly selected disc, or null when the dropdown is on
    /// Auto (or on a saved-but-missing filename).</summary>
    private DiscProbe.Disc SelectedDisc()
    {
        if (comboDisc.SelectedIndex <= 0 || comboDisc.SelectedIndex >= _discIds.Count)
            return null;
        string id = _discIds[comboDisc.SelectedIndex];
        return _discs.FirstOrDefault(d =>
            string.Equals(d.FileName, id, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>
    /// Reflect the Disc selection: a specific disc means the game boots
    /// exactly that file (region from its serial); on Auto the status line
    /// shows what the game's own rules would pick. Unsupported serials
    /// (NTSC-J first prints etc.) disable Play with a highlight.
    /// </summary>
    private void UpdateDiscUi()
    {
        var disc = SelectedDisc();

        if (disc == null)
            disc = AutoPickDisc();
        if (disc == null)
            return;

        // Compact strings — the status label is a single 13px line.
        string text = $"{disc.Serial} {disc.Region}";

        if (!disc.Supported)
        {
            lblDisc.ForeColor = Color.Firebrick;
            lblDisc.Text      = text + " — " + Loc.T(string.IsNullOrEmpty(disc.UnsupportedReason)
                                                ? "not supported yet"
                                                : disc.UnsupportedReason);
            btnPlay.Enabled   = false;
            return;
        }

        if (disc.Modified)
        {
            // Fan translation / patched image: the game reads its text and
            // voices straight off the disc.
            lblDisc.ForeColor = Color.RoyalBlue;
            lblDisc.Text      = text + " — " + Loc.T("fan patch");
        }
        else
        {
            lblDisc.ForeColor = SystemColors.ControlText;
            lblDisc.Text      = $"{disc.Serial} — {RegionDisplayName(disc.Region)}";
        }
        btnPlay.Enabled = true;
    }

    private void comboDisc_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (_regionUiUpdating) return;
        UpdateDiscUi();
    }

    /// <summary>
    /// Fire-and-forget update probe on launcher startup. Doesn't pop a
    /// dialog or block anything — just updates lblUpdateStatus so the
    /// user sees "Update available: X" or "Up to date" without clicking.
    /// Click "Check for Updates" to actually run the install flow.
    ///
    /// Failures are silent (no network, no remote, etc.) — startup
    /// shouldn't yell at users about a missing connection.
    /// </summary>
    // Always checks the configured branch's LATEST build, regardless of which
    // build is pinned, and reports an update only when that latest is newer than
    // the highest version ever installed from this branch (so deliberately
    // running an old build isn't flagged). Build switching is the Download Build
    // button's job.
    private static LauncherSettings ForceLatest(LauncherSettings s)
        // A custom (opt-in) build tracks ITS OWN named build: forcing plain "latest"
        // would measure it against a different mod's newest release, or the beta one.
        => new LauncherSettings
        {
            RepoUrl        = s.RepoUrl,
            Branch         = s.Branch,
            Build          = UpdateChecker.CustomFamilyLatestToken(s.Build) ?? "latest",
            OldBuildWarned = s.OldBuildWarned
        };

    private async void SilentAutoCheckForUpdates()
    {
        var settings = LauncherSettings.Load(config);
        string installDir = AppDomain.CurrentDomain.BaseDirectory;
        SetText(btnUpdate, "Check for Updates");
        SetText(downloadBuild, "Download Build");
        try
        {
            SetText(lblUpdateStatus, "Checking for updates...");
            var plan = await UpdateChecker.CheckAsync(installDir, ForceLatest(settings));

            // If the install already matches the latest, remember that so it
            // isn't mis-reported as an update later.
            if (!plan.HasUpdate) settings.RecordSeenAtLeast(config, plan.RemoteVersion);

            bool available = LauncherSettings.CompareVersions(plan.RemoteVersion, settings.GetSeen(config)) > 0;
            if (available)
            {
                SetText(btnUpdate, "Update available!");
                lblUpdateStatus.ForeColor = Color.LightGreen;
                SetText(lblUpdateStatus, "Update available: {0}", plan.RemoteVersion);
            }
            else
            {
                lblUpdateStatus.ForeColor = Color.LightGray;
                SetText(lblUpdateStatus, "Up to date ({0}).", plan.RemoteVersion);
            }

            // "Download Build" vs "Redownload Build": is the SELECTED build already
            // installed? For "latest" reuse the check above; for a pinned build do
            // a quick second check.
            bool selectedInstalled = settings.IsLatestBuild
                ? !plan.HasUpdate
                : !(await UpdateChecker.CheckAsync(installDir, settings)).HasUpdate;
            SetText(downloadBuild, selectedInstalled ? "Redownload Build" : "Download Build");
        }
        catch
        {
            // Silent — no internet, no nightly repo yet, etc.
            SetText(lblUpdateStatus, "");
        }
    }

    /// <summary>
    /// Hover tooltips for each option. Resolution/refresh-rate are
    /// self-explanatory and skipped. Tooltip text is intentionally short —
    /// long enough to explain non-obvious behavior, short enough to read at
    /// a glance.
    /// </summary>
    private ToolTip _tip;

    private void SetupTooltips()
    {
        // Reused across language switches: a second ToolTip would leave the
        // first one's (old-language) text popping up alongside the new one.
        if (_tip == null)
            _tip = new ToolTip
            {
                AutoPopDelay = 12000,  // keep visible up to 12s while hovered
                InitialDelay = 400,
                ReshowDelay  = 200,
                ShowAlways   = true,
            };
        var tip = _tip;

        /* Tooltips are localized here rather than at each call site: the English
         * text IS the dictionary key, so every Set() below stays readable and a
         * missing translation falls through to English on its own. SetupTooltips
         * is re-run by OnLanguageChanged, because a ToolTip's text is not a
         * control property and Loc.Apply cannot reach it. */
        void Set(Control c, string text)
        {
            if (c == null) return;
            text = Loc.T(text);
            tip.SetToolTip(c, text);
            // Radio buttons sit inside panels; attach to the panel too so
            // hovering between buttons doesn't drop the tooltip.
            if (c.Parent is Panel)
                tip.SetToolTip(c.Parent, text);
        }

        const string fullscreenTip =
            "Fullscreen: exclusive fullscreen at the chosen resolution.\n" +
            "Windowed: a normal window at the chosen resolution.\n" +
            "Borderless: fills the screen at desktop resolution (fast alt-tab).";
        Set(fullscreenLabel,   fullscreenTip);
        Set(comboFullscreen,   fullscreenTip);

        const string vsyncTip =
            "Sync frames to your monitor's refresh rate.\n" +
            "Yes: no tearing, may add a frame of input lag.\n" +
            "No: lowest input lag, possible tearing.";
        Set(vsyncLabel,     vsyncTip);
        Set(radioVsyncYes,  vsyncTip);
        Set(radioVsyncNo,   vsyncTip);

        const string fpsTip =
            "Frame rate cap (0 = unlimited). Game logic always runs at 30 Hz;\n" +
            "a higher cap makes the camera and input smoother.";
        Set(fpsLabel,  fpsTip);
        Set(comboFps,  fpsTip);

        const string filteringTip =
            "Off: crisp PSX pixels.\n" +
            "Bilinear: smooths textures.\n" +
            "Trilinear: bilinear plus mip blending (only replacement textures with mips).\n" +
            "Anisotropic: sharper surfaces at steep angles; higher costs more GPU.";
        Set(filteringLabel, filteringTip);
        Set(comboFiltering, filteringTip);

        const string ditheringTip =
            "The PSX 4x4 ordered dither plus a 5-bit quantize: the original look.\n" +
            "It also hides texture-page seams as noise instead of hard edges.\n" +
            "Separate from Filtering, so the two can be combined.";
        Set(ditheringLabel, ditheringTip);
        Set(comboDithering, ditheringTip);

        const string scalingTip =
            "How a render resolution SMALLER than the window is scaled up to fill it.\n" +
            "Integer: whole-number scale, centred, with a border. Nothing shimmers.\n" +
            "Nearest Neighbor: fills the screen, no blending, edges can crawl.\n" +
            "Bilinear: fills the screen, smoothly blended. Default.\n" +
            "Sharp Bilinear: whole-number scale first, then blend the remainder.\n" +
            "No effect when the resolution already matches the window.";
        Set(scalingLabel, scalingTip);
        Set(comboScaling, scalingTip);

        const string menuFilterTip =
            "Also smooth menus and 2D screens with bilinear filtering.\n" +
            "Separate from Filtering; softens menu text too.";
        Set(lblMenu, menuFilterTip);
        Set(checkBox1, menuFilterTip);

        const string pgxpTip =
            "On: precise vertices and perspective-correct textures (less wobble and warping).\n" +
            "Off: authentic PSX look. Toggle in-game with F1.";
        Set(pgxpLabel,  pgxpTip);
        Set(pgxpYes,    pgxpTip);
        Set(pgxpNo,     pgxpTip);

        const string skipIntrosTip =
            "Don't Skip: warning, logos and intro movie, as in the original.\n" +
            "Skip to Menu: straight to the title screen.\n" +
            "Skip to Game: starts a New Game (Normal) on the map chosen under Level.";
        Set(skipIntrosLabel,  skipIntrosTip);
        Set(comboSkipIntros,  skipIntrosTip);

        const string decalsTip =
            "Bullet holes on walls where your shots land.\n" +
            "Not in the original game, so off by default.";
        Set(decalsLabel,      decalsTip);
        Set(radioDecalsYes,   decalsTip);
        Set(radioDecalsNo,    decalsTip);

        const string renderTip =
            "Graphics API. OpenGL (native) is the default and the best tested.\n" +
            "The others run through ANGLE: try Direct3D 11 or Vulkan if OpenGL misbehaves.\n" +
            "WARP and Software render on the CPU (very slow).\n" +
            "ANGLE needs libEGL.dll and libGLESv2.dll next to the exe.";
        Set(lblRender,        renderTip);
        Set(comboRender,      renderTip);

        const string shadowTip =
            "Flashlight shadow map size (shadow flashlight modes only).\n" +
            "Higher is sharper but costs more GPU; 8192 needs a recent GPU.\n" +
            "Console: shadowres <size>";
        Set(lblShadow,        shadowTip);
        Set(comboShadow,      shadowTip);

        const string minimapTip =
            "Minimap shape and screen corner.\n" +
            "Size and opacity are in the in-game options. Console: minimap";
        Set(lblMinimap,       minimapTip);
        Set(comboMinimap,     minimapTip);

        const string preloadTip =
            "Load every map chunk at level start instead of streaming them as you walk.\n" +
            "No pop-in, but more memory and a longer first load. Recommended.";
        Set(chunksLabel,      preloadTip);
        Set(radioPreloadYes,  preloadTip);
        Set(radioPreloadNo,   preloadTip);

        const string pillarboxTip =
            "4:3 black bars on widescreen displays:\n" +
            "Menus Only (default): bars on 2D screens; 3D gameplay fills the screen.\n" +
            "Yes: bars everywhere.\n" +
            "No: no bars; menus are stretched.";
        Set(refreshLabel,        pillarboxTip);
        Set(comboPillarbox,      pillarboxTip);

        const string discTip =
            "Disc image to boot. Discs are detected by serial, so filenames don't matter.\n" +
            "Auto picks USA, then PAL, then NTSC-J. PAL carries EN/DE/FR/ES/IT text.\n" +
            "[modified] marks fan translations and patched discs; also pick the matching\n" +
            "Language in the title screen options (or set language = es in config.cfg).";
        Set(regionLabel, discTip);
        Set(comboDisc,   discTip);
        Set(lblDisc,     discTip);

        const string levelTip =
            "Map a New Game starts on (default map0_s00, the intro alley).\n" +
            "Handy for jumping to a specific scene when testing.";
        Set(label1,   levelTip);
        Set(comboMap, levelTip);

        const string audioTip =
            "Speaker layout. Auto follows your Windows sound setup.\n" +
            "With surround speakers, sounds pan all around you. HRTF = 3D audio for headphones.\n" +
            "In-game console: AUDIOOUT";
        Set(audioLabel,    audioTip);
        Set(comboAudioOut, audioTip);

        const string uncensoredTip =
            "PAL and NTSC-J discs. Checked (default): the censored \"Mumblers\", as on\n" +
            "the retail disc. Unchecked: the original Grey Children, as on the US disc.\n" +
            "PAL censors them everywhere, NTSC-J in the school and the amusement park.\n" +
            "No effect on a USA disc, which was never censored.";
        Set(lblMenuType,   Loc.T("Which main menu the game shows: the US picture, "
                                + "PAL's fog-only title, or the Japanese logo. "
                                + "Auto follows the disc."));
        Set(comboMenuType, Loc.T("Which main menu the game shows: the US picture, "
                                + "PAL's fog-only title, or the Japanese logo. "
                                + "Auto follows the disc."));
        const string gameLangTip =
            "Which language the game runs in. Automatic follows the disc: US English" +
            " on a USA disc, PAL English on a PAL one, Japanese on NTSC-J.";
        Set(lblGameLang,   Loc.T(gameLangTip));
        Set(comboGameLang, Loc.T(gameLangTip));
        Set(lblUncensored,  uncensoredTip);
        Set(chkUncensored,  uncensoredTip);

        const string loggingTip =
            "Write a log to SilentHill.log next to the game.\n" +
            "Needed to diagnose crashes; keep it on if you might report a bug.";
        Set(loggingLabel,  loggingTip);
        Set(loggingYes,    loggingTip);
        Set(loggingNo,     loggingTip);

        const string consoleTip =
            "Open a separate console window with live debug output.\n" +
            "Optional: with debug controls on, hold ~ in-game for the built-in console.";
        Set(consoleLabel,  consoleTip);
        Set(consoleYes,    consoleTip);
        Set(consoleNo,     consoleTip);

        const string aaTip =
            "MSAA: smooths jagged 3D edges; higher costs more GPU.\n" +
            "Textures and 2D UI stay sharp. Turns itself off if the GPU can't do it.";
        Set(aaLabel,   aaTip);
        Set(comboAA,   aaTip);

        const string postTip =
            "Full-screen post-processing look (CRT, scanlines, vignette, film grain…).\n" +
            "Cycle in-game with F2.";
        Set(postLabel, postTip);
        Set(comboPost, postTip);

        const string toneTip =
            "Tone mapping (Reinhard, ACES, Filmic): softens highlights for a filmic look.\n" +
            "Cycle in-game with F3.";
        Set(toneLabel, toneTip);
        Set(comboTone, toneTip);

        const string flashTip =
            "Classic: the original PSX flashlight (per-vertex).\n" +
            "Classic + Shadows: the same look per-pixel, with real-time shadows.\n" +
            "Modern: a stylized per-pixel spotlight.\n" +
            "Modern + Shadows: Modern with real-time shadows.\n" +
            "Cycle in-game with F4; [ and ] adjust the beam.";
        Set(flashLabel, flashTip);
        Set(comboFlash, flashTip);

        const string fogTip =
            "How far you can see through the fog. The default (1.10) is the classic game.\n" +
            "Anything below 1.00 lets you see the world beyond the fog: the whole town is\n" +
            "drawn out to the horizon. Below about 0.70 the fog has only a minimal effect.\n" +
            "Also in game: F10 > Graphics.";
        Set(lblFog, fogTip);
        Set(trackFog, fogTip);
        Set(lblFogValue, fogTip);

        const string lineGapTip =
            "Emulates the PlayStation's CD seek before each spoken line in cutscenes.\n" +
            "On the console a voice line started a beat after its subtitle while the disc\n" +
            "sought the clip; the PC loads instantly. Scene and subtitle timing are unchanged,\n" +
            "only the voice starts later. Normal is the default.";
        Set(lblLineGap, lineGapTip);
        Set(comboLineGap, lineGapTip);

        Set(btnManager, "Manage texture packs, load-folder and FMV mods: enable, disable and set load order.");

        Set(btnPlay, "Save settings and start the game.");

        // RA's tip reflects live sign-in state, so it gets its own refreshable pass.
        RefreshRaTooltip();
        Set(btnChangelog, "Show the changelog of the installed build.");
        Set(btnControls, "Keyboard and controller bindings, plus debug/cheat keys.");
        Set(btnUpdate, "Check the selected branch for a newer build and offer to update.");
        Set(btnBuildSettings, "Choose the repo, branch and build to track for updates.");
        Set(downloadBuild, "Download the build selected in Build Settings, replacing your game files.");
    }

    /// <summary>
    /// Canonical map descriptions (per the upstream decomp README). These
    /// are the primary source for the dropdown, so the launcher shows
    /// correct names even against an old/minimal config.cfg. Keep in sync
    /// with the `# Available maps` comment block in pc_port/config.cfg.
    /// </summary>
    private static readonly Dictionary<string, string> BuiltinMapDescriptions = new Dictionary<string, string>
    {
        { "map0_s00", "Old Silent Hill - intro sequence" },
        { "map0_s01", "Old Silent Hill - cafe" },
        { "map0_s02", "Old Silent Hill - bonus unlockable areas" },
        { "map1_s00", "School - 1F, courtyard, basement" },
        { "map1_s01", "School - 2F" },
        { "map1_s02", "School Otherworld - 1F and courtyard" },
        { "map1_s03", "School Otherworld - 2F and roof" },
        { "map1_s04", "Unused" },
        { "map1_s05", "School - boss fight (Split Head)" },
        { "map1_s06", "School - 1F and basement after the boss" },
        { "map2_s00", "Old Silent Hill - streets" },
        { "map2_s01", "Church" },
        { "map2_s02", "Central Silent Hill - streets" },
        { "map2_s03", "Unused" },
        { "map2_s04", "Police station (Central Silent Hill)" },
        { "map3_s00", "Hospital - until Kaufmann meeting" },
        { "map3_s01", "Hospital - 1F and basement after Kaufmann" },
        { "map3_s02", "Hospital - antique shop cutscene" },
        { "map3_s03", "Hospital Otherworld - 3F and 2F" },
        { "map3_s04", "Hospital Otherworld - 1F" },
        { "map3_s05", "Hospital Otherworld - basement" },
        { "map3_s06", "Hospital - 1F after Otherworld" },
        { "map4_s00", "Unused" },
        { "map4_s01", "Green Lion Antiques (normal + Otherworld)" },
        { "map4_s02", "Central Silent Hill Otherworld - streets" },
        { "map4_s03", "Mall and boss fight" },
        { "map4_s04", "Hospital - 1F (Lisa cutscene)" },
        { "map4_s05", "Central SH Otherworld - Floatstinger boss" },
        { "map4_s06", "Unused" },
        { "map5_s00", "Sewers - lower and upper levels" },
        { "map5_s01", "Resort Area" },
        { "map5_s02", "Annie's Bar and Indian Runner (Resort Area)" },
        { "map5_s03", "Norman's Motel (Resort Area)" },
        { "map6_s00", "Resort Area Otherworld" },
        { "map6_s01", "Boat at Lakeside Pier" },
        { "map6_s02", "Lakeside Pier and Lighthouse" },
        { "map6_s03", "Sewer to Lakeside Amusement Park" },
        { "map6_s04", "Amusement Park - Cybil boss, Alessa kidnapping" },
        { "map6_s05", "Unused" },
        { "map7_s00", "Nowhere - hospital 1F, Lisa cutscene" },
        { "map7_s01", "Nowhere" },
        { "map7_s02", "Nowhere - Alessa vs. Dahlia cutscene" },
        { "map7_s03", "Nowhere - final boss" },
    };

    /// <summary>
    /// Map id → description for the dropdown. Built-in canonical names win;
    /// `# mapX_sY  Description` comment lines from config.cfg only fill ids
    /// the built-in table doesn't know (future/renamed maps).
    /// </summary>
    private Dictionary<string, string> LoadMapDescriptions(string cfgPath)
    {
        var result = new Dictionary<string, string>(BuiltinMapDescriptions);
        if (!File.Exists(cfgPath)) return result;

        var rx = new Regex(@"^#\s+(map\d+_s\d+)\s+(.+?)\s*$");
        try
        {
            foreach (var line in File.ReadAllLines(cfgPath))
            {
                var m = rx.Match(line);
                if (m.Success && !result.ContainsKey(m.Groups[1].Value))
                    result[m.Groups[1].Value] = m.Groups[2].Value.Trim();
            }
        }
        catch { /* best-effort; unknown ids just fall back to plain id */ }
        return result;
    }

    /// <summary>
    /// If config.cfg is missing, regenerate it from the embedded copy of
    /// pc_port/config.cfg (linked into the project as an EmbeddedResource,
    /// so it is always the current detailed template with full comments).
    /// </summary>
    private void EnsureConfigExists(string cfgPath)
    {
        if (File.Exists(cfgPath)) return;

        try
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using (var s = asm.GetManifestResourceStream("SilentHillPC_Launcher.DefaultConfig.cfg"))
            {
                if (s == null) return; // resource missing: ConfigManager defaults still apply
                using (var f = File.Create(cfgPath))
                {
                    s.CopyTo(f);
                }
            }
        }
        catch { /* read-only dir etc.; launcher still works off in-memory defaults */ }
    }

    private void PopulateDisplayOptions()
    {
        /* Renderer backends. Filled HERE because the constructor runs
         * PopulateDisplayOptions() before LoadConfig(), and LoadConfig sets
         * comboRender.SelectedIndex — an empty combo makes that throw
         * ArgumentOutOfRangeException and the launcher never opens. It first
         * lived in LocalizeValueLists(), which runs after LoadConfig, and did
         * exactly that.
         *
         * Display text is paired with the config value by INDEX through
         * RendererValues, so what lands in config.cfg never depends on the
         * label: the labels are PsyX_Backend's descriptions, the values are
         * what PsyX_Backend_FromName parses. */
        comboRender.Items.Clear();
        comboRender.Items.AddRange(new object[] {
            "OpenGL (native)", "OpenGL ES 3.0", "Direct3D 11 (ANGLE)",
            "Vulkan (ANGLE)", "Direct3D 11 WARP (CPU)", "Software (SwiftShader)" });

        /* Same index-pairing rule as the renderer: the visible text is localized,
         * the config value comes from the parallel array, so a translation can
         * never change what is written to config.cfg. */
        comboShadow.Items.Clear();
        comboShadow.Items.AddRange(new object[] {
            "256 x 256", "512 x 512", "1024 x 1024", "2048 x 2048", "4096 x 4096",
            "8192 x 8192" });

        comboMinimap.Items.Clear();
        comboMinimap.Items.AddRange(new object[] {
            "Off",
            "Circle + Top Left",     "Circle + Top Right",
            "Circle + Bottom Left",  "Circle + Bottom Right",
            "Square + Top Left",     "Square + Top Right",
            "Square + Bottom Left",  "Square + Bottom Right" });

        var modes = DisplayModes.GetModes();

        // Unique resolutions, LARGEST FIRST. A HashSet enumerates in whatever
        // order it likes, so this list used to arrive scrambled -- with ~40
        // entries that is enough on its own for someone to conclude their
        // resolution isn't there.
        var seen = new HashSet<string>();
        var resolutions = new List<(int w, int h)>();
        foreach (var m in modes)
        {
            if (seen.Add($"{m.width}x{m.height}"))
                resolutions.Add((m.width, m.height));
        }
        /* PSX-native and its doubles, which no monitor reports as a display mode
         * but which people ask for by name. Harmless in exclusive fullscreen --
         * SDL_GetClosestDisplayMode picks the nearest real mode -- and exact in
         * windowed. Added only if the driver did not already list them. */
        foreach (var r in new[] { (320, 240), (640, 480), (960, 720) })
        {
            if (seen.Add($"{r.Item1}x{r.Item2}"))
                resolutions.Add((r.Item1, r.Item2));
        }

        /* Standard 16:9 sizes the panel is big enough to frame. Some drivers --
         * and every remote-desktop, capture or virtual display -- enumerate a
         * handful of modes and nothing else, so a 1440p-capable screen could
         * come up with no 2560x1440 entry at all. Bounded by the largest width
         * and height actually reported, so nothing is offered to a display that
         * cannot show it: exclusive fullscreen snaps to the nearest real mode
         * (SDL_GetClosestDisplayMode) and windowed is exact. */
        int maxW = 0, maxH = 0;
        foreach (var r in resolutions)
        {
            if (r.w > maxW) maxW = r.w;
            if (r.h > maxH) maxH = r.h;
        }
        foreach (var r in new[] { (1280, 720), (1600, 900), (1920, 1080), (2560, 1440), (3840, 2160) })
        {
            if (r.Item1 > maxW || r.Item2 > maxH)
                continue;
            if (seen.Add($"{r.Item1}x{r.Item2}"))
                resolutions.Add((r.Item1, r.Item2));
        }

        resolutions.Sort((a, b) => a.w != b.w ? b.w.CompareTo(a.w) : b.h.CompareTo(a.h));

        foreach (var r in resolutions)
            comboResolution.Items.Add($"{r.w}x{r.h}");

        /* Last, under 320x240: every screen at the resolution the game itself
         * uses (320x224 play, 640x448 Konami, 320x448 menus), not one fixed size. */
        _nativeResText = Loc.T("Native (PSX)");
        comboResolution.Items.Add(_nativeResText);

        // Unique refresh rates, highest first.
        var refreshRates = new List<int>();
        foreach (var m in modes)
        {
            if (m.hz > 0 && !refreshRates.Contains(m.hz))
                refreshRates.Add(m.hz);
        }
        refreshRates.Sort((a, b) => b.CompareTo(a));

        foreach (var hz in refreshRates)
            comboRefresh.Items.Add(hz.ToString());
    }


    /* Keeps the largest-first order PopulateDisplayOptions established. */
    private void InsertResolutionSorted(string res)
    {
        var parts = res.Split('x');
        int w, h;
        if (parts.Length != 2 || !int.TryParse(parts[0], out w) || !int.TryParse(parts[1], out h) ||
            w <= 0 || h <= 0)
            return;

        int at = comboResolution.Items.Count;
        for (int i = 0; i < comboResolution.Items.Count; i++)
        {
            var p = comboResolution.Items[i].ToString().Split('x');
            int iw, ih;
            if (p.Length != 2 || !int.TryParse(p[0], out iw) || !int.TryParse(p[1], out ih))
                continue;
            if (w > iw || (w == iw && h > ih)) { at = i; break; }
        }
        comboResolution.Items.Insert(at, res);
    }

    private void LoadConfig()
    {
        string cfgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.cfg");
        EnsureConfigExists(cfgPath);
        config = new ConfigManager(cfgPath);

        // Level select. Cleared first: LoadConfig runs from both the
        // constructor and Form1_Load — without it every entry duplicated.
        // An unknown hand-set map id (test maps like mapt_s00) gets its own
        // raw entry so Play doesn't silently rewrite it to map0_s00.
        comboMap.Items.Clear();
        foreach (var m in s_mapEntries)
            comboMap.Items.Add(m);
        string savedMap = config.Get("map", "map0_s00");
        int mapIdx = -1;
        for (int i = 0; i < comboMap.Items.Count; i++)
        {
            string id = comboMap.Items[i].ToString().Split(new[] { "  -  " }, StringSplitOptions.None)[0];
            if (string.Equals(id, savedMap, StringComparison.OrdinalIgnoreCase)) { mapIdx = i; break; }
        }
        if (mapIdx < 0 && savedMap.Length > 0)
        {
            comboMap.Items.Add(savedMap);
            mapIdx = comboMap.Items.Count - 1;
        }
        comboMap.SelectedIndex = mapIdx >= 0 ? mapIdx : 0;

        // The box reads as "Censored" (🚫): CHECKED = censored (retail PAL
        // Mumblers), UNCHECKED = uncensored (Grey Children). The config key is
        // still `uncensored`, so the mapping is inverted here. Default 0
        // (censored) → checked, so the box defaults on.
        chkUncensored.Checked = config.Get("uncensored", "0") == "0";

        // Game language. Built once, then selected by code, because the row is
        // a mix of what every disc carries and whatever packs are installed.
        BuildGameLangList();
        {
            string gl = config.Get("language", "auto").Trim();
            int    at = _gameLangCodes.FindIndex(
                            c => string.Equals(c, gl, StringComparison.OrdinalIgnoreCase));

            // An unknown or removed code lands on Automatic rather than on
            // whatever happens to be first, which is what the game does too.
            comboGameLang.SelectedIndex = at >= 0 ? at : 0;
        }

        // Main-menu style. "auto" is the disc's own, which is what every
        // existing config says and what the game defaults to, so it stays the
        // first item rather than silently pinning a style on the next save.
        {
            string ms = config.Get("menu_style", "auto").Trim().ToLowerInvariant();
            comboMenuType.SelectedIndex =
                  ms == "us" || ms == "western" || ms == "ntsc" ? 1
                : ms == "pal" || ms == "eur"                    ? 2
                : ms == "japanese" || ms == "jp" || ms == "ntscj" ? 3
                : 0;
        }

        // fullscreen
        // fullscreen: 0 = windowed, 1 = exclusive fullscreen, 2 = borderless.
        // Dropdown order: Fullscreen(0), Windowed(1), Borderless(2).
        switch (config.Get("fullscreen", "0"))
        {
            case "1":  comboFullscreen.SelectedIndex = 0; break;
            case "2":  comboFullscreen.SelectedIndex = 2; break;
            default:   comboFullscreen.SelectedIndex = 1; break;
        }

        // vsync
        radioVsyncYes.Checked = config.Get("vsync", "0") == "1";
        radioVsyncNo.Checked = config.Get("vsync", "0") == "0";

        // enable debug logging (writes SH_DBG output to SilentHill.log)
        loggingYes.Checked = config.Get("enable_debug_log", "0") == "1";
        loggingNo.Checked = !loggingYes.Checked;

        // External console: Yes = external window (show_console=1). The in-game
        // overlay is toggleable with ~, so the legacy ingame/both modes (2/3)
        // also count as "external on" here; SaveConfig collapses to 1/0.
        int consoleMode;
        if (!int.TryParse(config.Get("show_console", "0"), out consoleMode) || consoleMode < 0 || consoleMode > 3)
            consoleMode = 0;
        consoleYes.Checked = (consoleMode == 1 || consoleMode == 3);
        consoleNo.Checked = !consoleYes.Checked;

        // PGXP — sub-pixel-precision GTE coords + perspective-correct textures.
        // WORK IN PROGRESS — defaults off until prim emit sites are migrated.
        pgxpYes.Checked = config.Get("use_pgxp", "0") == "1";
        pgxpNo.Checked = !pgxpYes.Checked;

        comboFps.SelectedItem = config.Get("fps_cap", "30");
        string fps = config.Get("fps_cap", "30");
        if (comboFps.Items.Contains(fps))
            comboFps.SelectedItem = fps;
        else
            comboFps.SelectedItem = "30";

        /* Dithering and Filtering used to share one key (psx_dither), which meant
         * the authentic dither could not be combined with a smoothing mode. They
         * are separate keys now; a config that still only has the old one is
         * translated here the same way the game translates it, so the launcher
         * shows what is actually in effect.
         *
         * texture_filter indexes comboFiltering directly: 0 off, 1 bilinear,
         * 2 trilinear, 3..6 anisotropic 2x/4x/8x/16x. */
        int ditherOn = config.Get("dithering", "") == "1" ? 1 : 0;
        int filterIdx;
        bool haveNewKeys = config.Get("dithering", "") != "" ||
                           config.Get("texture_filter", "") != "";

        if (!int.TryParse(config.Get("texture_filter", "0"), out filterIdx))
            filterIdx = 0;

        if (!haveNewKeys)
        {
            int legacy;
            if (!int.TryParse(config.Get("psx_dither", "1"), out legacy))
                legacy = 1;
            ditherOn  = (legacy == 1) ? 1 : 0;
            filterIdx = (legacy <= 1) ? 0 : legacy - 1;  // 2..7 -> 1..6
        }

        if (filterIdx < 0 || filterIdx >= comboFiltering.Items.Count) filterIdx = 0;
        comboFiltering.SelectedIndex = filterIdx;
        comboDithering.SelectedIndex = ditherOn;

        /* Scaling: how a render resolution below the window is scaled up to it.
         * 0 integer, 1 nearest, 2 bilinear, 3 sharp bilinear. */
        int scaleIdx;
        if (!int.TryParse(config.Get("scaling", "2"), out scaleIdx))
            scaleIdx = 2;
        if (scaleIdx < 0 || scaleIdx >= comboScaling.Items.Count) scaleIdx = 2;
        comboScaling.SelectedIndex = scaleIdx;

        // "Menus:" checkbox — also bilinear-filter menu/2D screens (config key menu_filter)
        checkBox1.Checked = config.Get("menu_filter", "0") == "1";

        // Antialiasing (MSAA): config msaa value 0/2/4/8 <-> dropdown index 0..3
        switch (config.Get("msaa", "0"))
        {
            case "2": comboAA.SelectedIndex = 1; break;
            case "4": comboAA.SelectedIndex = 2; break;
            case "8": comboAA.SelectedIndex = 3; break;
            default:  comboAA.SelectedIndex = 0; break;
        }

        // Post-process look: config post_process int 0..N <-> dropdown index
        int postIdx;
        if (!int.TryParse(config.Get("post_process", "0"), out postIdx) ||
            postIdx < 0 || postIdx >= comboPost.Items.Count)
            postIdx = 0;
        comboPost.SelectedIndex = postIdx;

        // Tone mapping: config tonemap int 0..3 <-> dropdown index
        int toneIdx;
        if (!int.TryParse(config.Get("tonemap", "0"), out toneIdx) ||
            toneIdx < 0 || toneIdx >= comboTone.Items.Count)
            toneIdx = 0;
        comboTone.SelectedIndex = toneIdx;

        // Flashlight: 0 = Classic, 1 = Classic + Shadows, 2 = Modern,
        // 3 = Modern + Shadows. flashlight_mode is authoritative; configs from
        // older builds only carry the legacy pp/shadows keys (pp+shadows was
        // the pre-calibration per-pixel look, so it maps to Modern + Shadows).
        {
            string fm = config.Get("flashlight_mode", "");
            int fmIdx;
            if (!int.TryParse(fm, out fmIdx) || fmIdx < 0 || fmIdx > 3)
            {
                if (config.Get("per_pixel_flashlight", "0") != "1")
                    fmIdx = 0;
                else
                    fmIdx = config.Get("flashlight_shadows", "1") == "1" ? 3 : 2;
            }
            comboFlash.SelectedIndex = fmIdx;
        }

        // cutscene_line_gap_ms: minimum pause after a voiced cutscene line.
        // Presets only; a hand-set value that matches none shows the nearest
        // preset and stays in the file unless the dropdown is changed.
        {
            int ms;
            if (!int.TryParse(config.Get("cutscene_line_gap_ms", "300"), out ms)) ms = 300;
            _lineGapLoadedIdx = LineGapIndexFor(ms);
            comboLineGap.SelectedIndex = _lineGapLoadedIdx;
        }

        // fog_strength, snapped to the slider's 0.05 steps. A value the slider
        // cannot show (set in game above 1.20) stays in the file unless moved.
        {
            float fs;
            if (!float.TryParse(config.Get("fog_strength", "1.10"), System.Globalization.NumberStyles.Float,
                                System.Globalization.CultureInfo.InvariantCulture, out fs)) fs = 1.10f;
            _fogLoadedStep = Math.Max(trackFog.Minimum, Math.Min(trackFog.Maximum, (int)Math.Round(fs / FogStep)));
            trackFog.Value = _fogLoadedStep;
            UpdateFogValueLabel();
        }

        // Audio output (speaker layout): auto = OpenAL detects the system
        // layout. With rears active the game pans SFX on the full circle and
        // sends wide-stereo BGM layers to the surrounds.
        {
            string ao = config.Get("audio_output", "auto");
            int aoIdx = Array.IndexOf(AudioOutputIds, ao);
            comboAudioOut.SelectedIndex = aoIdx >= 0 ? aoIdx : 0;
        }

        // resolution
        string w = config.Get("width", "640");
        string h = config.Get("height", "480");
        string res = $"{w}x{h}";
        /* A size set by hand in config.cfg, or one this machine's driver does
         * not enumerate, still has to be selectable: without this the box comes
         * up blank and the next Save writes whatever the user picks instead. */
        if (config.Get("native_resolution", "0") == "1" && _nativeResText != null)
        {
            comboResolution.SelectedItem = _nativeResText;
        }
        else
        {
            if (!comboResolution.Items.Contains(res))
                InsertResolutionSorted(res);
            comboResolution.SelectedItem = res;
        }

        // refresh rate is config-only now (auto-detected by default); keep the
        // hidden combo populated harmlessly so its references stay valid.
        comboRefresh.SelectedItem = config.Get("refresh_rate", "0");

        // pillarboxing: combine menu_pillarbox + widescreen_mode into one 3-way choice.
        bool _menuPb = config.Get("menu_pillarbox", "1") == "1";
        bool _wide3d = config.Get("widescreen_mode", "1") != "0"; // 0 = pillarbox 3D
        if (!_menuPb)      comboPillarbox.SelectedIndex = 1; // No
        else if (!_wide3d) comboPillarbox.SelectedIndex = 0; // Yes (3D pillarboxed)
        else               comboPillarbox.SelectedIndex = 2; // Menus Only (default)

        // Region dropdown is populated from the detected discs in
        // CheckDiscImage (runs on Shown), not from config.

        // skip_intros is a level: 0 = don't skip, 1 = to the menu, 2 = into gameplay
        int skipIntrosLevel;
        if (!int.TryParse(config.Get("skip_intros", "0"), out skipIntrosLevel)) skipIntrosLevel = 0;
        if (skipIntrosLevel < 0) skipIntrosLevel = 0;
        if (skipIntrosLevel > 2) skipIntrosLevel = 2;
        comboSkipIntros.SelectedIndex = skipIntrosLevel;

        // preload_chunks (recommended: Yes — matches engine default)
        // bullet_decals — off by default, matching the engine default.
        radioDecalsYes.Checked = config.Get("bullet_decals", "0") == "1";
        radioDecalsNo.Checked = !radioDecalsYes.Checked;
        {
            /* Never assign SelectedIndex without checking the item count. A
             * combo that is empty (or shorter than expected) throws, and a
             * throw in LoadConfig happens in the constructor, so the launcher
             * dies before it draws a window — no UI, no log, nothing the user
             * can act on. Clamping costs nothing and the worst case is a
             * dropdown showing the wrong entry. */
            int ri = Array.IndexOf(RendererValues, config.Get("renderer", "gl").Trim().ToLowerInvariant());
            /* Unknown, or the retired "auto" — both mean OpenGL. GR_ResolveBackend
             * maps PSYX_BACKEND_AUTO straight to PSYX_BACKEND_GL with no probing
             * of any kind, so "Automatic" was a second name for the entry below
             * it and is no longer offered. A config that still says auto lands
             * here and shows what it actually gets. */
            if (ri < 0) ri = 0;
            if (ri >= comboRender.Items.Count) ri = 0;
            comboRender.SelectedIndex = comboRender.Items.Count > 0 ? ri : -1;
        }
        {
            int si = Array.IndexOf(ShadowResValues, config.Get("shadow_resolution", "1024").Trim());
            if (si < 0 || si >= comboShadow.Items.Count) si = 2; /* 1024 */
            comboShadow.SelectedIndex = comboShadow.Items.Count > 0 ? si : -1;
        }
        {
            /* One dropdown over two keys: `minimap` is 0 off / 1 square / 2 circle,
             * `minimap_corner` is 0..3. Off collapses both. */
            int shape  = ParseIntOr(config.Get("minimap", "0"), 0);
            int corner = ParseIntOr(config.Get("minimap_corner", "0"), 0);
            if (corner < 0 || corner > 3) corner = 0;

            int mi;
            if (shape == 2)      mi = 1 + corner;   /* circle */
            else if (shape == 1) mi = 5 + corner;   /* square */
            else                 mi = 0;            /* off */

            if (mi >= comboMinimap.Items.Count) mi = 0;
            comboMinimap.SelectedIndex = comboMinimap.Items.Count > 0 ? mi : -1;
        }
        radioPreloadYes.Checked = config.Get("preload_chunks", "1") == "1";
        radioPreloadNo.Checked = !radioPreloadYes.Checked;

    }

    private void SaveConfig()
    {
        config.Set("fullscreen",
            comboFullscreen.SelectedIndex == 0 ? "1" :   // Fullscreen
            comboFullscreen.SelectedIndex == 2 ? "2" :   // Borderless
            "0");                                        // Windowed
        config.Set("vsync", radioVsyncYes.Checked ? "1" : "0");
        // resolution
        if (comboResolution.SelectedItem != null &&
            comboResolution.SelectedItem.ToString() == _nativeResText)
        {
            /* The render size follows the game, so width/height only size the
             * window: the desktop when fullscreen, otherwise the largest whole
             * multiple of 320x240 that leaves room on the screen. */
            var scr = Screen.PrimaryScreen;
            int ww, wh;

            if (comboFullscreen.SelectedIndex != 1)
            {
                ww = scr.Bounds.Width;
                wh = scr.Bounds.Height;
            }
            else
            {
                int k = Math.Min(scr.WorkingArea.Width * 9 / 10 / 320,
                                 scr.WorkingArea.Height * 9 / 10 / 240);
                if (k < 2) k = 2;
                ww = 320 * k;
                wh = 240 * k;
            }
            config.Set("native_resolution", "1");
            config.Set("width", ww.ToString());
            config.Set("height", wh.ToString());
        }
        else if (comboResolution.SelectedItem != null)
        {
            var parts = comboResolution.SelectedItem.ToString().Split('x');
            config.Set("native_resolution", "0");
            config.Set("width", parts[0]);
            config.Set("height", parts[1]);
        }

        // refresh rate is config-only now (auto-detected by default) — do NOT
        // write it from the launcher so a hand-set value is preserved.

        // pillarboxing: 3-way dropdown -> menu_pillarbox + widescreen_mode
        switch (comboPillarbox.SelectedIndex)
        {
            case 0: config.Set("menu_pillarbox", "1"); config.Set("widescreen_mode", "0"); break; // Yes
            case 1: config.Set("menu_pillarbox", "0"); config.Set("widescreen_mode", "1"); break; // No
            default: config.Set("menu_pillarbox", "1"); config.Set("widescreen_mode", "1"); break; // Menus Only
        }

        /* skip_intros. disable_culling is deliberately no longer surfaced here — it stays
         * game-side (pc_config.c) and in-game-toggleable, and ConfigManager.Save() rewrites
         * only keys it holds, so a user's existing value is preserved untouched. */
        config.Set("skip_intros", comboSkipIntros.SelectedIndex.ToString());

        // preload_chunks
        config.Set("bullet_decals", radioDecalsYes.Checked ? "1" : "0");
        config.Set("renderer", RendererValues[comboRender.SelectedIndex >= 0 ? comboRender.SelectedIndex : 1]);
        config.Set("shadow_resolution", ShadowResValues[comboShadow.SelectedIndex >= 0 ? comboShadow.SelectedIndex : 2]);
        {
            int mi = comboMinimap.SelectedIndex;
            if (mi < 0) mi = 0;
            config.Set("minimap",        mi == 0 ? "0" : (mi <= 4 ? "2" : "1"));
            config.Set("minimap_corner", mi == 0 ? "0" : ((mi <= 4 ? mi - 1 : mi - 5)).ToString());
        }
        config.Set("preload_chunks", radioPreloadYes.Checked ? "1" : "0");

        // enable debug logging
        config.Set("enable_debug_log", loggingYes.Checked ? "1" : "0");

        // External console: Yes = external window (1), No = off (0). The in-game
        // console stays togglable with ~ regardless of this setting.
        config.Set("show_console", consoleYes.Checked ? "1" : "0");

        // PGXP toggle (work-in-progress)
        config.Set("use_pgxp", pgxpYes.Checked ? "1" : "0");

        if (comboFps.SelectedItem != null)
            config.Set("fps_cap", comboFps.SelectedItem.ToString());

        /* Filtering and Dithering are independent keys. psx_dither is deliberately
         * not written back: it only exists so an old config still loads, and
         * leaving it alone keeps it from overriding these two on the next boot. */
        if (comboFiltering.SelectedIndex >= 0)
            config.Set("texture_filter", comboFiltering.SelectedIndex.ToString());
        if (comboDithering.SelectedIndex >= 0)
            config.Set("dithering", comboDithering.SelectedIndex == 1 ? "1" : "0");
        if (comboScaling.SelectedIndex >= 0)
            config.Set("scaling", comboScaling.SelectedIndex.ToString());
        config.Set("menu_filter", checkBox1.Checked ? "1" : "0");

        // Antialiasing (MSAA): dropdown index 0..3 -> msaa 0/2/4/8
        switch (comboAA.SelectedIndex)
        {
            case 1:  config.Set("msaa", "2"); break;
            case 2:  config.Set("msaa", "4"); break;
            case 3:  config.Set("msaa", "8"); break;
            default: config.Set("msaa", "0"); break;
        }

        // Post-process look: dropdown index -> post_process int
        if (comboPost.SelectedIndex >= 0)
            config.Set("post_process", comboPost.SelectedIndex.ToString());

        // Tone mapping: dropdown index -> tonemap int
        if (comboTone.SelectedIndex >= 0)
            config.Set("tonemap", comboTone.SelectedIndex.ToString());

        // Flashlight dropdown -> flashlight_mode (authoritative) + the legacy
        // keys for older builds. 0 = Classic, 1 = Classic + Shadows, 2 = Modern,
        // 3 = Modern + Shadows.
        {
            int fmIdx = comboFlash.SelectedIndex >= 0 ? comboFlash.SelectedIndex : 0;
            config.Set("flashlight_mode", fmIdx.ToString());
            config.Set("per_pixel_flashlight", fmIdx >= 1 ? "1" : "0");
            config.Set("flashlight_shadows", (fmIdx == 1 || fmIdx == 3) ? "1" : "0");
        }

        if (comboLineGap.SelectedIndex >= 0 &&
            (comboLineGap.SelectedIndex != _lineGapLoadedIdx || config.Get("cutscene_line_gap_ms", "") == ""))
            config.Set("cutscene_line_gap_ms", LineGapValues[comboLineGap.SelectedIndex].ToString());

        if (trackFog.Value != _fogLoadedStep)
            config.Set("fog_strength", (trackFog.Value * FogStep).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture));

        // Audio output dropdown -> audio_output string id.
        if (comboAudioOut.SelectedIndex >= 0)
            config.Set("audio_output", AudioOutputIds[comboAudioOut.SelectedIndex]);

        // Disc: exact filename (fan-translated / modified images), "" = auto.
        // Untouched when no disc was detected so a hand-set value survives.
        // (The `region` key is no longer UI-managed; a hand-set value keeps
        // steering the Auto pick.)
        if (comboDisc.SelectedIndex >= 0 && comboDisc.SelectedIndex < _discIds.Count)
            config.Set("disc_image", _discIds[comboDisc.SelectedIndex]);

        config.Set("uncensored", chkUncensored.Checked ? "0" : "1"); // checked = censored

        // By INDEX into the parallel code list, for the same reason as below:
        // the visible names are translated, the codes are not.
        if (comboGameLang.SelectedIndex >= 0 &&
            comboGameLang.SelectedIndex < _gameLangCodes.Count)
            config.Set("language", _gameLangCodes[comboGameLang.SelectedIndex]);

        // Read by INDEX, never by item text: the items are region codes the
        // game parses, and Loc must never be able to change what lands here.
        switch (comboMenuType.SelectedIndex)
        {
            case 1:  config.Set("menu_style", "us");       break;
            case 2:  config.Set("menu_style", "pal");      break;
            case 3:  config.Set("menu_style", "japanese"); break;
            default: config.Set("menu_style", "auto");     break;
        }

        // Level: persist only the map id, not the " - description" suffix.
        if (comboMap.SelectedItem != null)
        {
            string sel = comboMap.SelectedItem.ToString();
            config.Set("map", sel.Split(new[] { "  -  " }, StringSplitOptions.None)[0]);
        }

        config.Save();
    }

    // Dropdown index -> audio_output config id (matches the game's parser).
    private static readonly string[] AudioOutputIds = { "auto", "stereo", "quad", "51", "71", "hrtf" };

    // Fog/World Visibility slider -> fog_strength. Capped at 1.20 rather than
    // the game's 2.0: past that the town is already fully fogged out.
    private const float FogStep = 0.05f;
    private int _fogLoadedStep = 22;

    // A "No" holds until the launcher is closed; "Do Not Ask Again" is saved.
    private static bool s_pgxpFogDeclined;

    private void AskPgxpForDistantWorld()
    {
        if (trackFog.Value * FogStep >= 0.999f || pgxpYes.Checked || s_pgxpFogDeclined)
            return;
        if (config.Get("launcher_warn_pgxp_fog", "1").Trim() == "0")
            return;

        using (var dlg = new SilentHillPC_Launcher.PgxpFogDialog())
        {
            dlg.ShowDialog(this);
            switch (dlg.Result)
            {
                case SilentHillPC_Launcher.PgxpFogDialog.Choice.Yes:
                    pgxpYes.Checked = true;
                    break;
                case SilentHillPC_Launcher.PgxpFogDialog.Choice.NeverAsk:
                    config.EnsureLauncherSection();
                    config.Set("launcher_warn_pgxp_fog", "0");
                    config.Save();
                    break;
                default:
                    s_pgxpFogDeclined = true;
                    break;
            }
        }
    }

    private void UpdateFogValueLabel()
    {
        lblFogValue.Text = (trackFog.Value * FogStep).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
    }

    // Dialog Pause dropdown -> cutscene_line_gap_ms (CD seek before each voice
    // line). 300 is the engine default.
    private static readonly int[] LineGapValues = { 0, 150, 300, 600 };
    private int _lineGapLoadedIdx = 2;
    private static int LineGapIndexFor(int ms)
    {
        if (ms <= 0)   return 0;
        if (ms <= 220) return 1;
        if (ms <= 450) return 2;
        return 3;
    }

    // Win32 focus helpers. Windows' focus-stealing-prevention blocks a newly-
    // spawned process from taking the foreground unless the parent grants
    // permission via AllowSetForegroundWindow OR the parent explicitly calls
    // SetForegroundWindow on the child window once it exists. Use both: the
    // permission grant covers the case where the game brings itself to front
    // during SDL init, and the explicit call handles SDL builds that don't.
    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool AllowSetForegroundWindow(uint dwProcessId);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    /// <summary>
    /// Warn once per launch when the config carries `resident_textures = 0` and
    /// offer to turn it on. Runs AFTER SaveConfig so the value read here is the
    /// one the game is about to load, including a hand edit made while the
    /// launcher was open (ConfigManager.Save re-reads, and this key is never
    /// Set() by the launcher, so Get reports what is really on disk).
    ///
    /// Only ever prompts; the fallback is legitimate on some hardware, so the
    /// launcher must not overrule a deliberate choice. `launcher_warn_resident_textures = 0`
    /// suppresses it permanently.
    /// </summary>
    private void WarnIfResidentTexturesOff()
    {
        if (config == null) return;
        if (config.Get("resident_textures", "1").Trim() != "0") return;
        if (config.Get("launcher_warn_resident_textures", "1").Trim() == "0") return;

        using (var dlg = new SilentHillPC_Launcher.ResidentTexturesDialog())
        {
            dlg.ShowDialog(this);
            switch (dlg.Result)
            {
                case SilentHillPC_Launcher.ResidentTexturesDialog.Choice.TurnOn:
                    config.Set("resident_textures", "1");
                    config.Save();
                    break;
                case SilentHillPC_Launcher.ResidentTexturesDialog.Choice.NeverAsk:
                    config.EnsureLauncherSection();
                    config.Set("launcher_warn_resident_textures", "0");
                    config.Save();
                    break;
                default:
                    break; /* leave it off, ask again next launch */
            }
        }
    }

    private void btnPlay_Click(object sender, EventArgs e)
    {
        SaveConfig();
        WarnIfResidentTexturesOff();

        string exePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SilentHillPC.exe");

        if (!File.Exists(exePath))
        {
            MessageBox.Show(Loc.T("SilentHillPC.exe not found."));
            return;
        }

        try
        {
            // The game opens config.cfg relative to its working directory; a
            // shortcut with another "Start in" folder made it read (and write
            // binds to) a different file than the one this launcher edits.
            var p = Process.Start(new ProcessStartInfo(exePath)
            {
                WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                UseShellExecute  = false,
            });
            if (p != null)
            {
                /* THE stale-settings bug. The launcher loads config.cfg once at
                 * startup, and this handler saves the UI state before every
                 * launch -- so: Play, change options in-game (the game writes
                 * them to config.cfg correctly), quit, Play again... and this
                 * SaveConfig() just overwrote the in-game changes with whatever
                 * the launcher was showing from before. Reload the UI from disk
                 * the moment the game exits, so the launcher always reflects the
                 * most recent writer. */
                try
                {
                    p.EnableRaisingEvents = true;
                    p.Exited += (s2, e2) =>
                    {
                        try { BeginInvoke((Action)(() => LoadConfig())); }
                        catch { /* launcher closing; nothing to refresh */ }
                    };
                }
                catch { }

                // Grant the child process permission to come to the foreground.
                AllowSetForegroundWindow((uint)p.Id);

                // Wait briefly for the SDL window to be created and message-
                // loop ready, then explicitly raise it. WaitForInputIdle's
                // timeout is forgiving — if the game takes longer to init, we
                // just skip the explicit call; the AllowSetForegroundWindow
                // permission still lets SDL bring it forward later.
                try { p.WaitForInputIdle(2000); } catch { }
                p.Refresh();
                if (p.MainWindowHandle != IntPtr.Zero)
                {
                    SetForegroundWindow(p.MainWindowHandle);
                }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(Loc.F("Failed to launch SilentHillPC.exe: {0}", ex.Message));
            return;
        }

        Close();
    }

    // Check for Updates: always checks the configured branch's LATEST build and
    // offers to update + switch to it — but only when that latest is newer than
    // the highest version ever installed from this branch, so an old build you
    // chose on purpose doesn't nag you. (Switching to a specific build is the
    // Download Build button's job.)
    private async void btnUpdate_Click(object sender, EventArgs e)
    {
        string installDir = AppDomain.CurrentDomain.BaseDirectory;
        var settings = LauncherSettings.Load(config);

        SetUpdateBusy(true);
        SetText(lblUpdateStatus, "Checking for updates...");
        progUpdate.Style   = ProgressBarStyle.Marquee;
        progUpdate.Visible = true;
        try
        {
            var plan = await UpdateChecker.CheckAsync(installDir, ForceLatest(settings));
            if (!plan.HasUpdate) settings.RecordSeenAtLeast(config, plan.RemoteVersion);

            bool available = LauncherSettings.CompareVersions(plan.RemoteVersion, settings.GetSeen(config)) > 0;
            if (!available)
            {
                SetText(btnUpdate, "Check for Updates");
                SetText(lblUpdateStatus, "Up to date ({0}).", plan.RemoteVersion);
                progUpdate.Visible = false;
                MessageBox.Show(this,
                    Loc.F("You're up to date!\n\nSource: {0}\nLatest: {1}", plan.RepoLabel, plan.RemoteVersion),
                    Loc.T("Check for Updates"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SetText(btnUpdate, "Update available!");
            lblUpdateStatus.ForeColor = Color.LightGreen;

            // Always re-promptable: clicking the button offers the update every
            // time, even if you said "no" before. (View Changelog previews the
            // incoming build's notes without downloading it.)
            bool wantUpdate = PromptUpdate(Loc.T("Update available"),
                Loc.F("A newer build is available: {0}\nBuilt: {1}\nSource: {2}",
                      plan.RemoteVersion, plan.BuildDate, plan.RepoLabel) + "\n\n" +
                (plan.IsBeta ? Loc.T("This build is on the BETA branch (newer than the latest alpha/stable build).") + "\n\n" : "") +
                (plan.IsCustom
                    ? Loc.F("This is the experimental build \"{0}\", not a normal release. " +
                            "You stay on it until you pick another branch in Build Settings.",
                            string.IsNullOrWhiteSpace(plan.BuildName) ? "custom" : plan.BuildName) + "\n\n"
                    : "") +
                (settings.IsLatestBuild ? "" : Loc.F("You currently have build '{0}' selected.", settings.Build) + "\n") +
                Loc.T("Update to the latest build and switch to it now?"),
                plan.ChangelogUrl);
            if (!wantUpdate)
            {
                SetText(lblUpdateStatus, "Update {0} skipped.", plan.RemoteVersion);
                progUpdate.Visible = false;
                return;
            }

            bool applied = await RunApplyAsync(installDir, plan, showFileConfirm: false);
            if (applied)
            {
                // Stay with whatever stream the user is on: a custom build keeps
                // following its own named build, everything else tracks latest.
                settings.Build = UpdateChecker.CustomFamilyLatestToken(settings.Build) ?? "latest";
                if (!string.IsNullOrEmpty(plan.MigrateToBranch))
                    settings.Branch = plan.MigrateToBranch;   // auto-migrate alpha -> beta
                settings.Save(config);
                settings.RecordInstalled(config, plan.RemoteVersion);
                SetText(btnUpdate, "Check for Updates");
                SetText(downloadBuild, "Redownload Build"); // latest is now installed
                lblUpdateStatus.ForeColor = Color.LightGray;
                SetText(lblUpdateStatus, "Up to date ({0}).", plan.RemoteVersion);
                MessageBox.Show(this, Loc.T("Update complete!"), Loc.T("Update"), MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                SetText(lblUpdateStatus, "Update {0} skipped.", plan.RemoteVersion);
            }
        }
        catch (Exception ex)
        {
            SetText(lblUpdateStatus, "Update failed (see message).");
            MessageBox.Show(this, Loc.F("Update failed:\n\n{0}", ex.Message), Loc.T("Update error"),
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetUpdateBusy(false);
            progUpdate.Visible = false;
        }
    }

    // Download Build: download (or re-download) the SELECTED build and replace
    // the differing game files with it, regardless of newer/older. The launcher
    // exe is never downgraded (CheckAsync's gate handles that).
    private async void downloadBuild_Click(object sender, EventArgs e)
    {
        string installDir = AppDomain.CurrentDomain.BaseDirectory;
        var settings = LauncherSettings.Load(config);

        SetUpdateBusy(true);
        SetText(lblUpdateStatus, "Checking selected build...");
        progUpdate.Style   = ProgressBarStyle.Marquee;
        progUpdate.Visible = true;
        try
        {
            var plan = await UpdateChecker.CheckAsync(installDir, settings);

            if (!plan.HasUpdate)
            {
                progUpdate.Visible = false;
                SetText(lblUpdateStatus, "Build {0} is installed.", plan.RemoteVersion);
                MessageBox.Show(this,
                    Loc.F("Build {0} is already installed.\n\nSource: {1}", plan.RemoteVersion, plan.RepoLabel),
                    Loc.T("Download Build"), MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var others = plan.Changed.Where(f => !UpdateChecker.IsLauncherFile(f.Path)).ToList();
            var sb = new StringBuilder();
            sb.AppendLine(Loc.F("Download build {0}?", plan.RemoteVersion));
            sb.AppendLine(Loc.F("Built: {0}", plan.BuildDate));
            sb.AppendLine(Loc.F("Source: {0}", plan.RepoLabel));
            sb.AppendLine();
            sb.AppendLine(Loc.F("{0} file(s) will be replaced with this build:", others.Count));
            int i = 0;
            foreach (var f in others)
            {
                if (i++ < 10) sb.AppendLine($"  • {f.Path}");
                else { sb.AppendLine("  • " + Loc.F("... and {0} more", others.Count - 10)); break; }
            }
            sb.AppendLine();
            bool hasExisting = File.Exists(Path.Combine(installDir, "SilentHillPC.exe"));
            string promptTitle;
            MessageBoxIcon promptIcon;
            if (hasExisting)
            {
                sb.AppendLine(Loc.T("This will overwrite your existing files. Are you sure you want to continue?"));
                promptTitle = Loc.T("Overwrite existing files?");
                promptIcon  = MessageBoxIcon.Warning;
            }
            else
            {
                sb.AppendLine(Loc.T("Download and install now?"));
                promptTitle = Loc.T("Download Build");
                promptIcon  = MessageBoxIcon.Information;
            }
            if (MessageBox.Show(this, sb.ToString(), promptTitle,
                    MessageBoxButtons.YesNo, promptIcon) != DialogResult.Yes)
            {
                SetText(lblUpdateStatus, "Download cancelled.");
                progUpdate.Visible = false;
                return;
            }

            bool applied = await RunApplyAsync(installDir, plan, showFileConfirm: false);
            if (applied)
            {
                settings.RecordInstalled(config, plan.RemoteVersion);
                lblUpdateStatus.ForeColor = Color.LightGray;
                SetText(lblUpdateStatus, "Build {0} installed.", plan.RemoteVersion);
                MessageBox.Show(this, Loc.F("Build {0} installed!", plan.RemoteVersion), Loc.T("Download Build"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                SilentAutoCheckForUpdates(); // refresh the update indicator
            }
            else
            {
                SetText(lblUpdateStatus, "Download cancelled.");
            }
        }
        catch (Exception ex)
        {
            SetText(lblUpdateStatus, "Download failed (see message).");
            MessageBox.Show(this, Loc.F("Download failed:\n\n{0}", ex.Message), Loc.T("Download error"),
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetUpdateBusy(false);
            progUpdate.Visible = false;
        }
    }

    private void SetUpdateBusy(bool busy)
    {
        btnUpdate.Enabled     = !busy;
        downloadBuild.Enabled = !busy;
        btnPlay.Enabled       = !busy;
    }

    // Shared apply: a SEPARATE launcher self-update confirm (only when the
    // incoming launcher is strictly newer), an optional file-list confirm, then
    // the download/install with progress. Returns true if anything was installed.
    private async Task<bool> RunApplyAsync(string installDir, UpdateChecker.UpdatePlan plan, bool showFileConfirm)
    {
        var launcherEntry = plan.LauncherEntry;
        bool applyLauncher = false;
        if (launcherEntry != null && plan.LauncherIsNewer)
        {
            var lmsg = Loc.F(
                "An update for the launcher is available. Update it?\n\n" +
                "New launcher version: {0}\n" +
                "Current version: {1}\n" +
                "Build: {2} ({3})\n" +
                "Source: {4}\n\n" +
                "The launcher is replaced and the new version loads the next time you open it.",
                plan.LauncherVersion, LauncherSettings.OwnLauncherVersion(),
                plan.RemoteVersion, plan.BuildDate, plan.RepoLabel);
            applyLauncher = MessageBox.Show(this, lmsg, Loc.T("Launcher update"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }

        var others = plan.Changed.Where(f => !UpdateChecker.IsLauncherFile(f.Path)).ToList();
        bool applyOthers = others.Count > 0;
        if (applyOthers && showFileConfirm)
        {
            var sb = new StringBuilder();
            sb.AppendLine(plan.Mode == "zip"
                ? Loc.F("{0} file(s) to install (from zip):", others.Count)
                : Loc.F("{0} file(s) to download:", others.Count));
            int i = 0;
            foreach (var f in others)
            {
                if (i++ < 10) sb.AppendLine($"  • {f.Path}");
                else { sb.AppendLine("  • " + Loc.F("... and {0} more", others.Count - 10)); break; }
            }
            sb.AppendLine();
            sb.AppendLine(Loc.T("Continue?"));
            applyOthers = MessageBox.Show(this, sb.ToString(), Loc.T("Update"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes;
        }

        var apply = new List<UpdateChecker.FileEntry>();
        if (applyLauncher && launcherEntry != null) apply.Add(launcherEntry);
        if (applyOthers) apply.AddRange(others);
        if (apply.Count == 0) return false;
        plan.Changed = apply;

        progUpdate.Style = ProgressBarStyle.Continuous;
        progUpdate.Minimum = 0;
        progUpdate.Maximum = 100;
        await UpdateChecker.ApplyAsync(installDir, plan, (frac, msg) =>
        {
            // Marshal back to UI thread — the progress callback fires on
            // whatever thread HttpClient happens to be on.
            BeginInvoke((Action)(() =>
            {
                if (frac >= 0 && frac <= 1) progUpdate.Value = (int)(frac * 100);
                lblUpdateStatus.Text = Loc.T(msg ?? "");
            }));
        });

        if (applyLauncher)
            MessageBox.Show(this,
                Loc.T("The launcher itself was updated — the new version loads the next time you open it."),
                Loc.T("Launcher updated"), MessageBoxButtons.OK, MessageBoxIcon.Information);
        return true;
    }

    private void btnChangelog_Click(object sender, EventArgs e)
    {
        string changelogPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CHANGELOG.md");
        string text = File.Exists(changelogPath)
            ? File.ReadAllText(changelogPath, System.Text.Encoding.UTF8)
            : Loc.T("CHANGELOG.md not found next to the launcher.\n\n" +
                    "Run 'Check for Updates' to download the latest build, which includes the changelog.");
        ChangelogViewer.Show(this, Loc.T("Silent Hill PC Port — Changelog (installed)"), text);
    }

    // Update prompt with a "View Changelog" button that previews the INCOMING
    // build's notes (fetched from the release, not the local copy). Returns true
    // if the user chose to update.
    private bool PromptUpdate(string title, string message, string changelogUrl)
    {
        bool update = false;
        using (var dlg = new Form
        {
            Text            = title,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            StartPosition   = FormStartPosition.CenterParent,
            MaximizeBox     = false,
            MinimizeBox     = false,
            ShowInTaskbar   = false,
            ClientSize      = new Size(432, 195),
            BackColor       = Color.FromArgb(32, 32, 32),
            ForeColor       = Color.Gainsboro,
        })
        {
            var lbl    = new Label  { Text = message, Left = 14, Top = 14, Width = 404, Height = 112, AutoSize = false };
            var btnCl  = new Button { Text = Loc.T("View Changelog"), Left = 14,  Top = 150, Width = 120, Height = 28 };
            var btnYes = new Button { Text = Loc.T("Update"),         Left = 246, Top = 150, Width = 80,  Height = 28 };
            var btnNo  = new Button { Text = Loc.T("Not now"),        Left = 332, Top = 150, Width = 86,  Height = 28, DialogResult = DialogResult.Cancel };

            // Translations run longer than the English this was laid out for:
            // grow the label to its text and each button to its caption.
            int textH = TextRenderer.MeasureText(message, dlg.Font, new Size(lbl.Width, 0),
                                                 TextFormatFlags.WordBreak).Height;
            if (textH > lbl.Height)
            {
                int grow = textH - lbl.Height + 4;
                lbl.Height += grow;
                foreach (var b in new[] { btnCl, btnYes, btnNo }) b.Top += grow;
                dlg.ClientSize = new Size(dlg.ClientSize.Width, dlg.ClientSize.Height + grow);
            }
            foreach (var b in new[] { btnCl, btnYes, btnNo })
                b.Width = Math.Max(b.Width, TextRenderer.MeasureText(b.Text, dlg.Font).Width + 20);
            btnNo.Left  = dlg.ClientSize.Width - 14 - btnNo.Width;
            btnYes.Left = btnNo.Left - 6 - btnYes.Width;
            btnYes.Click += (s, e) => { update = true; dlg.Close(); };
            btnCl.Enabled = !string.IsNullOrWhiteSpace(changelogUrl);
            btnCl.Click += async (s, e) =>
            {
                btnCl.Enabled = false;
                try { ChangelogViewer.Show(dlg, Loc.T("Changelog — incoming build"), await UpdateChecker.FetchTextAsync(changelogUrl)); }
                catch (Exception ex) { MessageBox.Show(dlg, Loc.F("Couldn't load the changelog:\n\n{0}", ex.Message), Loc.T("Changelog"), MessageBoxButtons.OK, MessageBoxIcon.Warning); }
                finally { btnCl.Enabled = true; }
            };

            dlg.Controls.Add(lbl);
            dlg.Controls.Add(btnCl);
            dlg.Controls.Add(btnYes);
            dlg.Controls.Add(btnNo);
            dlg.AcceptButton = btnYes;
            dlg.CancelButton = btnNo;
            dlg.ShowDialog(this);
        }
        return update;
    }

    private void ApplyDarkMode()
    {
        Color back = Color.FromArgb(30, 30, 30);
        Color panelBack = Color.FromArgb(45, 45, 45);
        Color text = Color.White;

        this.BackColor = back;
        this.ForeColor = text;

        foreach (Control c in this.Controls)
            ApplyDarkToControl(c, back, panelBack, text);
    }

    private void ApplyDarkToControl(Control c, Color back, Color panelBack, Color text)
    {
        if (c is Panel)
            c.BackColor = panelBack;
        else if (c is ComboBox)
            c.BackColor = panelBack;
        else if (c is Button)
            c.BackColor = panelBack;
        else
            c.BackColor = back;

        c.ForeColor = text;

        // Recursively apply to children
        foreach (Control child in c.Controls)
            ApplyDarkToControl(child, back, panelBack, text);
    }


    private void banner_Click(object sender, EventArgs e)
    {
        /* Belt and braces: Control only raises Click off WM_LBUTTONUP, so the
         * right-click that opens the background menu should never reach here --
         * but About popping up behind that menu would be a nasty surprise. */
        MouseEventArgs me = e as MouseEventArgs;
        if (me != null && me.Button != MouseButtons.Left)
            return;

        string about = Loc.F(
    "This port is based on the decompiled Silent Hill 1 for PSX source code:\n\n" +
    "{0}\n\n" +
    "This launcher and port were created by Chris Hardin aka KushAstronaut " +
    "({1}), with many thanks and a lot of help from " +
    "Psycross, Claude Code, and the decomp community.\n\n" +
    "The source code is available here:\n\n" +
    "{2}\n\n" +
    "You should never pay for this software, and you should always provide " +
    "your own legally obtained game data.\n\n" +
    "Silent Hill is copyright © KONAMI",
            "https://github.com/shdecompilations/silent-hill-decomp",
            "kushastronaut@icloud.com",
            "https://github.com/SlickAmogus/silent-hill-decomp");
        MessageBox.Show(about, Loc.T("About Silent Hill PC Port"),
            MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void comboResolution_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void btnManager_Click(object sender, EventArgs e)
    {
        using (var f = new SilentHillPC_Launcher.ModManagerForm(config, AppDomain.CurrentDomain.BaseDirectory, CurrentGameLanguageCode()))
        {
            f.ShowDialog(this);
        }
    }

    private void btnManager_MouseDown(object sender, MouseEventArgs e)
    {
        if (e.Button == MouseButtons.Left)
            btnManager.BackgroundImage = SilentHillPC_Launcher.Properties.Resources.manager_clicked;
    }

    private void btnManager_MouseUp(object sender, MouseEventArgs e)
    {
        btnManager.BackgroundImage = SilentHillPC_Launcher.Properties.Resources.manager;
    }

    private void btnManager_MouseLeave(object sender, EventArgs e)
    {
        btnManager.BackgroundImage = SilentHillPC_Launcher.Properties.Resources.manager;
    }

    private void comboRefresh_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void Form1_Load(object sender, EventArgs e)
    {

        //ApplyDarkMode();
        LoadConfig();
        BannerInit();
    }

    // ==========================================================
    // Custom banner (right-click the banner image)
    // ==========================================================

    /* The chosen image is re-encoded to one fixed PNG beside the launcher, so its
     * presence alone is the "customised" flag -- nothing to keep in sync in the
     * config, and Reset is just a delete. Re-encoding also means we do not care
     * what container the user picked. */
    private static string BannerCustomPath =>
        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "launcher_banner.png");

    private Image             _bannerCustom;
    private ContextMenuStrip  _bannerMenu;
    private ToolStripMenuItem _bannerMenuReset;
    private ToolStripMenuItem _bannerMenuDark;
    private bool _darkMode;
    /* Captured before the first darkening so the toggle can go back. Without it
     * "off" would have to guess at the designer's per-control colours. */
    private Dictionary<Control, Color[]> _lightColors;

    private void BannerInit()
    {
        banner.MouseUp += banner_MouseUp;
        BannerApplyCustomIfPresent();

        if (config != null && config.Get("launcher_dark_mode", "0").Trim() == "1")
            DarkModeSet(true, false);
    }

    // ==========================================================
    // Dark mode (toggled from the banner right-click menu)
    // ==========================================================

    private void DarkModeSet(bool on, bool persist = true)
    {
        if (on)
        {
            if (_lightColors == null)
            {
                _lightColors = new Dictionary<Control, Color[]>();
                DarkModeCapture(this);
                foreach (Control c in this.Controls) DarkModeCapture(c);
            }
            ApplyDarkMode();
        }
        else
        {
            DarkModeRestore();
        }

        _darkMode = on;

        if (persist && config != null)
        {
            try
            {
                config.EnsureLauncherSection();
                config.Set("launcher_dark_mode", on ? "1" : "0");
                config.Save();
            }
            catch { /* a read-only install must not break the toggle */ }
        }
    }

    private void DarkModeCapture(Control c)
    {
        if (!_lightColors.ContainsKey(c))
            _lightColors[c] = new Color[] { c.BackColor, c.ForeColor };

        foreach (Control child in c.Controls)
            DarkModeCapture(child);
    }

    private void DarkModeRestore()
    {
        if (_lightColors == null) return;

        foreach (var kv in _lightColors)
        {
            kv.Key.BackColor = kv.Value[0];
            kv.Key.ForeColor = kv.Value[1];
        }
    }

    /* ContextMenuStrip is a Component, not a Control, so the Controls walk in
     * ApplyDarkMode never reaches it. */
    private void DarkModeStyleMenu(ContextMenuStrip menu)
    {
        Color back = _darkMode ? Color.FromArgb(45, 45, 45) : SystemColors.Control;
        Color text = _darkMode ? Color.White              : SystemColors.ControlText;

        menu.BackColor = back;
        menu.ForeColor = text;
        menu.RenderMode = _darkMode ? ToolStripRenderMode.System : ToolStripRenderMode.ManagerRenderMode;

        foreach (ToolStripItem it in menu.Items)
        {
            it.BackColor = back;
            it.ForeColor = text;
        }
    }

    private void BannerApplyCustomIfPresent()
    {
        if (!File.Exists(BannerCustomPath))
            return;

        try
        {
            /* Image.FromFile keeps the file locked for the lifetime of the Image,
             * which would make Reset fail with a sharing violation. Copy the pixels
             * and let the handle go. */
            Image loaded;
            using (var fs = new FileStream(BannerCustomPath, FileMode.Open, FileAccess.Read))
            using (var tmp = Image.FromStream(fs))
                loaded = new Bitmap(tmp);

            banner.Image = loaded;
            if (_bannerCustom != null) _bannerCustom.Dispose();
            _bannerCustom = loaded;
        }
        catch (Exception ex)
        {
            /* A corrupt or unreadable file must not stop the launcher opening --
             * fall back to the built-in banner and say why. */
            MessageBox.Show(this,
                Loc.F("The custom launcher background could not be loaded, so the default is being used.\n\n{0}", ex.Message),
                Loc.T("Custom background"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void banner_MouseUp(object sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Right)
            return;

        /* Built once and reused. Disposing a ContextMenuStrip from its own Closed
         * handler races the item's Click, which may not have run yet. */
        if (_bannerMenu == null)
        {
            // Items are created with their English so ApplyMenu can remember it;
            // a language switch while the menu exists re-translates from there.
            _bannerMenu = new ContextMenuStrip();
            _bannerMenu.Items.Add("Change background", null, (s2, e2) => BannerChange());
            _bannerMenuReset = (ToolStripMenuItem)_bannerMenu.Items.Add("Reset", null, (s2, e2) => BannerReset());
            _bannerMenu.Items.Add(new ToolStripSeparator());
            _bannerMenuDark = (ToolStripMenuItem)_bannerMenu.Items.Add("Dark mode", null, (s2, e2) => DarkModeSet(!_darkMode));
            _bannerMenu.Items.Add("Cancel", null, (s2, e2) => { });
        }

        Loc.ApplyMenu(_bannerMenu.Items);
        _bannerMenuReset.Visible = File.Exists(BannerCustomPath);
        _bannerMenuDark.Checked  = _darkMode;
        DarkModeStyleMenu(_bannerMenu);
        _bannerMenu.Show(banner, e.Location);
    }

    private void BannerChange()
    {
        using (var dlg = new OpenFileDialog())
        {
            dlg.Title  = Loc.T("Choose a launcher background");
            dlg.Filter = Loc.T("Image files") + "|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.tif;*.tiff|" + Loc.T("All files") + "|*.*";

            if (dlg.ShowDialog(this) != DialogResult.OK)
                return;

            try
            {
                /* Decode fully before touching the destination: if the pick turns
                 * out not to be an image, the existing background is untouched. */
                Bitmap copy;
                using (var fs = new FileStream(dlg.FileName, FileMode.Open, FileAccess.Read))
                using (var src = Image.FromStream(fs))
                    copy = new Bitmap(src);

                using (copy)
                    copy.Save(BannerCustomPath, System.Drawing.Imaging.ImageFormat.Png);

                BannerApplyCustomIfPresent();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    Loc.F("That file could not be used as a background.\n\n{0}", ex.Message),
                    Loc.T("Change background"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }

    private void BannerReset()
    {
        if (MessageBox.Show(this, Loc.T("Are you sure?"), Loc.T("Reset background"),
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            return;

        try
        {
            banner.Image = SilentHillPC_Launcher.Properties.Resources.launcher;

            if (_bannerCustom != null)
            {
                _bannerCustom.Dispose();
                _bannerCustom = null;
            }

            if (File.Exists(BannerCustomPath))
                File.Delete(BannerCustomPath);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this,
                Loc.F("The custom background could not be removed.\n\n{0}", ex.Message),
                Loc.T("Reset background"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    /* Parallel to comboRender's items. Index is the only link between the two,
     * so re-ordering one without the other silently writes the wrong backend. */
    private static readonly string[] RendererValues =
    {
        "gl", "gles", "d3d11", "vulkan", "warp", "software",
    };

    /* Parallel to comboShadow's items, same contract as RendererValues. */
    private static readonly string[] ShadowResValues =
    {
        "256", "512", "1024", "2048", "4096", "8192",
    };

    private static int ParseIntOr(string s, int fallback)
    {
        int v;
        return int.TryParse((s ?? "").Trim(), out v) ? v : fallback;
    }

    private void radioPreloadYes_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void preloadPanel_Paint(object sender, PaintEventArgs e)
    {

    }

    private void progUpdate_Click(object sender, EventArgs e)
    {

    }

    private void consoleLabel_Click(object sender, EventArgs e)
    {

    }

    private void btnControls_Click(object sender, EventArgs e)
    {
        // Controls button: open the keyboard/controller binding window. Shares
        // this form's ConfigManager so its Save lands in the same config.cfg.
        using (var dlg = new ControlsForm(config))
        {
            dlg.ShowDialog(this);
        }
    }

    // RetroAchievements tooltip lives on its own ToolTip so it can be refreshed
    // after sign-in/out without rebuilding every other tip in SetupTooltips.
    private readonly ToolTip _raTip = new ToolTip
    {
        AutoPopDelay = 12000,
        InitialDelay = 400,
        ReshowDelay  = 200,
        ShowAlways   = true,
    };

    private void RefreshRaTooltip()
    {
        if (btnRA == null) return;
        bool signedIn = !string.IsNullOrEmpty(config.Get("ra_token", ""));
        bool enabled  = config.Get("retroachievements", "0") == "1";
        string user   = config.Get("ra_username", "");

        string text;
        if (signedIn)
            text = enabled
                ? Loc.F("RetroAchievements: signed in as {0}.\nClick to sign out or switch accounts.", user)
                : Loc.F("RetroAchievements: signed in as {0} (achievements disabled).\nClick to sign out or switch accounts.", user);
        else
            text = Loc.T("RetroAchievements: not signed in.\n" +
                         "Click to sign in and earn achievements (softcore, matched to your disc).");
        _raTip.SetToolTip(btnRA, text);
    }

    private void btnRA_Click(object sender, EventArgs e)
    {
        // Straight to the dialog whether signed in or not. It already reports
        // the signed-in account and carries sign-out, so the confirm prompt
        // only stood between the user and the other settings on that page.
        using (var dlg = new RetroAchievementsForm(config))
        {
            dlg.ShowDialog(this);
        }
        RefreshRaTooltip();
    }

    private void btnBuildSettings_Click(object sender, EventArgs e)
    {
        // Build Settings: choose the repo/branch/build the launcher tracks for
        // updates (saved into config.cfg's ## Launcher section). Re-probe the
        // silent status afterward so the label reflects the new selection.
        using (var dlg = new BuildSettingsForm(config))
        {
            dlg.ShowDialog(this);
        }
        SilentAutoCheckForUpdates();
    }

    private void pgxpYes_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void pillarboxPanel_Paint(object sender, PaintEventArgs e)
    {

    }

    // Help button (btnHelp): contact info + a quick tip about debug controls.
    // Uses a custom dialog with a LinkLabel so "@KushAstronaut" and the Discord
    // invite are clickable (a plain MessageBox can't host links).
    private void button1_Click(object sender, EventArgs e)
    {
        const string discordProfile = "https://discord.com/users/363942283348934656";
        const string discordInvite = "https://discord.com/invite/JWuNzVsQbr";
        const string emailiCloudURL = "mailto:kushastronaut@icloud.com";
        const string emailgmailURL = "mailto:kushastronaut@gmail.com";
        const string emailiCloud = "kushastronaut@icloud.com";
        const string emailgmail = "kushastronaut@gmail.com";
        const string profileToken   = "@KushAstronaut";

        string text = Loc.F(
            "If you need help, please reach out to me on Discord {0}, " +
            "or by email at {1} or {2}. " +
            "I have created a Discord server for this port that you can join as well, " +
            "here is the link: {3} - It will have helpful info, " +
            "update news, and sometimes early releases.\n\n" +
            "Tip: There are a lot of cheats and debug commands available, and to enable " +
            "them you have to turn on the debug controls setting in the controls menu of " +
            "the launcher. When they're on, you can hold ~ to toggle the console, and " +
            "press ~ again with it open to input a command. Type help or debug to get a " +
            "list of different controls and commands!",
            profileToken, emailiCloud, emailgmail, discordInvite);

        using (var dlg = new Form())
        {
            dlg.Text = Loc.T("Get Help");
            dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.MaximizeBox = false;
            dlg.MinimizeBox = false;
            dlg.ShowInTaskbar = false;
            dlg.ClientSize = new System.Drawing.Size(430, 235);

            var link = new LinkLabel
            {
                Text = text,
                AutoSize = false,
                Location = new System.Drawing.Point(0, 0),
                Size = new System.Drawing.Size(430, 198),
                Padding = new Padding(12),
                LinkBehavior = LinkBehavior.HoverUnderline,
            };

            void AddLink(string token, string url)
            {
                int idx = text.IndexOf(token, StringComparison.Ordinal);
                if (idx >= 0)
                    link.Links.Add(idx, token.Length, url);
            }
            AddLink(profileToken, discordProfile);
            AddLink(emailgmail, emailgmailURL);
            AddLink(emailiCloud, emailiCloudURL);
            AddLink(discordInvite, discordInvite);

            link.LinkClicked += (s2, e2) =>
            {
                var url = e2.Link.LinkData as string;
                if (string.IsNullOrEmpty(url)) return;
                try { Process.Start(url); } catch { /* no browser / blocked */ }
            };

            var ok = new Button
            {
                Text = Loc.T("OK"),
                DialogResult = DialogResult.OK,
                Size = new System.Drawing.Size(75, 23),
                Location = new System.Drawing.Point(343, 203),
            };

            // Most translations are longer than the English the 198px box was sized for.
            int textH = TextRenderer.MeasureText(text, link.Font, new System.Drawing.Size(link.Width - 24, 0),
                                                 TextFormatFlags.WordBreak).Height + 24;
            if (textH > link.Height)
            {
                int grow = textH - link.Height;
                link.Height += grow;
                ok.Top += grow;
                dlg.ClientSize = new System.Drawing.Size(dlg.ClientSize.Width, dlg.ClientSize.Height + grow);
            }

            dlg.Controls.Add(link);
            dlg.Controls.Add(ok);
            dlg.AcceptButton = ok;
            dlg.ShowDialog(this);
        }
    }

    // Report Bug button (btnBug): open the GitHub issues page in the browser.
    private void button2_Click(object sender, EventArgs e)
    {
        try
        {
            Process.Start("https://github.com/SlickAmogus/silent-hill-decomp/issues");
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, Loc.F("Couldn't open the browser:\n{0}", ex.Message),
                Loc.T("Report Bug"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    // Reset button (btnReset): confirm, then overwrite config.cfg with the
    // built-in default (the embedded copy of pc_port/config.cfg) and reload.
    private void button1_Click_1(object sender, EventArgs e)
    {
        var result = MessageBox.Show(this,
            Loc.T("Are you sure you would like to reset all settings to the default?"),
            Loc.T("Reset Settings"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (result != DialogResult.Yes)
            return;

        string cfgPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.cfg");
        try
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using (var s = asm.GetManifestResourceStream("SilentHillPC_Launcher.DefaultConfig.cfg"))
            {
                if (s == null)
                {
                    MessageBox.Show(this, Loc.T("Built-in default config is missing; nothing was changed."),
                        Loc.T("Reset Settings"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                using (var f = File.Create(cfgPath))
                    s.CopyTo(f);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, Loc.F("Couldn't write config.cfg:\n{0}", ex.Message),
                Loc.T("Reset Settings"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        // Reload the freshly written defaults into the UI.
        LoadConfig();
    }

    private void regionLabel_Click(object sender, EventArgs e)
    {

    }

    private void checkBox1_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void lblUncensored_Click(object sender, EventArgs e)
    {

    }

    private void chkUncensored_CheckedChanged(object sender, EventArgs e)
    {

    }

    private void label2_Click(object sender, EventArgs e)
    {

    }
}
