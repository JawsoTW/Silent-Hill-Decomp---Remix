#include "game.h"
#ifdef SH_PC_PORT
#include "pc_pick.h"
#endif
#ifdef SH_PC_PORT
#include "sh_log.h"
#endif
#include "inline_no_dmpsx.h"

#include <psyq/libpad.h>
#include <psyq/strings.h>

#include "bodyprog/bodyprog.h"
#include "bodyprog/screen/screen_data.h"
#include "bodyprog/screen/screen_draw.h"
#include "bodyprog/screen/screen_fade.h"
#include "bodyprog/item_screens.h"
#include "bodyprog/math/math.h"
#include "bodyprog/sound/sound_system.h"
#include "main/fsqueue.h"
#ifdef SH_PC_PORT
#include <math.h>
#endif

s16 D_800AFD1C[] = // Used by `func_8008A3E0`.
{
    0x1000, 0x1000, 0x800, 0x555,
    0x400,  0x333,  0x2AA, 0x249,
    0x200,  0x1C7,  0x199, 0x174,
    0x155,  0x13B,  0x124, 0x111
};

// ========================================
// COMBAT RELATED?
// ========================================
// Will: Possibly combat? I only found that breaking `func_8008A3E0` and `func_8008B714`
// makes enemies unable to perform any attack. Also there are some sound related functions,
// they seem to be specifically done for something related to weapons in the inventory.

u32 func_8008A058(s32 arg0) // 0x8008A058
{
#ifdef SH_PC_PORT
    /* On PC, gte_ldlzc(arg0) would dereference arg0 as a pointer (broken macro).
     * func_80080540 returns (x^2+y^2+z^2)>>12; multiply by 4096 restores the square,
     * and sqrtf gives the Q12 magnitude. Result matches the GTE LZCS/LZCR table lookup. */
    if (!arg0) return 0;
    return (u32)sqrtf((float)arg0 * 4096.0f);
#else
    register s32  temp_t0 asm("t0");
    register u32  var_t1 asm("t1");
    register u32  var_t2 asm("t2");
    register s16* ptr asm("t3");

    var_t1 = 0;

    if (arg0)
    {
        gte_ldlzc(arg0);

        var_t2  = var_t1;
        ptr = SQRT;

        if (arg0 > 0)
        {
            gte_stlzcr(var_t2);
        }

        var_t1 = arg0;

        var_t2 &= 0x1E;
        temp_t0 = var_t2 - 0x18;

        var_t2 = -temp_t0;

        if (temp_t0 >= 0)
        {
            var_t2 = var_t1 << temp_t0;
        }
        else
        {
            var_t2 = var_t1 >> var_t2;
        }

        var_t2 -= 0x40;

        ptr += var_t2;

        var_t2 = *ptr;

        temp_t0  += 6;
        temp_t0 >>= 1;

        var_t1 = -temp_t0;

        if (temp_t0 >= 0)
        {
            var_t1 = var_t2 >> temp_t0;
        }
        else
        {
            var_t1 = var_t2 << var_t1;
        }
    }

    return var_t1;
#endif
}

s32 func_8008A0CC(void) // 0x8008A0CC
{
    return 0;
}

s64 func_8008A0D4(void) // 0x8008A0D4
{
    return 0;
}

s32 func_8008A0E4(s32 arg0, s32 weaponAttack, s_SubCharacter* chara, VECTOR3* pos, s_SubCharacter* chara2, q3_12 angle0, q3_12 angle1) // 0x8008A0E4
{
    s32          var_t1;
    s32          temp_a1;
    s32          var_a0;
    s32          ret;
    s32          var_v0_2;
    s32          count;
    s_AnimInfo*  mapAnimInfos;
    s_AnimInfo*  baseAnimInfos;
    s_ModelAnim* modelAnim;

    var_t1    = chara->field_44.field_0;
    modelAnim = &chara->model.anim;

    if (g_DeltaTime == Q12(0.0f) || g_SysWork.sysState != SysState_Gameplay)
    {
        return NO_VALUE;
    }

#ifdef SH_PC_PORT
    /* No hits land while the room is still fading in after a load. The world
     * updates during that reveal with the player already at his arrival point but
     * with no control; an enemy placed near the entrance would otherwise strike a
     * helpless, just-teleported Harry, and the knockback can shove him out of
     * bounds (very visible in first person). g_Screen_FadeStatus masks to
     * FadeInStart/FadeInSteps only during that post-load reveal -- never in normal
     * gameplay (which rests at None) and never for a text box -- so this suppresses
     * exactly the transition window and nothing else. */
    if ((g_Screen_FadeStatus & 0x7) >= ScreenFadeState_FadeInStart)
    {
        return NO_VALUE;
    }

    /* No-target cheat: nothing an enemy swings can land on Harry.
     *
     * This is the only place every enemy attack passes through, so it is
     * the one hook that covers ALL of them. CharaFlag_Unk4, which the cheat
     * also sets, is the game's own ignore-the-player flag but only six
     * characters ever test it (stalker, groaner, creeper, hanged scratcher,
     * air screamer, player) -- the rest inline their own distance and angle
     * math against the player's position and never consult it, which is why
     * nurses and the bosses kept attacking.
     *
     * Gated on chara2 (the VICTIM) being the player: enemies pass the player
     * there, while the player's own attacks pass an NPC, so Harry's ability
     * to damage enemies is untouched. */
    {
        extern int g_DebugNoTarget;
        if (g_DebugNoTarget && chara2 == &g_SysWork.playerWork.player)
        {
            return NO_VALUE;
        }
    }
#endif

    if (chara == &g_SysWork.playerWork.player)
    {
        baseAnimInfos = D_800297B8;
        mapAnimInfos  = g_MapOverlayHdr.harryMapAnimInfos;

        modelAnim->baseAnimInfos      = baseAnimInfos;
        modelAnim->mapAnimStatusStart = ANIM_STATUS(38, false); // TODO: 38 is the first anim after base anims. Make a constant?
        modelAnim->mapAnimInfos      = mapAnimInfos;

        modelAnim                       = &g_SysWork.playerWork.extra.model.anim;
        modelAnim->baseAnimInfos      = baseAnimInfos;
        modelAnim->mapAnimInfos      = mapAnimInfos;
        modelAnim->mapAnimStatusStart = ANIM_STATUS(38, false);
    }

    if (arg0 <= 0)
    {
        var_t1          = 0;
        chara->field_44.field_0 = 0;
    }

    chara->field_44.field_2 = weaponAttack;

#ifdef SH_PC_PORT
    /* Re-arm the one-hit-per-swing latch on a genuinely new swing.
     *
     * Confirmed by [PLRDMG] against a Puppet Nurse: the first knife hit lands
     * (sp14=0x0, dmg=132) and every hit after it reads sp14=0xFFFFFFFF, dmg=0,
     * across eight separate swings. Against the PLAYER sp10 is -1, so
     * `sp14 |= sp10` sets every bit, and neither clearing branch below ever runs
     * for this attacker: it registers only inside its attack state, so no call
     * lands on an anim with the active bit low, and field_0 stays 1 once set, so
     * the swing-start branch never fires either.
     *
     * A new swing is what actually matters, and the animation states it: either
     * the status changed, or the clock restarted. Tracked in the struct's
     * existing padding, so nothing grows. Within a swing the status holds and
     * time only advances, so this cannot fire mid-swing -- the player's melee,
     * which the existing path already handles correctly, is untouched. */
    {
        u8 animSt = (u8)modelAnim->status;
        u8 animTm = (u8)FP_FROM(modelAnim->time, Q12_SHIFT);

        if ((u8)chara->field_44.__pad_5[0] != animSt ||
            (u8)chara->field_44.__pad_5[1] > animTm)
        {
            chara->field_44.field_8 = 0;
        }

        chara->field_44.__pad_5[0] = (s8)animSt;
        chara->field_44.__pad_5[1] = (s8)animTm;
    }
#endif

    if (!(modelAnim->status & (1 << 0)))
    {
        chara->field_44.field_0 = 0;
        chara->field_44.field_8 = 0;
    }
    else if (!var_t1 && arg0 > 0)
    {
        chara->field_44.field_0 = 1;
        chara->field_44.field_8 = 0;
    }

    chara->field_44.field_3  = 100;
    chara->field_44.field_C  = angle0;
    chara->field_44.field_E  = angle1;
    chara->field_44.field_18 = *pos;
    temp_a1         = func_8008A3E0(chara);
    ret             = NO_VALUE;

    if (chara == &g_SysWork.playerWork.player)
    {
        count    = 6;
        var_v0_2 = 1;
    }
    else
    {
        count    = 1;
        var_v0_2 = NO_VALUE;
    }

    if (temp_a1 != 0)
    {
        var_a0 = var_v0_2;
        while (count > 0)
        {
            if (temp_a1 & var_a0)
            {
                ret = count;
                break;
            }

            var_a0 *= 2; // Or `<<= 1`.
            count--;
        }
    }

    if (chara->model.charaId != Chara_Harry)
    {
        if (g_SysWork.playerWork.player.attackReceived != NO_VALUE)
        {
            ret = 0;
        }
        else
        {
            ret = NO_VALUE;
        }
    }

#ifdef SH_PC_PORT
    /* Combat hit log: log every dispatch where SOMETHING interesting is
     * happening — either the cone has a target (temp_a1 > 0) or there's
     * an actual NPC in npcs[0] (so we can see why hits don't register
     * even when AirScreamer is loaded). Earlier 30-entry cap limited us
     * to the first few dispatches where npcs[0] was empty, which gave
     * no info about combat post-AirScreamer-arrival. Also log player
     * position + npc position so we can verify the hit cone geometry. */
    if (chara == &g_SysWork.playerWork.player && weaponAttack != NO_VALUE && arg0 > 0) {
        s_SubCharacter* tgt = &g_SysWork.npcs[0];
        bool interesting = (temp_a1 != 0) || (tgt->model.charaId != 0);
        static int _fireLogCount = 0;
        if (interesting && _fireLogCount < 200) {
            VECTOR3* pp = &g_SysWork.playerWork.player.position;
            _fireLogCount++;
        }
    }
#endif

    return ret;
}

const s32 g_rodataPad_8002AF9C[2] = { 0, 0 }; // TODO: Might indicate split nearby?

u32 func_8008A270(s32 idx) // 0x8008A270
{
#if VERSION_EQUAL_OR_NEWER(USA)
    switch (idx)
    {
        case 2:
        case 5:
        case 12:
        case 15:
        case 22:
        case 25:
            if (g_SysWork.field_275C > Q12(256.0f))
            {
                return 0;
            }
            break;

        default:
            break;
    }
#else
    if (idx != 57 && idx != 58)
    {
        if (g_SysWork.field_275C > Q12(256.0f))
        {
            return 0;
        }
    }
#endif

    return D_800AD4C8[idx].field_E;
}

u32 func_8008A2E0(s32 arg0) // 0x8008A2E0
{
    if (g_SysWork.field_275C > Q12(256.0f))
    {
        switch (arg0)
        {
            case 5:
            case 25:
                return 18;

            case 15:
                return 15;

            case 2:
            case 12:
            case 22:
                return 13;
        }
    }

    return D_800AD4C8[arg0].field_F;
}

s32 func_8008A35C(s_800AD4C8* arg0, s32 arg1) // 0x8008A35C
{
    s32 var;
    s32 res;

    var = arg0->field_E + arg0->field_F;
    res = 0;
    if (arg1 >= arg0->field_E)
    {
        res = (arg1 < var);
    }

    return res;
}

void Chara_Flag8Clear(s_SubCharacter* chara) // 0x8008A384
{
    chara->flags &= ~CharaFlag_Unk8;
}

void Chara_Flag8Set(s_SubCharacter* chara) // 0x8008A398
{
    chara->flags |= CharaFlag_Unk8;
}

void func_8008A3AC(s_SubCharacter* chara) // 0x8008A3AC
{
    if (!(chara->flags & CharaFlag_Unk8))
    {
        chara->field_44.field_0 = 0;
        func_8008A3E0(chara);
    }
}

s32 func_8008A3E0(s_SubCharacter* chara) // 0x8008A3E0
{
    s32                sp10;
    s32                sp14;
    s32                sp18;
    s_800AD4C8*        sp1C;
    s32                sp20;
    s32                sp24;
    s32                sp28;
    s32                sp2C;
    s32                sp30;
    s32                sp34;
    u32                sp38;
    s32                sp3C;
    u32                sp40;
    s32                charaId;
    s32                sp48;
    s32                sp4C;
    s32                sp50;
    s32                sp54;
    s32                sp58;
    s32                sp5C;
    s32                sp60;
    s32                sp64;
    s32                sp68;
    s32                sp6C;
    s32                sp70;
    s32                sp74;
    s32                sp78;
    s32                sp7C;
    s32                sp80;
    s32                sp84;
    s32                sp88;
    s32                sp8C;
    s32                sp90;
    s32                sp94;
    DVECTOR*           temp_s0_14;
    VECTOR3*           temp_a0;
    VECTOR3*           temp_v0_11;
    s_SubCharacter_44* temp_v0_12;
    s32                temp_s0;
    s32                temp_s0_11;
    q19_12             angle;
    s32                temp_s0_7;
    s32                temp_s0_8;
    s32                temp_s0_9;
    s32                temp_s0_10;
    s32                var_s0_2;
    s32                temp_s1_3;
    s32                temp_s1_4;
    s32                temp_s1_5;
    s32                temp_s2_2;
    s32                var_s2;
    s32                temp_v0_10;
    s32                temp_v0_4;
    s32                temp_v0_5;
    s32                temp_v0_6;
    s32                temp_v1;
    s32                var_a0_2;
    s32                var_a0_3;
    s32                temp_a1;
    s32                var_a1;
    s32                var_fp;
    s32                var_s3;
    s32                j;
    s32                var_s6;
    s32                i;
    s32                var_v1;
    s_ModelAnim*       var_s0;
    s_SubCharacter*    temp_s1_2;
    u32                temp_s1;
    s32                var_a0;
    s_AnimInfo*        anim;
    s_SubCharacter*    ptr;
    s32                temp;
    s32                temp_t3_2;
    s32                temp2;
    s32                temp3;
    s32                temp4;
    s32                temp5;
    s32                temp6;
    static s_RayTrace D_800C4728;
    static DVECTOR D_800C4748[4];
    static VECTOR3 D_800C4758[4];

    sp30 = NO_VALUE;
    Chara_Flag8Set(chara);

    sp10 = chara->field_44.field_0;
    sp14 = (u8)chara->field_44.field_2;

    if (sp10 == 0)
    {
        chara->field_44.field_4  = 0;
        chara->field_44.field_8  = 0;
        chara->field_44.field_14 = 0;
        return 0;
    }

    if (sp10 == sp30)
    {
        chara->field_44.field_8  = 0;
        chara->field_44.field_14 = 0;
        return 0;
    }

    sp18 = 0;

    sp1C = &D_800AD4C8[sp14];

    temp_s1 = sp1C->field_10;

    if (chara == &g_SysWork.playerWork.player)
    {
        var_s0 = &((s_PlayerWork*)chara)->extra.model.anim;
    }
    else
    {
        var_s0 = &chara->model.anim;
    }

    anim  = func_80044918(var_s0);
    sp28  = var_s0->time;
    sp28 -= Q12(anim->startKeyframeIdx);

    var_s0_2 = func_8008A270(sp14);
    var_a0   = func_8008A2E0(sp14);

    i   = chara->field_44.field_14;
    sp2C     = Q12(var_s0_2 + var_a0);
    var_s0_2 = Q12(var_s0_2);

    if (sp28 < i)
    {
        sp10                   = 1;
        chara->field_44.field_0 = sp10;
    }

    if (sp10 == 1)
    {
        chara->field_44.field_4 = 0;
        sp10                   = 2;
    }

    if (i < var_s0_2)
    {
        i                  = var_s0_2;
        chara->field_44.field_14 = i;
    }
    else if (sp2C < i)
    {
        i                  = sp2C;
        chara->field_44.field_14 = i;
    }

    if (sp28 < var_s0_2)
    {
        return 0;
    }

    if (g_DeltaTime != Q12(0.0f))
    {
        if (sp28 >= sp2C)
        {
            sp28 = sp2C;
            sp18 = 1;
        }

        sp20 = chara->field_44.field_C;
        sp24 = chara->field_44.field_E;

        if (temp_s1 == 3)
        {
            sp3C = chara->field_44.field_3;
            sp40 = chara->field_44.field_4;
            sp34 = *(u16*)&sp1C->field_6;

            sp54 = sp1C->field_0;

            if (sp34 != 0)
            {
                sp38 = sp1C->field_8;
                if (sp38 == 0)
                {
                    sp38 = 1;
                }
            }
            else
            {
                sp38 = 1;
            }

            sp50 = sp1C->field_B;
            sp4C = sp50 >> 4;
            sp48 = sp1C->field_A;
            sp4C--;
            sp4C &= 0xF;
            sp50  = D_800AFD1C[sp50 & 0xF];
            sp4C++;
            charaId = sp1C->charaId_9;
            sp4C = sp4C * sp50;

            if (sp34 == 0 && charaId == Chara_Harry)
            {
                if (chara->model.charaId == charaId)
                {
                    var_a0_2 = func_8007FD2C();
                }
                else
                {
                    var_a0_2 = Q12(2.0f);
                }

                if (var_a0_2 < Q12(0.5f))
                {
                    var_a0_2 = Q12(0.5f);
                }
                else if (var_a0_2 > Q12(2.0f))
                {
                    var_a0_2 = Q12(2.0f);
                }

                temp_v1 = Q12(var_a0_2 - Q12(0.5f)) / Q12(1.5f);
                var_s2  = Q12_MULT_PRECISE(temp_v1, Q12(-1.5f)) + Q12(1.75f);
                var_s2  = Q12_MULT_PRECISE(var_s2, sp48);

                if (var_s2 < 170)
                {
                    if (g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & 1)
                    {
                        var_s2 = (var_s2 + 170) / 2;
                    }

                    // @hack
                    goto j_3d8;
                j_3a8:
                    sp30 = 3;
                    goto j_584;
                j_3b0:
                    sp30 = 2;
                    goto j_584;
                j_3bc:
                    sp30    = 1;
                    var_s2 -= var_s2 / 2;
                    goto j_584;
                }
                else
                {
                    var_s2 = 170;
                }

            j_3d8:
                temp_t3_2 = sp54 / 3;
                sp30      = NO_VALUE;

                if (g_SysWork.targetNpcIdx >= 0)
                {
                    temp_s1_2 = &g_SysWork.npcs[g_SysWork.targetNpcIdx];

                    if (temp_s1_2->model.charaId >= Chara_AirScreamer)
                    {
                        do
                        {
                            if (temp_s1_2->model.charaId < Chara_LockerDeadBody)
                            {
                                temp_v0_4 = chara->position.vx - temp_s1_2->position.vx;
                                temp_v0_5 = chara->position.vy - temp_s1_2->position.vy;
                                temp_v0_6 = chara->position.vz - temp_s1_2->position.vz;

                                temp6   = Q12_MULT_PRECISE(temp_v0_4, temp_v0_4) + Q12_MULT_PRECISE(temp_v0_5, temp_v0_5);
                                temp_s0 = Q12_MULT_PRECISE(temp_v0_6, temp_v0_6) + temp6;

                                sp30 = SquareRoot12(temp_s0);

                                if (temp_s1_2->flags & CharaFlag_Unk2)
                                {
                                    temp_s0 = temp_s0 - 0x800;
                                    if (temp_s0 < 0)
                                    {
                                        var_s2 = 0;
                                    }
                                    else if (temp_s0 <= 0xFFFF)
                                    {
                                        temp_v0_10 = Q12(temp_s0);
                                        if (temp_v0_10 < 0)
                                        {
                                            temp_v0_10 += 0xFFFF;
                                        }
                                        var_s2 = Q12_MULT_PRECISE(var_s2, temp_v0_10 >> 16);
                                    }
                                }

                                if (!(g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & (1 << 0)))
                                {
                                    if (temp_t3_2 >= sp30)
                                    {
                                        if (sp30 <= Q12(2.0f))
                                        {
                                            sp30   = 0;
                                            var_s2 = 0;
                                        }
                                        else
                                        {
                                            goto j_3bc;
                                            // sp30 = 1;
                                            // var_s2 -= var_s2 / 2;
                                        }
                                    }
                                    else
                                    {
                                        goto j_3b0;
                                        // sp30 = 2;
                                    }
                                }
                                else
                                {
                                    goto j_3a8;
                                    // sp30 = 3;
                                }
                            }
                        } while (0); // @hack
                    }
                }

            j_584:
                sp48 = Q12_MULT_PRECISE(var_s2, Rng_RandQ12());

#ifdef SH_PC_PORT
                /* Free-aim (alt cameras): the PSX accuracy model scatters every
                 * shot a random angle off the aim direction (distance/state
                 * driven). Under auto-aim that read as game feel; under a
                 * crosshair it reads as "bullets don't go where I aim" — worst
                 * in first person, which has no aim assist. Cap the deviation
                 * for the PLAYER's shots in alt cameras only: handgun/rifle
                 * near-exact, shotgun keeps a fixed modest pellet cone.
                 * Classic camera is untouched. */
                {
                    extern int g_DebugThirdPersonCam;
                    if (g_DebugThirdPersonCam && chara == &g_SysWork.playerWork.player)
                    {
                        s32 cap = (WEAPON_ATTACK_ID_GET(sp14) == EquippedWeaponId_Shotgun)
                                      ? Q12_ANGLE(4.0f)
                                      : Q12_ANGLE(0.5f);
                        if (sp48 > cap)
                        {
                            sp48 = cap;
                        }
                    }
                }
#endif
            }

            var_s6 = Q12_MULT(sp4C, sp10 - 2);

            for (i = i + sp34;
                 sp3C != 0 && sp40 < sp38 && sp28 >= i;
                 i += sp34, sp40++, sp3C--)
            {
                for (j = charaId; j > 0; j--)
                {
                    temp_v0_10 = Rng_RandQ12();
                    temp_s2_2  = Q12_MULT_PRECISE(sp48, temp_v0_10);

                    temp_v0_10 = Rng_RandQ12() - Q12_ANGLE(180.0f);
                    angle  = var_s6 + Q12_MULT_PRECISE(sp50, temp_v0_10);

                    temp3     = sp20 + Q12_MULT(temp_s2_2, Math_Sin(angle));
                    temp_s0_7 = sp24 + Q12_MULT(temp_s2_2, Math_Cos(angle));
                    temp2     = Math_Cos(temp_s0_7);
                    temp_s0_8 = Math_Sin(temp_s0_7);
                    temp_s1_4 = Q12_MULT(temp_s0_8, Math_Sin(temp3));
                    temp_s0_9 = Q12_MULT(temp_s0_8, Math_Cos(temp3));

                    chara->field_44.field_48[0].vx = Q12_MULT(sp54, temp_s1_4);
                    chara->field_44.field_48[0].vy = Q12_MULT(sp54, temp2);
                    chara->field_44.field_48[0].vz = Q12_MULT(sp54, temp_s0_9);

                    var_s6 += sp4C;

                    if (chara->model.charaId == Chara_Harry)
                    {
                        func_800892A4(5);
                    }

#ifdef SH_PC_PORT
                    /* Player gun bullets only: inflate the enemy collision
                     * cylinder (func_8006EE0C) to the full visible body so any
                     * body shot lands + blood spawns where aimed. Scoped tightly
                     * to this one trace so enemy attacks / LOS keep the original
                     * tight hitbox. */
                    { extern s32 g_PcBulletHitActive; g_PcBulletHitActive = (chara == &g_SysWork.playerWork.player); }
#endif
                    temp = Ray_CharaTraceQuery(&D_800C4728, &chara->field_44.field_18, &chara->field_44.field_48[0], chara);
#ifdef SH_PC_PORT
                    { extern s32 g_PcBulletHitActive; g_PcBulletHitActive = 0; }
#endif
                    ptr  = D_800C4728.character;
#ifdef SH_PC_PORT
                    if (chara == &g_SysWork.playerWork.player) {
                        s32 tIdx = g_SysWork.targetNpcIdx;
                        s_SubCharacter* tn = (tIdx >= 0) ? &g_SysWork.npcs[tIdx] : NULL;
                        s32 reqYaw = tn ? Q12_FRACT(ratan2(tn->position.vx - chara->field_44.field_18.vx,
                                                           tn->position.vz - chara->field_44.field_18.vz) + Q12_ANGLE(360.0f)) : -1;
                    }

                    /* Bullet-hole decal: the player's bullet trace ended on
                     * world geometry (hit with no character) — target is the
                     * clipped world-space impact point, field_48[0] the
                     * bullet direction (pc_decals.c). */
                    if (temp && D_800C4728.character == NULL && chara == &g_SysWork.playerWork.player)
                    {
                        extern void Pc_DecalAddBulletImpact(const VECTOR3* pos, const VECTOR3* dir, const VECTOR3* origin);
                        Pc_DecalAddBulletImpact(&D_800C4728.target, &chara->field_44.field_48[0], &chara->field_44.field_18);
                    }
#endif

                    if (temp && ptr != NULL)
                    {
                        chara->field_44.field_48[1].vx = temp_s1_4;
                        chara->field_44.field_48[1].vy = temp2;
                        chara->field_44.field_48[1].vz = temp_s0_9;
                        func_8008B714(chara, ptr, &D_800C4728.target, 0);
                    }
                }
            }

            if (i >= sp2C)
            {
                sp18 = 1;
            }
            else
            {
                i -= sp34;
            }

            if (sp3C == 0)
            {
                i = sp28;
                sp18   = 1;
            }

            if (sp40 >= sp38)
            {
                i = sp28;
                sp18   = 1;
            }

            chara->field_44.field_14 = i;
            chara->field_44.field_4  = sp40;
            chara->field_44.field_3  = sp3C;
        }
        else
        {
            if (var_a0 <= 0)
            {
                var_a0 = 1;
            }

            if (temp_s1 == 1)
            {
                sp58 = 0;
#ifdef SH_PC_PORT
                /* Blade-weapon damage scaler. PSX added (sp28 - i)/(var_a0*4)
                 * EVERY overlap frame, where sp28 is the current anim time and
                 * `i` the previous frame's swept position, so each term is the
                 * per-frame sweep (∝ g_DeltaTime). The PC once-per-swing guard
                 * (func_8008B714) applies just ONE frame, so the dt-sized term
                 * left player blades doing almost no damage at high fps. The PSX
                 * sum telescopes to the FULL window length: Σ(sp28-i) = sp2C -
                 * var_s0_2, so the fps-independent single-hit value is
                 * (sp2C - var_s0_2)/(var_a0*4) == Q12(0.25), INDEPENDENT of where
                 * in the swing the hit lands. (Using the partial sp28-var_s0_2
                 * here made a hit that landed at window-open — e.g. the 1st of the
                 * knife's two slashes — deal ~0 while the 2nd, landing later, hit.)
                 * Applies to ENEMIES too, which it originally did not.
                 * "Enemy balance left as-is" sounded conservative but it left
                 * enemy blades with the identical defect: a Puppet Nurse knife
                 * measured base=102400 arriving as dmg=132, because sp5C came
                 * out around 5 -- one frame's sweep at PC frame rates -- and
                 * D_800AD4C8[57].field_10 == 1 puts that attack in exactly the
                 * class scaled by it (func_8008B714 multiplies by this when
                 * field_10 == 1). Enemies whose attacks are not field_10 == 1
                 * skip the multiply entirely, which is why only the nurse's
                 * knife read as doing nothing while everything else hurt.
                 * The grab drain is a separate path and was never affected. */
                sp5C = (var_s0_2 < sp2C) ? (sp2C - var_s0_2) / (var_a0 * 4) : 0;
#else
                if (i < sp28)
                {
                    sp5C = (sp28 - i) / (var_a0 * 4);
                }
                else
                {
                    sp5C = 0;
                }
#endif
            }
            else
            {
                sp58 = 1;
                sp5C = 0x1000;
            }

            if (sp10 == 2)
            {
                func_8008B15C(chara);
                sp10 = 3;
            }

            temp_s0_10 = chara->field_44.field_12;
            temp_s1_5  = chara->field_44.field_10;

            sp60 = chara->field_44.field_24[2].vx;
            sp64 = chara->field_44.field_24[2].vy;
            sp68 = chara->field_44.field_24[2].vz;

            sp6C = chara->field_44.field_18.vx;
            sp70 = chara->field_44.field_18.vy;
            sp74 = chara->field_44.field_18.vz;

            sp7C = Math_Cos(temp_s0_10);
            sp80 = Math_Sin(temp_s0_10);

            sp78 = Q12_MULT(sp80, Math_Sin(temp_s1_5));
            sp80 = Q12_MULT(sp80, Math_Cos(temp_s1_5));

            sp88 = Math_Cos(sp24);
            sp8C = Math_Sin(sp24);

            sp84 = Q12_MULT(sp8C, Math_Sin(sp20));
            sp8C = Q12_MULT(sp8C, Math_Cos(sp20));
            sp90 = 0;
            sp94 = 0;

            for (var_s2 = 4, var_fp = 0, var_s3 = 0, i = 0, var_s6 = 0;
                 var_s2 > 0;
                 sp90  += sp68,
                 sp94   += sp64,
                 var_fp += sp60,
                 var_s3 += sp80,
                 i += sp7C,
                 var_s6 += sp78,
                 var_s2--)
            {
                var_a0_3 = (sp84 * var_s2) + var_s6;
                if (var_a0_3 < 0)
                {
                    var_a0_3 += 3;
                }
                temp5 = var_a0_3 >> 2;

                var_a1 = (sp88 * var_s2) + i;
                if (var_a1 < 0)
                {
                    var_a1 += 3;
                }
                temp4 = var_a1 >> 2;

                var_s0_2 = (sp8C * var_s2) + var_s3;
                if (var_s0_2 < 0)
                {
                    var_s0_2 += 3;
                }
                temp_s0_11 = var_s0_2 >> 2;

                temp_s0 = ratan2(temp5, temp_s0_11);

                D_800C4748[var_s2 - 1].vy = ratan2(SquareRoot0(SQUARE(temp5) + SQUARE(temp_s0_11)), temp4);
                D_800C4748[var_s2 - 1].vx = temp_s0;

                temp_a1 = var_s2 - 1;
                temp_a0 = &D_800C4758[temp_a1];

                var_v1 = (sp6C * var_s2) + var_fp;
                if (var_v1 < 0)
                {
                    var_v1 += 3;
                }
                temp_a0->vx = var_v1 >> 2;

                temp_v0_10 = (sp70 * var_s2) + sp94;
                if (temp_v0_10 < 0)
                {
                    temp_v0_10 += 3;
                }
                temp_a0->vy = temp_v0_10 >> 2;

                temp_v0_10 = (sp74 * var_s2) + sp90;
                if (temp_v0_10 < 0)
                {
                    temp_v0_10 += 3;
                }
                temp_a0->vz = temp_v0_10 >> 2;
            }

            chara->field_44.field_10 = chara->field_44.field_C;
            chara->field_44.field_12 = chara->field_44.field_E;

            for (var_s2 = 0, temp_s1_3 = 4; (temp_s1_3 > 0) && (var_s2 == 0); temp_s1_3--)
            {
                temp_v0_11                 = &D_800C4758[4 - temp_s1_3];
                chara->field_44.field_18.vx = temp_v0_11->vx;
                chara->field_44.field_18.vy = temp_v0_11->vy;

                temp_s0_14                 = &D_800C4748[4 - temp_s1_3];
                chara->field_44.field_18.vz = temp_v0_11->vz;

                func_8008B1DC(chara, temp_s0_14->vx, temp_s0_14->vy);
#ifdef SH_PC_PORT
                { extern int g_RayLineCombat; g_RayLineCombat = 1; }
#endif
                if (func_8008BF84(chara, temp_s0_14->vx, sp1C, sp5C) != 0)
                {
                    var_s2 = sp58;
                    sp18  |= var_s2;
                }
#ifdef SH_PC_PORT
                { extern int g_RayLineCombat; g_RayLineCombat = 0; }
#endif
            }

            i     = sp28;
            temp_v0_12 = &chara->field_44;

            temp_v0_12->field_18.vx       = sp6C;
            chara->field_44.field_24[2].vx = sp6C;
            temp_v0_12->field_18.vy       = sp70;
            chara->field_44.field_24[2].vy = sp70;
            temp_v0_12->field_18.vz       = sp74;
            chara->field_44.field_24[2].vz = sp74;
        }

        if (sp18 != 0)
        {
            chara->field_44.field_0 = NO_VALUE;

            if (chara->model.charaId == Chara_Harry)
            {
                switch (sp14)
                {
                    case 32:
                    case 33:
                        if (sp30 != NO_VALUE)
                        {
                            if (g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & (1 << 0))
                            {
                                var_s0_2 = 3;
                            }
                            else
                            {
                                var_s0_2 = sp30;
                            }
                        }
                        else
                        {
                            var_s0_2 = 5;
                        }
                        break;

                    case 34:
                        var_s0_2 = 5;
                        break;

                    case 35:
                        var_s0_2 = 4;
                        break;

                    case 2:
                    case 5:
                    case 6:
                    case 12:
                    case 15:
                    case 16:
                    case 22:
                    case 25:
                    case 26:
                        var_s0_2 = 7;
                        break;

                    case 8:
                    case 9:
                        var_s0_2 = NO_VALUE;
                        break;

                    default:
                        var_s0_2 = 6;
                        break;
                }

                if (var_s0_2 != NO_VALUE)
                {
                    func_8009151C(var_s0_2, chara->field_44.field_8 != 0, func_8007FD2C());
                }
            }
        }
        else
        {
            chara->field_44.field_0  = sp10;
            chara->field_44.field_14 = i;
        }
    }

    return chara->field_44.field_8;
}

void func_8008B15C(s_SubCharacter* chara) // 0x8008B15C
{
    s32 temp_s2;
    s32 temp_s3;
    s32 i;

    temp_s3 = chara->field_44.field_C;
    temp_s2 = chara->field_44.field_E;

    chara->field_44.field_10 = temp_s3;
    chara->field_44.field_12 = temp_s2;

    for (i = 1; i > 0; i--)
    {
        func_8008B1DC(chara, temp_s3, temp_s2);
        chara->field_44.field_24[2] = chara->field_44.field_18;
    }
}

void func_8008B1DC(s_SubCharacter* chara, q19_12 angle0, q19_12 angle1) // 0x8008B1DC
{
    s32                temp_s0;
    q19_12             sinAngle1;
    q19_12             cosAngle1;
    s32                temp_s3;
    s32                temp_v1_2;
    s32                i;
    s32                temp_s2;
    s32                idx46;
    s32                vx;
    s32                vy;
    s32                vz;
    s32                vx2;
    s32                vy2;
    s32                vz2;
    s32                vx3;
    s32                vy3;
    s32                vz3;
    s_800AD4C8*        ptr;
    s_SubCharacter_44* base;

    base  = &chara->field_44;
    idx46 = chara->field_44.field_2;

    for (i = 0; i >= 0; i--)
    {
        vx = base->field_48[i].vx;
        vy = base->field_48[i].vy;
        vz = base->field_48[i].vz;

        base->field_48[i + 1].vx = vx;
        base->field_48[i + 1].vy = vy;
        base->field_48[i + 1].vz = vz;

        vx2 = base->field_24[i].vx;
        vy2 = base->field_24[i].vy;
        vz2 = base->field_24[i].vz;

        base->field_24[i + 1].vx = vx2;
        base->field_24[i + 1].vy = vy2;
        base->field_24[i + 1].vz = vz2;
    }

    ptr = &D_800AD4C8[idx46];

    temp_s2 = ptr->field_0;
    temp_s0 = ptr->field_2;

    vx3 = chara->field_44.field_18.vx;
    vy3 = chara->field_44.field_18.vy;
    vz3 = chara->field_44.field_18.vz;

    vx2 = vx3;
    vy2 = vy3;
    vz2 = vz3;

    cosAngle1 = Math_Cos(angle1);
    sinAngle1 = Math_Sin(angle1);

    temp_s3   = Q12_MULT(sinAngle1, Math_Sin(angle0));
    temp_v1_2 = Q12_MULT(sinAngle1, Math_Cos(angle0));

    temp_s2 -= temp_s0;

    vx2                          += Q12_MULT(temp_s0, temp_s3);
    chara->field_44.field_24[0].vx = vx2;

    vy2                          += Q12_MULT(temp_s0, cosAngle1);
    chara->field_44.field_24[0].vy = vy2;

    vz2                          += Q12_MULT(temp_s0, temp_v1_2);
    chara->field_44.field_24[0].vz = vz2;

    vx                            = Q12_MULT(temp_s2, temp_s3);
    chara->field_44.field_48[0].vx = vx;

    vy                            = Q12_MULT(temp_s2, cosAngle1);
    chara->field_44.field_48[0].vy = vy;

    vz                            = Q12_MULT(temp_s2, temp_v1_2);
    chara->field_44.field_48[0].vz = vz;
}

void func_8008B398(void) // 0x8008B398
{
    func_8008B3E4(Q8(0.0f));
    func_8008B438(0, 0, 0);
    func_8008B438(1, 0, 0);
    func_8008B40C(0, 0);
}

void func_8008B3E4(q23_8 vol) // 0x8008B3E4
{
    func_8008B474(0, vol, 0);
}

void func_8008B40C(q23_8 vol, s32 soundType) // 0x8008B40C
{
    func_8008B474(3, vol, soundType);
}

void func_8008B438(s32 arg0, q23_8 vol, s32 soundType) // 0x8008B438
{
    bool cond;

    cond = arg0 != 0;
    if (func_8008B474(2 - cond, vol, soundType))
    {
        func_80089314(cond);
    }
}

bool func_8008B474(s32 arg0, q23_8 vol, s32 soundType) // 0x8008B474
{
    s32 unkVol;
    s32 cond;
    u16 sfxId;

    unkVol = 0;
    sfxId = 0;
    switch (arg0)
    {
        case 0:
            sfxId = Sfx_Unk1300;
            unkVol = g_SysWork.field_2760;
            soundType = 0;
            break;

        case 1:
            sfxId = Sfx_Unk1301;
            unkVol = g_SysWork.field_275C;
            break;

        case 2:
            sfxId = Sfx_Unk1302;
            unkVol = g_SysWork.field_275C;
            break;

        case 3:
            sfxId = Sfx_Unk1303;
            unkVol = g_SysWork.field_2764;
            break;
    }

    cond = unkVol == Q12(0.0f);

    if (g_DeltaTime == Q12(0.0f))
    {
        vol = 0;
    }

    if (vol >= 0)
    {
        if (vol != 0)
        {
            if (vol > Q8_CLAMPED(1.0f))
            {
                unkVol = Q12(511.0f);
            }
            else
            {
                unkVol = Q12(vol) + Q12(256.0f);
            }
        }
        else
        {
            unkVol = 0;
        }
    }
    else
    {
        unkVol -= g_DeltaTime << 9;
        if (unkVol < 0)
        {
            unkVol = 0;
        }
    }

    if (unkVol == 0)
    {
        Sd_SfxStop(sfxId);
    }
    else if (cond)
    {
        // NOTE: func_8005DC1C calls func_8005DC3C. `soundType` is `pitch` when calling `func_8005DC3C` directly.
        if (unkVol > Q12(256.0f))
        {
            func_8005DC1C(sfxId, &g_SysWork.playerWork.player.position, FP_FROM(unkVol - Q12(256.0f), Q12_SHIFT), soundType);
        }
        else
        {
            func_8005DC1C(sfxId, &g_SysWork.playerWork.player.position, Q8_CLAMPED(0.0f), soundType);
        }
    }
    else
    {
        if (unkVol > Q12(256.0f))
        {
            func_8005DC3C(sfxId, &g_SysWork.playerWork.player.position, FP_FROM(unkVol - Q12(256.0f), Q12_SHIFT), 4, soundType);
        }
        else
        {
            func_8005DC3C(sfxId, &g_SysWork.playerWork.player.position, 0, 4, soundType);
        }
    }

    switch (arg0)
    {
        case 0:
            g_SysWork.field_2760 = unkVol;
            break;

        case 1:
        case 2:
            g_SysWork.field_275C = unkVol;
            break;

        case 3:
            g_SysWork.field_2764 = unkVol;
    }

    return unkVol > Q12(256.0f);
}

void func_8008B664(VECTOR3* pos, u32 caseVar) // 0x8008B664
{
    s32 sfxId;

    sfxId = 0;
    switch (caseVar)
    {
        case 0:
        case 6:
        case 10:
        case 16:
        case 20:
        case 26:
            sfxId = Sfx_Unk1297;
            break;

        case 1:
        case 4:
        case 7:
        case 11:
        case 14:
        case 17:
        case 21:
        case 24:
        case 27:
            sfxId = Sfx_Unk1296;
            break;

        case 32:
        case 33:
        case 34:
            sfxId = Sfx_Unk1286;
            break;

        case 2:
        case 5:
        case 15:
        case 25:
            if (g_SysWork.field_275C > Q12(256.0f))
            {
                func_8008B3E4(Q8(0.5f));
                break;
            }

        case 8:
        case 9:
            sfxId = Sfx_Unk1316;
            break;

        case 35:
    }

    if (sfxId != 0)
    {
        func_8005DC1C(sfxId, pos, Q8(0.75f), 0);
    }
}

s32 func_8008B714(s_SubCharacter* attacker, s_SubCharacter* target, VECTOR3* arg2, s32 arg3) // 0x8008B714
{
    s32         sp10;
    s32         sp14;
    s32         var_a3;
    u32         var_s0;
    q19_12      offsetX;
    q19_12      offsetY;
    q19_12      offsetZ;
    q20_12      damageAmount;
    s32         var_v1;
    u32         var_s7;
    s32         var_v0;
    s32         weaponAttack;
    s32         var_a2;
    s32         temp;
    s64         new_var;
    s32         temp2;
    s32         x0;
    s32         y0;
    s32         z0;
    s32         x1;
    s32         y1;
    s32         z1;
    s32         x2;
    s32         y2;
    s32         z2;
    s_800AD4C8* temp_fp;

#ifdef SH_PC_PORT
    /* Console NOCOLLIDE: attacks pass straight through. The ray/hit-volume
     * queries already skip a phased character (they share
     * Collision_CollidableCharasGet), so this covers whatever resolves to an
     * attack without a ray -- grabs and proximity hits. 0 is "connected with
     * nothing", which is what the caller at ~2353 tests. */
    if (Pc_Pick_IsNoCollide(target))
        return 0;
#endif

    weaponAttack = (u8)attacker->field_44.field_2;
    temp_fp      = &D_800AD4C8[weaponAttack];
    offsetY       = temp_fp->field_10;
    sp14         = attacker->field_44.field_8;
    offsetZ       = arg3;

    if (target == &g_SysWork.playerWork.player)
    {
        sp10             = NO_VALUE;
#ifdef SH_PC_PORT
        /* PSX computed the attacker's NPC index via magic-constant division
         * (* -0x6EB3E453 >> 3) that bakes in the PSX sizeof(s_SubCharacter);
         * wrong on 64-bit. C pointer subtraction yields the index directly. */
        target->field_40 = (s32)(attacker - g_SysWork.npcs);
#else
        target->field_40 = (((s32)((uintptr_t)((u8*)attacker - sizeof(s_PlayerWork)) - (uintptr_t)target) * -0x6EB3E453) >> 3);
#endif
    }
    else
    {
#ifdef SH_PC_PORT
        /* PSX hashed the target's NPC index via magic-constant division
         * (* -0x6EB3E453 >> 3) that bakes in the PSX sizeof(s_SubCharacter),
         * producing a garbage shift on 64-bit (where the struct is larger).
         * sp10 is `1 << npcIndex`, tested against attacker->field_44.field_8.
         * C pointer subtraction gives the index directly and portably. */
        sp10 = 1 << (s32)(target - g_SysWork.npcs);
#else
        sp10 = 1 << (((s32)((u32)((u8*)target - sizeof(s_PlayerWork)) - (u32)&g_SysWork.playerWork) * -0x6EB3E453) >> 3);
#endif

        if (sp14 & sp10)
        {
            switch (weaponAttack)
            {
                case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Tap):
                case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Hold):
                case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Multitap):
                case WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Tap):
                    if (g_SysWork.field_275C > Q12(256.0f))
                    {
                        func_8008B3E4(Q8(0.5f));
                    }
                    break;
            }
        }
        else
        {
            switch (offsetY)
            {
                case 2:
                    func_800892A4(6);
                    break;

                case 1:
                    func_800892A4(7);
                    break;

                case 3:
                    break;
            }

            if (target->model.charaId == Chara_Padlock)
            {
                func_8005DC1C(Sfx_Unk1392, arg2, Q8(0.5f), 0);
            }
            else
            {
                func_8008B664(arg2, weaponAttack);
            }
        }
    }

    var_s0 = Q12(temp_fp->field_4);


    switch (weaponAttack)
    {
        case WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Hold):
        case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Hold):
        case WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Multitap):
        case WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Multitap):
            if (func_8008A35C(temp_fp, attacker->field_44.field_14) == 0)
            {
                var_s0 = 0;
            }

            if (g_SysWork.field_275C > Q12(256.0f))
            {
                var_s0 += Q12(200.0f);
            }
            break;

        case WEAPON_ATTACK(EquippedWeaponId_HyperBlaster, AttackInputType_Tap):
            switch (Game_HyperBlasterBeamColorGet())
            {
                case 0:
                    break;

                case 1:
                    var_s0 += var_s0 * 2;
                    break;

                case 2:
                    var_s0 += Rng_RandQ12() * 50;
                    var_s0 *= 5;
                    break;
            }
            break;

        case WEAPON_ATTACK(EquippedWeaponId_Kick, AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_Stomp, AttackInputType_Tap):
            if (target->flags & CharaFlag_Unk2)
            {
                var_s0 = Q12(1000.0f);
            }
            break;
    }

    var_s7  = temp_fp->field_C;
    temp2   = Rng_RandQ12();
    new_var = var_s0;
    var_v1  = Q12(4.5f);
    var_v1  = var_v1 - temp2;

    if (var_v1 < 0)
    {
        var_v1 += 3;
    }

    damageAmount = Q12_MULT_PRECISE(new_var, var_v1 >> 2);

    switch (weaponAttack)
    {
        case WEAPON_ATTACK(EquippedWeaponId_Handgun,      AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_HuntingRifle, AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_Shotgun,      AttackInputType_Tap):
        case WEAPON_ATTACK(EquippedWeaponId_HyperBlaster, AttackInputType_Tap):
        case NO_VALUE:
            offsetX = attacker->field_44.field_48[1].vx;
            offsetY   = attacker->field_44.field_48[1].vy;
            offsetZ   = attacker->field_44.field_48[1].vz;

            if (weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Shotgun, AttackInputType_Tap))
            {
                if (sp14 & sp10)
                {
                    var_s7 = 0;
                }

                offsetZ   = 0;
                offsetY   = 0;
                offsetX = 0;
            }
            break;

        default:
            if (target != &g_SysWork.playerWork.player && !(target->flags & CharaFlag_Hit))
            {
                damageAmount *= 4;
            }

            if (offsetY == 1)
            {
                damageAmount = Q12_MULT_PRECISE(damageAmount, offsetZ);
                var_s7 = Q12_MULT_PRECISE(var_s7, offsetZ);
            }

            // TODO: Doesn't match.
            //if (weaponAttack > WEAPON_ATTACK(EquippedWeaponId_Axe,       AttackInputType_Tap) &&
            //    weaponAttack < WEAPON_ATTACK(EquippedWeaponId_SteelPipe, AttackInputType_Hold))
            if (weaponAttack > 7 &&
                weaponAttack < 10)
            {
                offsetX = attacker->field_44.field_48[0].vx;
                offsetY   = 0;
                offsetZ   = attacker->field_44.field_48[0].vz;
            }
            else
            {
                x0 = attacker->field_44.field_24[2].vx;
                y0 = attacker->field_44.field_24[2].vy;
                z0 = attacker->field_44.field_24[2].vz;

                x1 = attacker->field_44.field_48[2].vx;
                y1 = attacker->field_44.field_48[2].vy;
                z1 = attacker->field_44.field_48[2].vz;

                x2 = attacker->field_44.field_48[0].vx;
                y2 = attacker->field_44.field_48[0].vy;
                z2 = attacker->field_44.field_48[0].vz;

                x1 += x0;
                y1 += y0;
                z1 += z0;

                x0 = attacker->field_44.field_24[0].vx;
                y0 = attacker->field_44.field_24[0].vy;
                z0 = attacker->field_44.field_24[0].vz;

                x2 += x0;
                y2 += y0;
                z2 += z0;

                offsetX = x2 - x1;
                offsetY   = y2 - y1;
                offsetZ   = z2 - z1;
            }

            var_v1 = func_8008A058(func_80080540(offsetX, offsetY, offsetZ));
            if (var_v1 >= 64)
            {
                if (var_v1 >= Q12(4096.0f))
                {
                    var_v1 /= Q12(1.0f);
                    offsetX /= Q12(1.0f);
                    offsetY /= Q12(1.0f);
                    offsetZ /= Q12(1.0f);
                }

                var_v1  = Q12(4096.0f) / var_v1;
                offsetX = Q12_MULT_PRECISE(offsetX, var_v1);
                offsetY = Q12_MULT_PRECISE(offsetY, var_v1);
                offsetZ = Q12_MULT_PRECISE(offsetZ, var_v1);
            }
            break;
    }

#ifdef SH_PC_PORT
    /* One hit per swing per target. The per-swing already-hit bitmask
     * (sp14 & sp10, reset at swing start in func_8008A0E4) is computed
     * above but PSX applied base damage unconditionally. At 30fps the
     * active-hitbox window is only a couple frames so that read as a
     * single hit; on PC the window spans the whole swing, so this
     * re-applies damage AND knockback every frame for dozens of frames.
     *
     * This bites in BOTH directions:
     *   - player -> enemy: enemies die in one swing and the hurt SFX
     *     (e.g. PuppetNurse_DamageHandle, played every frame damage>0)
     *     machine-guns.
     *   - enemy -> player: Harry loses health every frame the enemy's
     *     hitbox overlaps him (the player damage handler subtracts and
     *     clears damage.amount per frame), so a single enemy swing does
     *     ~Nframes x damage and N x knockback at high fps. For the player
     *     target sp10 == NO_VALUE (-1), so (sp14 & sp10) == sp14 is a
     *     valid "already hit this swing" test and sp14 |= sp10 latches it.
     *
     * Skip re-application once this target is already marked hit this
     * swing, for either direction. Chainsaw/RockDrill are intentionally
     * continuous-damage weapons (player-only) and stay exempt; enemies
     * never wield them so the player-damage path is always gated. */
    {
        int _continuous =
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Tap)      ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Hold)     ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Chainsaw,  AttackInputType_Multitap) ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Tap)       ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Hold)      ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_RockDrill, AttackInputType_Multitap);
        /* Ranged guns fire their ENTIRE pellet spread in a single frame: in
         * func_8008A3E0 the outer sweep cap sp38 == 1, so after the first call
         * field_4 (sp40) exhausts and no further pellets emit. The shotgun's
         * inner loop fires charaId (>1) pellets that frame, each a SEPARATE
         * func_8008B714 hit on the same target — they must all count, unlike a
         * melee hitbox re-applying across frames. The one-hit-per-swing guard
         * wrongly zeroed pellets 2..N, cutting shotgun damage to ~1/pelletCount
         * (Split Head needed 20-30 shots to open its mouth instead of ~5). It's
         * fps-independent (one-frame burst), so exempting the guns is faithful;
         * single-pellet guns (handgun/rifle, charaId==1) are unaffected. */
        int _rangedGun =
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Handgun,      AttackInputType_Tap) ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_HuntingRifle, AttackInputType_Tap) ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Shotgun,      AttackInputType_Tap) ||
            weaponAttack == WEAPON_ATTACK(EquippedWeaponId_HyperBlaster, AttackInputType_Tap);
        if ((sp14 & sp10) && !_continuous && !_rangedGun)
        {
            damageAmount = Q12(0.0f);
            var_s7       = 0;
        }
    }
#endif

#ifdef SH_PC_PORT
    /* [MELEEDMG] diagnostic: player melee hit on an enemy. base = table damage
     * (D_800AD4C8[weaponAttack].field_4); dmg = after the one-hit-per-swing guard.
     * base>0 with dmg==0 and alreadyHit=1 means the per-swing bitmask zeroed it. */
    /* The same numbers for a hit ON the player. The nurse knife reaches here with
     * a correct id (57/58) and a non-zero table damage (field_4 0x19/0x21), so if
     * the player still takes nothing this says which step drops it -- and if the
     * line never appears at all, the hit is not reaching this function and the
     * fault is in detection, not damage. */
    if (target == &g_SysWork.playerWork.player)
    {
        static int s_plrDmgLogs = 0;

        if (s_plrDmgLogs < 40)
        {
            s_plrDmgLogs++;
            SH_DBG("[PLRDMG] wa=%d base=%d dmg=%d sp14=0x%X sp10=0x%X alreadyHit=%d attacker=%d",
                   weaponAttack, (int)var_s0, (int)damageAmount, (unsigned)sp14, (unsigned)sp10,
                   (int)((sp14 & sp10) != 0), attacker->model.charaId);
        }
    }

    if (target != &g_SysWork.playerWork.player && (u8)weaponAttack < 30u)
        SH_DBG("[MELEEDMG] wa=%d base=%d dmg=%d sp14=0x%X sp10=0x%X alreadyHit=%d chara=%d\n",
               weaponAttack, (int)var_s0, (int)damageAmount, (unsigned)sp14, (unsigned)sp10,
               (int)((sp14 & sp10) != 0), target->model.charaId);
#endif

    if (damageAmount != Q12(0.0f))
    {
        target->damage.amount += damageAmount;
    }

    if (var_s7 != 0)
    {
        temp              = Q12_MULT_PRECISE(var_s7, offsetX);
        target->damage.position.vx += temp;
        temp              = Q12_MULT_PRECISE(var_s7, offsetY);
        target->damage.position.vy += temp;
        temp              = Q12_MULT_PRECISE(var_s7, offsetZ);
        target->damage.position.vz += temp;
    }

    target->attackReceived = weaponAttack;
    sp14                     |= sp10;
    attacker->field_44.field_8 = sp14;

    if (damageAmount | var_s7)
    {
        var_a2 = temp_fp->field_12;


        if (var_a2 > 0 && var_a2 < 8)
        {
            var_a3 = NO_VALUE;

            switch (target->model.charaId)
            {
                case Chara_Harry:
                    if (target->health >= Q12(0.0f))
                    {
                        var_a3 = 1;
                    }
                    break;

                case Chara_AirScreamer:
                case Chara_NightFlutter:
                    var_a3 = 2;
                    break;

                case Chara_Stalker:
                    var_a3 = 4;
                    break;

                case Chara_LarvalStalker:
                case Chara_GreyChild:
                case Chara_Mumbler:
                    var_a3 = 3;
                    break;

                case Chara_Creeper:
                    var_a3 = 5;
                    break;

                case Chara_Groaner:
                case Chara_Wormhead:
                    var_a3 = 6;
                    break;

                case Chara_SplitHead:
                    var_a3 = 7;
                    break;

                case Chara_HangedScratcher:
                    var_a3 = 8;
                    break;

                case Chara_Floatstinger:
                case Chara_Twinfeeler:
                    var_a3 = 10;
                    break;

                case Chara_Romper:
                    var_a3 = 9;
                    break;

                case Chara_PuppetNurse:
                case Chara_PuppetDoctor:
                    var_a3 = 11;
                    break;

                case Chara_Bloodsucker:
                    var_a3 = 12;
                    var_a2 = 1;
                    break;

                case Chara_Incubus:
                case Chara_Unknown23:
                case Chara_Incubator:
                    if (!(target->flags & CharaFlag_Hit))
                    {
                        if (weaponAttack == WEAPON_ATTACK(EquippedWeaponId_Shotgun, AttackInputType_Tap))
                        {
                            var_a2 = 4;
                        }
                        else
                        {
                            var_a2 = 7;
                        }
                    }

                default:
                    var_a3 = 16;
                    break;

                case Chara_Padlock:
                    var_a3 = NO_VALUE;
                    break;
            }

            if (var_a3 >= 0)
            {
#ifdef SH_PC_PORT
                /* Skip F6B0 when target is already dead. Log shows
                 * Harry can keep slashing AS body after death (player
                 * stays in attack anim near corpse, attackReceived=10
                 * each frame, target->health=0). Each F6B0 call spawns
                 * 2-3 state-1 blood particles + 1 ground decal. With
                 * the corpse collapsed near camera the particle z gets
                 * very small and the sizing math overflows producing
                 * giant garbage prims (logged field_14C=-84049). That
                 * was the source of the giant black/blue walls AND the
                 * OT corruption around the body. Skip the spawn entirely
                 * when target is already <= 0 HP — no point spraying
                 * blood from a corpse anyway. */
                if (target->health <= Q12(0.0f) && target->model.charaId != Chara_Harry) {
                    static int _deadSkipLogN = 0;
                    if (_deadSkipLogN < 30) {
                        _deadSkipLogN++;
                    }
                } else {
                    func_8005F6B0(target, arg2, var_a2, var_a3);
                }
#else
                func_8005F6B0(target, arg2, var_a2, var_a3);
#endif
            }
        }
    }

    return sp10;
}

s32 func_8008BF84(s_SubCharacter* chara, q19_12 angle, s_800AD4C8* arg2, s32 arg3) // 0x8008BF84
{
#ifdef SH_PC_PORT
    q19_12           atkScale;
    q19_12           tgtScale = Q12(1.0f);
#endif
    s_SubCharacter*  chara1;
    s32              sp14;
    s32              sp18;
    s32              i;
    q19_12           sinAngle;
    q19_12           cosAngle;
    s32              countX;
    s32              countY;
    s32              coundZ;
    s32              sp34;
    s32              sp38;
    s32              sp3C;
    s32              sp40;
    s32              sp44;
    s32              sp48;
    s32              sp4C;
    q19_12           posX;
    q19_12           posZ;
    s32              sp58;
    s32              sp5C;
    s32              temp_s5;
    s32              temp_s6;
    q19_12           temp_a0;
    s32              temp_a0_2;
    s32              temp_a0_3;
    s32              temp_lo_5;
    s32              temp_s0;
    s32              temp_s1;
    s32              temp_s2;
    q19_12           temp_s3;
    s32              temp_t2;
    s32              j;
    q19_12           temp_t4;
    s32              temp_t4_2;
    s32              temp_t5;
    s32              angle1;
    s32              temp_v0_6;
    s32              temp_v0_7;
    s32              temp_v0_8;
    q19_12           var_a1_2;
    s32              var_fp;
    s32              var_s1;
    q19_12           var_s7;
    s32              var_t1;
    s32              var_t2;
    s32              var_v0;
    s32              var_v0_3;
    s32              var_v0_6;
    s32              var_v1;
    s32              temp_a2;
    u16              temp_v1;
    q19_12           posY;
    s32              temp4;
    s_SubCharacter*  chara0;
    static VECTOR3 D_800C4788[4];
    static VECTOR3 D_800C47B8;
    static s32 __pad_bss_800C47C4;
    static VECTOR3 D_800C47C8[2];
    static s32 __pad_bss_800C4E0[2];
    static VECTOR3 D_800C47E8;
    static s32 __pad_bss_800C4F4;
    static s_RayState D_800C47F8;

    countX = chara->field_44.field_24[0].vx;
    countY = chara->field_44.field_24[0].vy;
    coundZ = chara->field_44.field_24[0].vz;

    sinAngle = Math_Sin(angle);
    cosAngle = Math_Cos(angle);

    D_800C4788[0].vx = Q12(0.0f);
    D_800C4788[0].vy = Q12(0.0f);
    D_800C4788[0].vz = Q12(0.0f);

    sp34   = chara->field_44.field_48[0].vx;
    var_fp = chara->field_44.field_48[0].vz;

    sp44 = 0;
    sp38 = 0;
    sp48 = 0;
    sp3C = 0;
    sp4C = 0;
    sp40 = 0;

    var_s7           = chara->field_44.field_48[0].vy;
#ifdef SH_PC_PORT
    /* Console SCALE: a resized attacker swings from where its model reaches,
     * so the attack point offset and the box around it scale with it. */
    atkScale = Pc_Pick_CollScale(chara);
    if (atkScale != Q12(1.0f))
    {
        sp34   = Q12_MULT_PRECISE(sp34,   atkScale);
        var_fp = Q12_MULT_PRECISE(var_fp, atkScale);
        var_s7 = Q12_MULT_PRECISE(var_s7, atkScale);
    }
#endif
    D_800C4788[1].vy = var_s7;

    temp_t4          = Q12_MULT_PRECISE(sp34, cosAngle) - Q12_MULT_PRECISE(var_fp, sinAngle);
    D_800C4788[1].vx = temp_t4;

    temp_a0          = Q12_MULT_PRECISE(sp34, sinAngle) + Q12_MULT_PRECISE(var_fp, cosAngle);
    D_800C4788[1].vz = temp_a0;

    temp4 = var_s7;

    if (temp_t4 > 0)
    {
        sp38 = temp_t4;
    }
    else if (temp_t4 < 0)
    {
        sp44 = temp_t4;
    }

    if (sp3C < temp4)
    {
        sp3C = temp4;
    }
    else if (temp4 < sp48)
    {
        sp48 = temp4;
    }

    if (sp40 < temp_a0)
    {
        sp40 = temp_a0;
    }
    else if (temp_a0 < sp4C)
    {
        sp4C = temp_a0;
    }

    temp_v1   = *(u16*)&arg2->field_6;
    temp_a0_2 = *(u16*)&arg2->field_8;
    temp_a2   = *(u16*)&arg2->field_A;
#ifdef SH_PC_PORT
    if (atkScale != Q12(1.0f))
    {
        temp_v1   = Q12_MULT_PRECISE(temp_v1,   atkScale);
        temp_a0_2 = Q12_MULT_PRECISE(temp_a0_2, atkScale);
        temp_a2   = Q12_MULT_PRECISE(temp_a2,   atkScale);
    }
#endif

    var_v0    = (sp38 - sp44);
    temp_v0_7 = (sp3C - sp48);
    var_v0_6  = (sp40 - sp4C);

    if (var_v0 < temp_v1)
    {
        sp38 += temp_v1 >> 1;
        sp44 -= temp_v1 >> 1;
    }

    if (temp_v0_7 < temp_a0_2)
    {
        sp3C += temp_a0_2 >> 1;
        sp48 -= temp_a0_2 >> 1;
    }

    if (var_v0_6 < temp_a2)
    {
        sp40 += temp_a2 >> 1;
        sp4C -= temp_a2 >> 1;
    }

    if (chara == &g_SysWork.playerWork.player)
    {
#ifdef SH_PC_PORT
        /* PSX: (u8*)chara + sizeof(s_PlayerWork) — relies on npcs[] sitting
         * exactly sizeof(s_PlayerWork) after the player. On 64-bit the struct
         * grows (8-byte pointers) and alignment padding can be inserted between
         * playerWork and npcs[], so the raw offset misses npcs[0] and Harry's
         * melee scans garbage → never hits enemies. npcs[0] is the real intent. */
        chara0 = &g_SysWork.npcs[0];
#else
        chara0 = (u8*)chara + sizeof(s_PlayerWork);
#endif
        var_v0 = 6;
        var_v1 = 1;
    }
    else
    {
        chara0 = &g_SysWork.playerWork.player;
        var_v0 = 1;
        var_v1 = -1;
    }

    sp18 = var_v1;
    chara1 = chara0;
    sp14 = 0;

    posX = chara->position.vx;
    posZ = chara->position.vz;

    posY  = chara->position.vy;
    posY += chara->collision.box.top;

    D_800C47C8[0].vx = posX;
    D_800C47C8[0].vy = posY;
    D_800C47C8[0].vz = posZ;

    for (i = var_v0; i > 0; i--, chara1++, sp18 *= 2)
    {
        if (g_SysWork.sysState == SysState_GameOver ||
            g_SysWork.playerWork.player.health <= Q12(0.0f) ||
            chara1 == chara ||
            chara1->model.charaId == Chara_None ||
            chara1->health < Q12(0.0f) ||
            !chara1->collision.state)
        {
            continue;
        }

        D_800C47E8.vx = chara1->position.vx + chara1->collision.shapeOffsets.box.vx;
        D_800C47E8.vy = chara1->position.vy;
        D_800C47E8.vz = chara1->position.vz + chara1->collision.shapeOffsets.box.vz;
#ifdef SH_PC_PORT
        /* Reject range has to grow with whichever body got bigger, or the
         * fine test below never runs for a scaled pair. */
        tgtScale = Pc_Pick_CollScale(chara1);
        {
            q19_12 reach = (atkScale > tgtScale) ? atkScale : tgtScale;
            if (reach < Q12(1.0f))
                reach = Q12(1.0f);
            if (Math_Distance2dGet(&chara->position, &D_800C47E8) >
                Q12_MULT_PRECISE(Q12(3.0f), reach))
            {
                continue;
            }
        }
#else
        if (Math_Distance2dGet(&chara->position, &D_800C47E8) > Q12(3.0f))
        {
            continue;
        }
#endif

        temp_s1 = chara1->position.vx;
        var_v1  = chara1->position.vy;
        temp_s2 = chara1->position.vz;

        temp_s0 = chara1->collision.shapeOffsets.box.vx;
        temp_s3 = chara1->collision.shapeOffsets.box.vz;

        temp_s1 += temp_s0;

#ifdef SH_PC_PORT
        var_v1  += Q12_MULT_PRECISE(chara1->collision.box.top, tgtScale);
#else
        var_v1  += chara1->collision.box.top;
#endif
        temp_s2 += temp_s3;

        D_800C47C8[1].vy = var_v1;
#ifdef SH_PC_PORT
        temp_s3          = Q12_MULT_PRECISE(chara1->collision.cylinder.field_2, tgtScale);
#else
        temp_s3          = chara1->collision.cylinder.field_2;
#endif

        angle1 = ratan2(temp_s1 - posX, temp_s2 - posZ);
        temp_v0_6 = Math_Sin(angle1);
        temp_s0   = Q12_MULT_PRECISE(temp_s3, temp_v0_6);

        var_s1 = Math_Cos(angle1);

        posX = temp_s1 - temp_s0;

        D_800C47C8[1].vx = posX;
        posZ             = temp_s2 - Q12_MULT_PRECISE(temp_s3, var_s1);

        D_800C47C8[1].vz = posZ;
        /* Merge regression: the fork called Ray_LineCheck (0x8006D90C) here — a
         * world-geometry line check between two POINTS (from, to) that computes the
         * delta internally. The merge's rename pass mis-mapped it to Ray_LosHitCheck
         * (0x8006DB3C), a different function taking (from, delta) + doing chara
         * collision, and added a chara arg to compile. Passing the absolute `to`
         * point as a delta made a ~65-unit cross-map ray that always hit distant
         * geometry, so melee (and enemy attacks) never connected. Ray_TraceQuery is
         * 0x8006D90C — the correct modular equivalent of the fork's Ray_LineCheck. */
        var_v1           = Ray_TraceQuery(&D_800C47F8, &D_800C47C8[0], &D_800C47C8[1]);

        if (var_v1 != false)
        {
            var_v1 = true;
        }

        if (var_v1 == true)
        {
            continue;
        }

        temp_t4_2  = chara1->position.vx;
        temp_t4_2 += chara1->collision.shapeOffsets.box.vx;

        var_v1   = temp_t4_2 - countX;
        temp_t5  = chara1->position.vz;
        temp_t5 += chara1->collision.shapeOffsets.box.vz;

        temp_v0_8 = temp_t5 - coundZ;

        sp58    = chara1->position.vy;
#ifdef SH_PC_PORT
        temp_s6 = Q12_MULT_PRECISE(chara1->collision.box.height, tgtScale);
        temp_s5 = Q12_MULT_PRECISE(chara1->collision.box.top,    tgtScale);
#else
        temp_s6 = chara1->collision.box.height;
        temp_s5 = chara1->collision.box.top;
#endif

        j   = sp58 - countY;
        temp_t2   = Q12_MULT_PRECISE(var_v1, cosAngle) - Q12_MULT_PRECISE(temp_v0_8, sinAngle);
        temp_a0_3 = Q12_MULT_PRECISE(var_v1, sinAngle) + Q12_MULT_PRECISE(temp_v0_8, cosAngle);

        if ((j < (sp48 - temp_s6)) || ((sp3C - temp_s5) < j))
        {
            continue;
        }

#ifdef SH_PC_PORT
        temp_s3  = Q12_MULT_PRECISE(chara1->collision.cylinder.field_2, tgtScale);
#else
        temp_s3  = chara1->collision.cylinder.field_2;
#endif
        var_a1_2 = 0;

        if (temp_t2 < sp44)
        {
            var_a1_2 = sp44 - temp_t2;
        }
        else if (sp38 < temp_t2)
        {
            var_a1_2 = temp_t2 - sp38;
        }

        var_v1 = 0;

        if (temp_a0_3 < sp4C)
        {
            var_v1 = sp4C - temp_a0_3;
        }
        else if (sp40 < temp_a0_3)
        {
            var_v1 = temp_a0_3 - sp40;
        }

        if (var_a1_2 | var_v1)
        {
            if (var_a1_2 == Q12(0.0f))
            {
                if (temp_s3 < var_v1)
                {
                    continue;
                }
            }
            else
            {
                if (var_v1 == 0)
                {
                    if (temp_s3 < var_a1_2)
                    {
                        continue;
                    }
                }
                else
                {
                    var_v0_3 = Q12_MULT_PRECISE(var_a1_2, var_a1_2) + Q12_MULT_PRECISE(var_v1, var_v1);
                    if (Q12_MULT_PRECISE(temp_s3, temp_s3) < var_v0_3)
                    {
                        continue;
                    }
                }
            }
        }

        var_v0 = sp34;
        if (var_v0 < 0)
        {
            var_v0 += 3;
        }
        sp34 -= var_v0 >> 2;

        var_v0 = var_s7;
        if (var_v0 < 0)
        {
            var_v0 += 3;
        }
        var_s7 -= var_v0 >> 2;

        var_v0 = var_fp;
        if (var_v0 < 0)
        {
            var_v0 += 3;
        }
        var_fp -= var_v0 >> 2;

        sp34   += countX;
        var_s7 += countY;
        var_fp += coundZ;

        sp5C = (temp_s5 + temp_s6) / 2;

        temp_s2 = sp34 - temp_t4_2;
        var_s1  = var_fp - temp_t5;
        temp_s0 = var_s7 - (sp58 + sp5C);

        var_t1 = func_8008A058(func_80080540(temp_s2, 0, var_s1));
        var_t2 = (temp_s6 - temp_s5) / 2;

        if (var_t2 < 0)
        {
            var_t2 = 0;
        }


        for (j = 2; (var_t2 < temp_s0 || temp_s0 < -var_t2 || temp_s3 < var_t1) && j > 0; j--)
        {
            if (temp_s3 < var_t1)
            {
                temp_lo_5 = Q12(temp_s3) / var_t1;
                var_t1    = temp_s3;
                temp_s2   = Q12_MULT_PRECISE(temp_lo_5, temp_s2);
                temp_s0   = Q12_MULT_PRECISE(temp_lo_5, temp_s0);
                var_s1    = Q12_MULT_PRECISE(temp_lo_5, var_s1);
            }
            else if (var_t2 < temp_s0)
            {
                temp_lo_5 = Q12(var_t2) / temp_s0;
                temp_s0   = var_t2;
                var_t1    = Q12_MULT_PRECISE(temp_lo_5, var_t1);
                temp_s2   = Q12_MULT_PRECISE(temp_lo_5, temp_s2);
                var_s1    = Q12_MULT_PRECISE(temp_lo_5, var_s1);
            }
            else if (temp_s0 < -var_t2)
            {
                temp_lo_5 = Q12(-var_t2) / temp_s0;
                temp_s0   = -var_t2;
                var_t1    = Q12_MULT_PRECISE(temp_lo_5, var_t1);
                temp_s2   = Q12_MULT_PRECISE(temp_lo_5, temp_s2);
                var_s1    = Q12_MULT_PRECISE(temp_lo_5, var_s1);
            }
        }

        D_800C47B8.vx = temp_t4_2 + temp_s2;
        D_800C47B8.vy = (sp58 + sp5C) + temp_s0;
        D_800C47B8.vz = temp_t5 + var_s1;
        if (func_8008B714(chara, chara1, &D_800C47B8, arg3))
        {
            sp14 |= sp18;
        }
    }

    chara->field_44.field_8 |= sp14;
    return sp14;
}
