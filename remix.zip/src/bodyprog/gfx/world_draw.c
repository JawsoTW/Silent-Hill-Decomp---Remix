#include "game.h"
#ifdef SH_PC_PORT
#include "pc_pick.h"
#include <stdio.h>
#include "sh_log.h"
#include "pc_config.h"
#include "pc_big_lm.h"
#include "pc_playas.h"
#ifdef SH_PC_PORT
#include "main/fileinfo.h" /* g_GameRegion — PAL BG_ETC material-UV relocation */
#endif
#endif

#include <psyq/libetc.h>
#include <psyq/libpad.h>
#include <psyq/strings.h>

#include "bodyprog/bodyprog.h"
#include "bodyprog/gfx/map_effects.h"
#include "bodyprog/math/math.h"
#include "bodyprog/memcard.h"
#include "bodyprog/screen/screen_data.h"
#include "bodyprog/screen/screen_draw.h"
#include "bodyprog/sound/sound_system.h"
#include "bodyprog/text/text_draw.h"
#include "main/fsqueue.h"
#include "main/rng.h"
#include "screens/stream/stream.h"

const s32 pad_rodata_80025524 = 0;

// ========================================
// MAP GRAPHIC INITALIZATION
// ========================================

s_LinkedBone* WorldGfx_CharaModelBonesGet(e_CharaId charaId) // 0x8003BE50
{
    return g_WorldGfxWork.registeredCharaModels[charaId]->skeleton.bones_C;
}

void GameFs_BgEtcGfxLoad(void) // 0x8003BE6C
{
    static s_FsImageDesc IMAGE = { .tPage = { 0, 12 }, .clutX = 192 };

    Fs_QueueStartReadTim(FILE_TIM_BG_ETC_TIM, FS_BUFFER_1, &IMAGE);
}

void GameFs_BgItemLoad(void) // 0x8003BE9C
{
    g_WorldGfxWork.itemLmQueueIdx = Fs_QueueStartRead(FILE_BG_BG_ITEM_PLM, &g_WorldGfxWork.itemLmHdr);
}

void func_8003BED0(void) // 0x8003BED0
{
    static s_FsImageDesc IMAGE_TIM = {
        .tPage = { 0, 15 },
        .u     = 0,
        .v     = 0,
        .clutX = 176,
        .clutY = 0
    };

    static s_FsImageDesc IMAGE_ETC = {
        .tPage = { 0, 12 },
        .u     = 0,
        .v     = 192,
        .clutX = 192,
        .clutY = 0
    };

    s_LmHeader* itemLmHdr;

    itemLmHdr = &g_WorldGfxWork.itemLmHdr;

    if (!Fs_QueueIsEntryLoaded(g_WorldGfxWork.itemLmQueueIdx) || itemLmHdr->isLoaded)
    {
        return;
    }

#ifdef SH_PC_PORT
    /* PAL reslices BG_ETC.TIM (US 128x256 -> 256x128, bottom half placed to
     * the right): the material band at US atlas v=192 lives at cells (32,64)
     * on PAL (SLES desc 0x800A9ABC). CLUT home (192,0) is unchanged. */
    IMAGE_ETC.u = (g_GameRegion == Region_EUR) ? 32 : 0;
    IMAGE_ETC.v = (g_GameRegion == Region_EUR) ? 64 : 192;

    /* PAL relocates the TIM00 common-item CLUT to the bottom-right VRAM margin
     * (928,480) — the same retarget font_region.c applies to
     * g_FirstAidKitItemTextureImg, which is the desc GameFs_Tim00TIMLoad uploads
     * the TIM00 palette with. This world-prop material binding hardcodes the US
     * home (176,0); without matching the retarget, every common-item world prop
     * (DRINK/AIDKIT/BULLET) samples an empty palette on EUR and renders
     * invisible — while the pickup/inventory previews (which use the retargeted
     * desc directly) look fine. Not needed for JAP/US (CLUT stays at 176,0). */
    if (g_GameRegion == Region_EUR)
    {
        IMAGE_TIM.clutX = 928;
        IMAGE_TIM.clutY = 480;
    }
#endif

    LmHeader_FixOffsets(&g_WorldGfxWork.itemLmHdr);
    Lm_MaterialFsImageApply1(&g_WorldGfxWork.itemLmHdr, "TIM00", &IMAGE_TIM, 1);
    Lm_MaterialFsImageApply1(&g_WorldGfxWork.itemLmHdr, "BG_ETC", &IMAGE_ETC, 1);
    Lm_MaterialFlagsApply(&g_WorldGfxWork.itemLmHdr);
}

s32 Map_SpeedZoneTypeGet(q19_12 posX, q19_12 posZ) // 0x8003BF60
{
    s32                zoneType;
    const s_SpeedZone* curZone;

    zoneType = SpeedZoneType_Slow;

    if (g_SavegamePtr->mapIdx == MapIdx_MAP0_S00)
    {
        return SpeedZoneType_Normal;
    }

    if (g_WorldGfxWork.mapInfo->speedZones != NULL)
    {
        curZone = g_WorldGfxWork.mapInfo->speedZones;
        while (curZone->type != NO_VALUE)
        {
            if (posX >= Q4_TO_Q12(curZone->minX) && Q4_TO_Q12(curZone->maxX) >= posX &&
                posZ >= Q4_TO_Q12(curZone->minZ) && Q4_TO_Q12(curZone->maxZ) >= posZ &&
                zoneType < curZone->type)
            {
                zoneType = curZone->type;
            }

            curZone++;
        }
    }

    return zoneType;
}

void WorldGfx_MapInit(void) // 0x8003C048
{
    WorldEnv_Init();

    g_WorldGfxWork.useStoredPoint = false;

    Map_Init(GLOBAL_LM_BUFFER, IPD_BUFFER, 0x2C000);
    Collision_Init();

    g_SysWork.lightIntensity = Q12(1.0f);

    Game_FlashlightAttributesFix();
    func_8005B55C(vwGetViewCoord());
    Gfx_WorldObjectsClear(&g_WorldGfxWork);
}

void Item_HeldItemModelFree(void) // 0x8003C0C0
{
    s_HeldItem* heldItem;

    heldItem = &g_WorldGfxWork.heldItem;

    heldItem->itemId                       = NO_VALUE;
    heldItem->lmHdr                       = HELD_ITEM_LM_BUFFER;
    heldItem->bone.modelInfo.field_0    = 0;
    heldItem->bone.modelInfo.coord      = NULL;
    heldItem->bone.modelInfo.modelHdr = NULL;
}

void CharaModel_AllModelsFree(void) // 0x8003C110
{
    s32           i;
    s_CharaModel* curModel;

    for (i = 0; i < Chara_Count; i++)
    {
        if (i != Chara_Harry)
        {
            g_WorldGfxWork.registeredCharaModels[i] = NULL;
        }
    }

    g_WorldGfxWork.charaLmBuffer = MAP_CHARA_LM_BUFFER;
    for (curModel = &g_WorldGfxWork.charaModels[0]; curModel < &g_WorldGfxWork.charaModels[4]; curModel++)
    {
        CharaModel_Free(curModel);
    }
}

void CharaModel_Free(s_CharaModel* model) // 0x8003C1AC
{
    s_FsImageDesc image = { 0 };

    //memset(&image, 0, 8);
    model->charaId  = Chara_None;
    model->isLoaded = false;
    model->queueIdx = 0;
    model->lmHdr    = MAP_CHARA_LM_BUFFER;
    model->texture  = image;
}

// ========================================
// MAP GRAPHIC DRAW
// ========================================

extern s_WorldEnvWork const g_WorldEnvWork;

void Ipd_PlayerChunkInit(s_MapOverlayHdr* mapHdr, s32 playerPosX, s32 playerPosZ) // 0x8003C220
{
    s32        activeIpdCount;
    u8         flags;
    s_MapInfo* mapInfo;

#ifdef SH_PC_PORT
    /* Clear the whole-town parked-cell registry before this map's placements
     * (Map_PlaceIpdAtCell below + event-driven ones) record into it. */
    { extern void Pc_ParkedCellsReset(void); Pc_ParkedCellsReset(); }
#endif

    g_WorldGfxWork.mapInfo = mapHdr->mapInfo;

    flags = mapHdr->mapInfo->flags;
    if (flags & MapFlag_OneActiveChunk)
    {
        activeIpdCount = 1;
    }
    else if (flags & MapFlag_TwoActiveChunks)
    {
        activeIpdCount = 2;
    }
    else
    {
        activeIpdCount = 4;
    }
#ifdef SH_PC_PORT
    /* Bump active chunk count on PC. Original game used 1-2 chunks for
     * interior rooms because PSX 4:3 view fit the entire room within
     * those cells. With Hor+ widescreen + pixel-aspect compensation
     * (PsyCross 9c502de) the visible horizontal extent is ~1.46x PSX,
     * so chunks adjacent to the player's cell now appear at the screen
     * edges and need to stay resident. User reported edge geometry
     * disappearing as they turn (chunks not loaded fast enough to
     * cover the wider view). Confirmed via [IPD] ChunkCheckDraw log:
     * `total=256 loaded=2` regardless of room size.
     *
     * Floor at 4 covers the worst-case 1.46x extent in any rotation
     * (player at corner of 2x2 cells, view extending into 1 more on
     * each side). Map slot count maxes at PC_MAX_IPD_CHUNKS=256 so
     * upping the count costs ~50KB/chunk extra RAM at most.
     *
     * Interiors get 16: Map_ChunkLoad now loads the full +-2 X / +-1 Z
     * window that Ipd_CellPositionMatchCheck draws (15 cells), so the
     * window must fit in slots without evicting itself. With only 4
     * slots the hospital cycled rooms through the same slots every
     * door/cell crossing: the +-2 draw window then showed stale
     * residents (other rooms/floors) while the player's own cell was
     * still mid-load — floating neighbor rooms, void where the current
     * room should be, popping floor patches, and no collision for
     * visible-but-unloaded neighbors. */
    if (flags & MapFlag_Interior) {
        activeIpdCount = 16;
    } else if (activeIpdCount < 4) {
        activeIpdCount = 4;
    }
#endif


    mapInfo = mapHdr->mapInfo;
    Ipd_MapFileInfoSet(mapInfo->tag, mapInfo->plmFileIdx, activeIpdCount, CHECK_FLAG(mapInfo->flags, MapFlag_Interior, false), 0, 0);

    if (mapHdr->mapInfo == &MAP_INFOS[MapType_THR])
    {
        Map_PlaceIpdAtCell(FILE_BG_THR05FD_IPD, -1, 8);
    }

    Ipd_ChunkInit(playerPosX, playerPosZ, playerPosX, playerPosZ);
}

void Ipd_ActiveMapChunksClear0(void) // 0x8003C2EC
{
    Ipd_ActiveMapChunksClear();
}

void Map_WorldClear(void) // 0x8003C30C
{
    u8 flags;

    flags = g_WorldGfxWork.mapInfo->flags;
    if ((flags & MapFlag_Interior) && (flags & (MapFlag_OneActiveChunk | MapFlag_TwoActiveChunks)))
    {
#ifdef SH_PC_PORT
        SH_DBG("[TRANSITION] Map_WorldClear: interior small room -> Map_WorldClearReset (flags=0x%02X)", flags);
#endif
        Map_WorldClearReset();
        return;
    }

#ifdef SH_PC_PORT
    SH_DBG("[TRANSITION] Map_WorldClear: full clear -> Ipd_ActiveMapChunksClear + Ipd_TexturesRefClear (flags=0x%02X)", flags);
#endif
    Ipd_ActiveMapChunksClear();
    Ipd_TexturesRefClear();
}

void WorldGfx_IpdSamplePointStore(void) // 0x8003C368
{
    g_WorldGfxWork.useStoredPoint = true;
    g_WorldGfxWork.ipdSamplePoint = g_SysWork.playerWork.player.position;
}

void WorldGfx_IpdSamplePointReset(void) // 0x8003C3A0
{
    g_WorldGfxWork.useStoredPoint = false;
}

void Ipd_CloseRangeChunksInit(void) // 0x8003C3AC
{
    VECTOR3         pos0; // Draw distance?
                          // Setting as `pos0.vz = Q12(200.0f)` makes the world not draw. In the void, the player becomes immovable.
                          //
                          // Most of the time, X and Z share the same value as
                          // the player player position or a position slightly ahead computed from the heading angle.
                          //
                          // In Old Silent Hill (after Cafe 5to2) while standing still, this value is
                          // the same as `g_SysWork.playerWork.player.position`.
    VECTOR3         pos1; // Draw distance?
                          // If the conditional `if (g_WorldEnvWork.isFogEnabled)` is reversed
                          // to run the `else` block, when fog is enabled, the draw distance
                          // is slightly reduced.
                          //
                          // Similarly to `pos0`, when fog is disabled, it uses the player position.
                          // Otherwise it's based the camera position, using its rotation to then make some extra calculations.
    SVECTOR         rot;
    s32             temp_a1;
    s32             temp_a2;
    q19_12          moveDist;
    s32             temp_s0_2;
    s32             temp_v1_4;
    s32             var_a0;
    s32             var_a1;
    s32             var_s1;
    u8              flagsCpy;
    s_SubCharacter* chara;

    chara = &g_SysWork.playerWork.player;

    if (g_WorldGfxWork.useStoredPoint)
    {
        pos0 = g_WorldGfxWork.ipdSamplePoint;
    }
    else
    {
        pos0 = chara->position;
    }

    moveDist = (chara->moveSpeed * Q12(5.5f)) / 16015; // TODO: `Q12(3.91f)`? What's this doing?
    moveDist = CLAMP(moveDist, Q12(0.0f), Q12(5.5f));

    pos0.vx += Q12_MULT_PRECISE(moveDist, Math_Sin(chara->headingAngle));
    pos0.vz += Q12_MULT_PRECISE(moveDist, Math_Cos(chara->headingAngle));

    if (g_WorldGfxWork.mapInfo == &MAP_INFOS[MapType_THR] &&
        chara->position.vx >= Q12(-40.0f) && chara->position.vx <= Q12(40.0f) &&
        chara->position.vz >= Q12(200.0f) && chara->position.vz <= Q12(240.0f))
    {
        pos0.vz = Q12(200.0f);
    }

#ifdef SH_PC_PORT
    if (g_WorldEnvWork.isFogEnabled && !g_PcConfig.disableCulling)
#else
    if (g_WorldEnvWork.isFogEnabled)
#endif
    {
        vwGetViewPosition(&pos1);
        vwGetViewAngle(&rot);

        flagsCpy = g_WorldGfxWork.mapInfo->flags;
        if (!(flagsCpy & MapFlag_Interior) || !(flagsCpy & (MapFlag_OneActiveChunk | MapFlag_TwoActiveChunks)))
        {
            var_s1 = Q12_MULT(Math_Cos(rot.vx), Q12(9.0f));
        }
        else
        {
            var_s1 = Q12(0.0f);
        }

        temp_s0_2 = Q12_MULT(var_s1, Math_Sin(rot.vy));
        temp_s0_2 = CLAMP(temp_s0_2, Q12(-6.0f), Q12(6.0f));

        temp_v1_4 = Q12_MULT(var_s1, Math_Cos(rot.vy));
        temp_v1_4 = CLAMP(temp_v1_4, Q12(-6.0f), Q12(6.0f));

        pos1.vx += temp_s0_2;
        pos1.vz += temp_v1_4;

        if (Vc_VectorMagnitudeCalc(pos1.vx - chara->position.vx, Q12(0.0f), pos1.vz - chara->position.vz) > Q12(16.0f))
        {
            var_s1  = Q12(14.0f);
            pos1.vx = chara->position.vx + Q12_MULT(Math_Sin(rot.vy), var_s1);
            pos1.vz = chara->position.vz + Q12_MULT(Math_Cos(rot.vy), var_s1);
        }
    }
    else
    {
        pos1     = chara->position;
        pos1.vx += FP_FROM(Q12(Math_Sin(chara->rotation.vy)), Q12_SHIFT);
        pos1.vz += FP_FROM(Q12(Math_Cos(chara->rotation.vy)), Q12_SHIFT);
    }

    flagsCpy = g_WorldGfxWork.mapInfo->flags;
    if ((flagsCpy & MapFlag_Interior) && (flagsCpy & (MapFlag_OneActiveChunk | MapFlag_TwoActiveChunks)))
    {
        var_a1 = chara->position.vx / Q12(2.5f);
        if (chara->position.vx < Q12(0.0f))
        {
            var_a1--;
        }

        var_a0  = chara->position.vz / Q12(2.5f);
        temp_a1 = var_a1 * Q12(2.5f);

        if (chara->position.vz < Q12(0.0f))
        {
            var_a0--;
        }

        temp_a2 = var_a0 * Q12(2.5f);

        pos0.vx = CLAMP(pos0.vx, temp_a1 + 1, temp_a1 + (Q12(2.5f) - 1));
        pos0.vz = CLAMP(pos0.vz, temp_a2 + 1, temp_a2 + (Q12(2.5f) - 1));
        pos1.vx = CLAMP(pos1.vx, temp_a1 + 1, temp_a1 + (Q12(2.5f) - 1));
        pos1.vz = CLAMP(pos1.vz, temp_a2 + 1, temp_a2 + (Q12(2.5f) - 1));
    }

    Ipd_ChunkInit(pos0.vx, pos0.vz, pos1.vx, pos1.vz);
}

bool Ipd_ChunkInitCheck(void) // 0x8003C850
{
    Ipd_CloseRangeChunksInit();
    return Ipd_AreChunksLoaded();
}

void Gfx_InGameDraw(bool arg0) // 0x8003C878
{
#ifdef SH_PC_PORT
    /* Assert the WORLD's GTE anchor at the moment the world is projected.
     * MainLoop's per-frame anchor assert runs AFTER the state update, and the
     * whole world is projected DURING it (right here), so that assert's value
     * lands one frame late: any 0<->8 transition leaked one world frame at the
     * stale value -- the 8-row upward flick on every common-pickup confirm
     * (pickup frames assert 0 for the item pass; the first world frame after
     * the confirm was still projected with it). Same decide-at-submission
     * pattern as the Hor+ framing flag set beside this call's site
     * (game_sys_states.c). The item pass never comes through here, so its
     * validated zero baseline is untouched.
     *
     * [FLICK] logs anchor CHANGES only (bounded): after this fix no world
     * submission may ever log an anchor of 0. */
    {
        extern s32 Pc_WorldAnchorOfy(void);
        extern int g_PcPickupItemActive;
        s32 worldOfy = Pc_WorldAnchorOfy();
        static s32 s_prevOfy = -9999;
        static int s_flickLogs = 0;
        if (worldOfy != s_prevOfy && s_flickLogs < 24)
        {
            s_flickLogs++;
            SH_DBG("[FLICK] world anchor %d -> %d (pickup=%d)",
                   s_prevOfy, worldOfy, g_PcPickupItemActive);
        }
        s_prevOfy = worldOfy;
        SetGeomOffset(0, worldOfy);
    }
#endif
    Gfx_WorldObjectsDraw(&g_WorldGfxWork);

#ifdef SH_PC_PORT
    /* On PC, CdRead is synchronous via PsyCross. The PSX while-loop
     * blocked rendering until the player's cell chunk was loaded; the
     * old PC replacement flushed the queue BEFORE Ipd_CloseRangeChunksInit
     * queued the new cell's read, so every cell crossing drew 1+ frames
     * with the current room missing. Order must be queue -> flush ->
     * fix up: each init queues reads and reformats completed ones, so
     * two init/flush rounds plus a final init guarantee the window is
     * loaded, reformatted, and drawable this same frame. */
    {
        int pass;
        for (pass = 0; pass < 2; pass++)
        {
            Ipd_CloseRangeChunksInit();
            {
                int flushLimit = 500;
                while (Fs_QueueGetLength() > 0 && --flushLimit > 0)
                {
                    Fs_QueueUpdate();
                }
            }
        }
        Ipd_CloseRangeChunksInit();
    }
#else
    while (func_80043830())
    {
        Ipd_CloseRangeChunksInit();
        Fs_QueueWaitForEmpty();
    }
#endif

    Ipd_ChunkCheckDraw(&g_OrderingTable0[g_ActiveBufferIdx], arg0);
#ifdef SH_PC_PORT
    /* Bullet-hole decals ride the world OT here so GsWSMATRIX matches the
     * chunk geometry they sit on (pc_decals.c). */
    { extern void Pc_DecalsDraw(GsOT* ot); Pc_DecalsDraw(&g_OrderingTable0[g_ActiveBufferIdx]); }
#endif
    Gfx_2dEffectsDraw();
}

// ========================================
// OBJECTS DRAW
// ========================================

void WorldObject_ModelNameSet(s_WorldObjectModel* model, char* newStr) // 0x8003C8F8
{
    model->metadata.lmIdx = 0;
    model->modelInfo.field_0  = 0;

    StringCopy(model->metadata.name.str, newStr);

    model->metadata.field_8 = 0;
}

#ifdef SH_PC_PORT
bool Pc_CommonPickupInRange(const VECTOR3* pos)
{
    extern s_MapTerrain g_Map;
    const VECTOR3*      pp = &g_SysWork.playerWork.player.position;
    q19_12              dy = pos->vy - pp->vy;
    s32                 dx;
    s32                 dz;

    /* Interiors only: rooms are short and first person sees across a cell
     * edge within a few steps. Outdoors keeps the original per-cell items. */
    if (g_Map.isExterior)
    {
        return false;
    }

    /* The floor test keeps an item on a storey above or below from showing
     * through a stairwell or an unloaded room. */
    if (dy > Q12(3.0f) || dy < Q12(-3.0f))
    {
        return false;
    }
    dx = FLOOR_TO_STEP(pos->vx, CHUNK_CELL_SIZE) - FLOOR_TO_STEP(pp->vx, CHUNK_CELL_SIZE);
    dz = FLOOR_TO_STEP(pos->vz, CHUNK_CELL_SIZE) - FLOOR_TO_STEP(pp->vz, CHUNK_CELL_SIZE);
    return dx >= -1 && dx <= 1 && dz >= -1 && dz <= 1;
}
#endif

void WorldGfx_ObjectAdd(s_WorldObjectModel* model, const VECTOR3* pos, const SVECTOR3* rot) // 0x8003C92C
{
    q23_8          geomPosX;
    q23_8          geomPosY;
    q23_8          geomPosZ;
    q21_10         geomRotX;
    q19_12         geomRotY;
    q21_10         geomRotZ;
    s32            i;
    s32            lmIdx;
    s_WorldObject* obj;

#ifdef SH_PC_PORT
    /* Remix keys: a key moved to a new spot hides its original-pose draw. */
    {
        extern int Pc_Remix_MapActive(void);
        extern int Pc_Remix_ObjectAddFilter(const s_WorldObjectModel* model, const VECTOR3* pos);
        if (Pc_Remix_MapActive() && Pc_Remix_ObjectAddFilter(model, pos))
            return;
    }
#endif
    // Check if array of world objects to draw is full.
    if (g_WorldGfxWork.objectCount < ARRAY_SIZE(g_WorldGfxWork.objects))
    {
        if (model->metadata.lmIdx == 0)
        {
            func_8003BED0();

            lmIdx = func_8004287C(model, &model->metadata, g_SysWork.playerWork.player.position.vx, g_SysWork.playerWork.player.position.vz);
            if (lmIdx == 0)
            {
                if (!Lm_ModelFind(model, &g_WorldGfxWork.itemLmHdr, &model->metadata))
                {
#ifdef SH_PC_PORT
                    /* Once per distinct name per session (used to fire every
                     * frame — thousands of lines/min in the streets/school).
                     * Kept as a one-shot because it found the chunks[4]-cap
                     * bug (vanishing papers/GOLD_HID); note itemLmMagic '0'
                     * (0x30) is the VALID LM magic, not an error. */
                    {
                        static char s_failNames[8][8];
                        static int  s_failCount = 0;
                        int _k, _seen = 0;
                        for (_k = 0; _k < s_failCount; _k++) {
                            if (memcmp(s_failNames[_k], model->metadata.name.str, 8) == 0) {
                                _seen = 1;
                                break;
                            }
                        }
                        if (!_seen && s_failCount < 8) {
                            memcpy(s_failNames[s_failCount++], model->metadata.name.str, 8);
                            SH_DBG("[WOBJ] find-fail name='%.8s' itemLmMagic=0x%x lmIdx=%d cell=(%d,%d)",
                                   model->metadata.name.str, (unsigned)g_WorldGfxWork.itemLmHdr.magic,
                                   (int)model->metadata.lmIdx,
                                   (int)(g_SysWork.playerWork.player.position.vx >> 16),
                                   (int)(g_SysWork.playerWork.player.position.vz >> 16));
                        }
                    }
#endif
                    return;
                }
                else
                {
                    lmIdx = 1;
                }
            }

            model->metadata.lmIdx = lmIdx;
#ifdef SH_PC_PORT
            /* First-resolve trace (paper-on-street diagnosis): if an object
             * is invisible AND absent here AND no find-fail printed, its
             * draw call never ran (cell/chunk gating). */
            {
                static int s_wobjResolveLogged = 0;
                if (s_wobjResolveLogged < 24) {
                    SH_DBG("[WOBJ] resolved '%.8s' lmIdx=%d", model->metadata.name.str, (int)lmIdx);
                    s_wobjResolveLogged++;
                }
            }
#endif
        }

        // Compute geometry position and rotation.
        geomPosX = Q12_TO_Q8(pos->vx);
        geomPosY = Q12_TO_Q8(pos->vy);
        geomPosZ = Q12_TO_Q8(pos->vz);
        geomRotX = Q12_TO_Q10(rot->vx);
        geomRotY = Q12_TO_Q10(rot->vz);
        geomRotZ = rot->vy;

        // Check if world object to draw was already submitted?
        for (i = 0; i < g_WorldGfxWork.objectCount; i++)
        {
            obj = &g_WorldGfxWork.objects[i];

            if (model == obj->model &&
                geomPosX == obj->positionX &&
                geomPosZ == obj->positionZ &&
                geomPosY == obj->positionY &&
                geomRotX == obj->rotationX &&
                geomRotZ == obj->rotationY &&
                geomRotY == obj->rotationZ)
            {
                return;
            }
        }

        // Submit world object to draw.
        obj = &g_WorldGfxWork.objects[g_WorldGfxWork.objectCount];
        obj->rotationX = geomRotX;
        obj->rotationY = geomRotZ;
        if (obj->positionZ) {} // @hack Required for match.
        obj->rotationZ = geomRotY;
        obj->model     = model;
        obj->positionX = geomPosX;
        obj->positionY = geomPosY;
        obj->positionZ = geomPosZ;

        g_WorldGfxWork.objectCount++;
    }
}

void Gfx_WorldObjectsClear(s_WorldGfxWork* worldGfxWork) // 0x8003CB3C
{
    worldGfxWork->objectCount = 0;
}

void Gfx_WorldObjectsDraw(s_WorldGfxWork* worldGfxWork) // 0x8003CB44
{
    s_WorldObject* curObj;

    // Run through world objects to draw.
    for (curObj = &worldGfxWork->objects[0]; curObj < &worldGfxWork->objects[worldGfxWork->objectCount]; curObj++)
    {
        Gfx_WorldObjectDraw(curObj);
    }
#ifdef SH_PC_PORT
    {
        extern void Pc_Remix_WorldDraw(void);
        Pc_Remix_WorldDraw();
    }
#endif

    worldGfxWork->objectCount = 0;
}

void Gfx_WorldObjectDraw(s_WorldObject* obj) // 0x8003CBA4
{
    GsCOORDINATE2 coord;
    SVECTOR       rot;     // Q3_12
    MATRIX        mats[2]; // View mat, world mat.

    coord.flg   = false;
    coord.super = NULL;

    // Set geometry position.
    coord.coord.t[0] = obj->positionX;
    coord.coord.t[1] = obj->positionY;
    coord.coord.t[2] = obj->positionZ;

    // Compute world rotation.
    rot.vx = Q10_TO_Q12(obj->rotationX);
    rot.vy = obj->rotationY;
    rot.vz = Q10_TO_Q12(obj->rotationZ);

    Math_RotMatrixZxyNeg(&rot, &coord.coord);
#ifdef SH_PC_PORT
    Pc_Pick_WorldObjectPreDraw(obj, &coord);
#endif
    Vw_CoordToWorldAndViewMatrices(&coord, &mats[1], &mats[0]);

    func_8003CC7C(obj->model, &mats[0], &mats[1]);
}

void func_8003CC7C(s_WorldObjectModel* model, MATRIX* viewMat, MATRIX* worldMat) // 0x8003CC7C
{
    s8                     lmIdx;
    s_WorldObjectMetadata* objMetaCpy;
    s_ModelHeader*         modelHdr;

#ifdef SH_PC_PORT
    /* PSX trusted the caller; PC sees occasional NULL `model` from
     * map overlay sanitizer + un-decompiled callers. Bail rather than
     * dereference. */
    if (model == NULL) return;
#endif
    lmIdx = model->metadata.lmIdx;
    if (lmIdx == 0)
    {
        return;
    }

    modelHdr   = model->modelInfo.modelHdr;
    objMetaCpy = &model->metadata;

#ifdef SH_PC_PORT
    /* PSX had 4 streaming-active chunks (lmIdx 3..6), all textured, so the
     * `< 7` bound covered every resolvable chunk. PC preloadChunks loads EVERY
     * chunk's geometry but only textures the nearest K (8-full/2-half page
     * pool), so a world object can resolve its model to a far chunk with
     * lmIdx >= 7 that is loaded-but-UNtextured. Those bypassed this residency
     * gate entirely and drew with stale/wrong VRAM pages = rainbow/garbage
     * textures on specific far props (otherworld fence rails + cylinder posts)
     * while the near textured floor rendered fine. Gate every active-chunk
     * lmIdx on texture residency; IpdHeader_IsLoaded reports Loaded only when
     * all the chunk's materials have resident textures, so an untextured far
     * chunk drops the object (lmIdx=0 -> re-resolve next frame), exactly like
     * PSX's out-of-window chunks. */
    extern s_MapTerrain g_Map;
    s32 chunkIdx = lmIdx - 3;
    if (lmIdx >= 3)
    {
        /* func_8004287C saturates the slot at 127 (lmIdx is an s8); find a
         * slot that far out from the model it resolved to. */
        const s_Chunk* ch = chunkIdx < g_Map.activeChunkCount ? &g_Map.activeChunks[chunkIdx] : NULL;
        if (lmIdx == 127 || ch == NULL || ch->ipdHdr == NULL || ch->ipdHdr->lmHdr == NULL ||
            modelHdr < ch->ipdHdr->lmHdr->modelHdrs ||
            modelHdr >= ch->ipdHdr->lmHdr->modelHdrs + ch->ipdHdr->lmHdr->modelCount)
        {
            s32 c;
            chunkIdx = -1;
            for (c = 0; c < g_Map.activeChunkCount; c++)
            {
                const s_Chunk* cc = &g_Map.activeChunks[c];
                if (cc->ipdHdr != NULL && cc->ipdHdr->lmHdr != NULL && cc->ipdHdr->lmHdr->modelHdrs != NULL &&
                    modelHdr >= cc->ipdHdr->lmHdr->modelHdrs &&
                    modelHdr < cc->ipdHdr->lmHdr->modelHdrs + cc->ipdHdr->lmHdr->modelCount)
                {
                    chunkIdx = c;
                    break;
                }
            }
            if (chunkIdx < 0)
            {
                model->metadata.lmIdx = 0;
                return;
            }
        }
    }
    if (lmIdx >= 3 && chunkIdx < g_Map.activeChunkCount)
#else
    if (lmIdx >= 3 && lmIdx < 7)
#endif
    {
#ifdef SH_PC_PORT
        if (!IpdHeader_IsLoaded(chunkIdx))
#else
        if (!IpdHeader_IsLoaded(lmIdx - 3))
#endif
        {
            model->metadata.lmIdx = 0;
        }
#ifdef SH_PC_PORT
        else if (lmIdx >= 7)
        {
            /* These objects were previously ungated (lmIdx>=7 fell outside the
             * old `< 7` bound). Log once per name: if a garbage-textured prop
             * appears here its chunk IS textured -> the corruption is a stolen/
             * wrong texture page, not a missing one. If it never appears, the
             * gate above dropped it (untextured far chunk). */
            static char s_seen[8][8];
            static int  s_seenCount = 0;
            int _k, _dup = 0;
            for (_k = 0; _k < s_seenCount; _k++)
                if (memcmp(s_seen[_k], model->metadata.name.str, 8) == 0) { _dup = 1; break; }
            if (!_dup && s_seenCount < 8)
            {
                memcpy(s_seen[s_seenCount++], model->metadata.name.str, 8);
                SH_DBG("[WOBJ-TEX] '%.8s' lmIdx=%d chunk textured=YES (drawn) — garbage here = wrong page",
                       model->metadata.name.str, (int)lmIdx);
            }
        }
#endif
    }

#ifdef SH_PC_PORT
    /* Guard NULL modelHdr (was once a crash; now silent skip) */
    if (modelHdr == NULL)
    {
        model->metadata.lmIdx = 0;
        return;
    }
#endif

    if (COMPARE_FILENAMES(&objMetaCpy->name, &modelHdr->name))
    {
        model->metadata.lmIdx = 0;
        return;
    }

#ifdef SH_PC_PORT
    /* Name the owner of any packet the CLUT sanitizer is about to discard.
     * PsyCross sees only the packet (CLUTDROP can't say whose it was); a clut
     * decoding past the pool (slot >= 512) cannot come from any stamp path --
     * it is poisoned prim data, i.e. this model is being drawn from a
     * reclaimed buffer even though its name still matches. Log the object,
     * model address and prim so user logs identify the reclaimed file
     * (Nowhere elevator: use elevator -> hall -> return). */
    {
        static int s_poisonLog = 0;

        if (s_poisonLog < 8 && modelHdr->meshCount > 0)
        {
            s_MeshHeader* _mh = &modelHdr->meshHdrs[0];
            s32           _pi;

            for (_pi = 0; _pi < _mh->primitiveCount; _pi++)
            {
                u16 _c = (u16)_mh->primitives[_pi].field_2;

                if ((_c & 0x8000) &&
                    (((((_c >> 6) & 0x3FF) - 512) / 16) * 64 + (_c & 0x3F)) >= 512)
                {
                    extern int Pc_PrimHashCheck(const void* ptr, u32 len);
                    int _v = Pc_PrimHashCheck(_mh->primitives,
                                              (u32)_mh->primitiveCount * sizeof(s_Primitive));
                    s_poisonLog++;
                    SH_DBG("[WOBJ-POISON] '%.8s' lmIdx=%d modelHdr=%p mesh0 prim%d clut=0x%04X primCnt=%d prims=%p verts=%p p0clut=0x%04X verdict=%s",
                           model->metadata.name.str, (int)lmIdx, (void*)modelHdr,
                           (int)_pi, (unsigned)_c, (int)_mh->primitiveCount,
                           (void*)_mh->primitives, (void*)_mh->verticesXy,
                           (unsigned)(u16)_mh->primitives[0].field_2,
                           (_v == 1) ? "BORN-AT-REFORMAT" :
                           (_v == 2) ? "STOMPED-IN-PLACE" : "PTR-NOT-A-REFORMAT-OUTPUT");
                    break;
                }
            }
        }
    }
#endif

    func_80057090(&model->modelInfo, &g_OrderingTable0[g_ActiveBufferIdx], 1, viewMat, worldMat, 0);
}

// ========================================
// HELD ITEM DRAW
// ========================================

s32 WorldGfx_HeldItemIdGet(void) // 0x8003CD5C
{
    return g_WorldGfxWork.heldItem.itemId;
}

s32 WorldGfx_PlayerPrevHeldItem(s_PlayerCombat* combat) // 0x8003CD6C
{
    s32 itemId;
    s8  weaponAttack;

    weaponAttack = combat->weaponAttack;
    itemId       = NO_VALUE;
    if (weaponAttack != NO_VALUE)
    {
        itemId = weaponAttack + InvItemId_KitchenKnife;
    }

    return WorldGfx_PlayerHeldItemSet(itemId);
}

s32 WorldGfx_PlayerHeldItemSet(e_InvItemId itemId) // 0x8003CDA0
{
    s32         fileIdx;
    s_HeldItem* heldItem;

    // Check if requested item is already being held.
    heldItem = &g_WorldGfxWork.heldItem;
    if (heldItem->itemId == itemId)
    {
        return 0;
    }

    // Define texture files to load.
    heldItem->itemId = itemId;
    switch (itemId)
    {
        default:
            fileIdx = NO_VALUE;
            break;

        case NO_VALUE:
        case InvItemId_KitchenKnife:
        case InvItemId_Hammer:
        case InvItemId_Axe:
        case InvItemId_Handgun:
        case InvItemId_HuntingRifle:
        case InvItemId_Shotgun:
            fileIdx                 = NO_VALUE;
            heldItem->textureName = "HERO";
            break;

        case InvItemId_SteelPipe:
            fileIdx                 = FILE_ITEM_PIPE_TIM;
            heldItem->textureName = "PIPE";
            break;

        case InvItemId_CutscenePhone:
            fileIdx                 = FILE_ITEM_PHONE_TIM;
            heldItem->textureName = "PHONE";
            break;

        case InvItemId_CutsceneFlauros:
            fileIdx                 = FILE_ITEM_FLAUROS_TIM;
            heldItem->textureName = "FLAUROS";
            break;

        case InvItemId_CutsceneAglaophotis:
            fileIdx                 = FILE_ITEM_AGLA_TIM;
            heldItem->textureName = "AGLA";
            break;

        case InvItemId_CutscenePlasticBottle:
            fileIdx                 = FILE_ITEM_BOTL_TIM;
            heldItem->textureName = "BOTL";
            break;

        case InvItemId_CutsceneBaby:
            fileIdx                 = FILE_ITEM_BABY_TIM;
            heldItem->textureName = "BABY";
            break;

        case InvItemId_CutsceneBloodPack:
            fileIdx                 = FILE_ITEM_BLOOD_TIM;
            heldItem->textureName = "BLOOD";
            break;

        case InvItemId_Chainsaw:
            fileIdx                 = FILE_ITEM_CSAW_TIM;
            heldItem->textureName = "CSAW";
            break;

        case InvItemId_HyperBlaster:
            fileIdx                 = FILE_ITEM_HPRGUN_TIM;
            heldItem->textureName = "HPRGUN";
            break;

        case InvItemId_RockDrill:
            fileIdx                 = FILE_ITEM_DRILL_TIM;
            heldItem->textureName = "DRILL";
            break;

        case InvItemId_Katana:
            fileIdx                 = FILE_ITEM_KATANA_TIM;
            heldItem->textureName = "KATANA";
            break;
    }

    // Set texture UVs.
    if (fileIdx == NO_VALUE)
    {
        heldItem->imageDesc.tPage[1] = 27;
        heldItem->imageDesc.tPage[0] = 0;
        heldItem->imageDesc.u        = 0;
        heldItem->imageDesc.v        = 0;
        heldItem->imageDesc.clutX    = 736;
        heldItem->imageDesc.clutY    = 480;
    }
    else
    {
        heldItem->imageDesc.tPage[1] = 27;
        heldItem->imageDesc.tPage[0] = 0;
        heldItem->imageDesc.u        = 48;
        heldItem->imageDesc.v        = 224;
        heldItem->imageDesc.clutX    = 736;
        heldItem->imageDesc.clutY    = 498;
    }

    // Load texture.
    if (fileIdx != NO_VALUE)
    {
        heldItem->queueIdx = Fs_QueueStartReadTim(fileIdx, FS_BUFFER_10, &heldItem->imageDesc);
    }

    // Define index of model file to lead.
    switch (itemId)
    {
        case NO_VALUE:
        default:
            fileIdx = NO_VALUE;
            break;

        case InvItemId_KitchenKnife:
            fileIdx = FILE_ITEM_KNIFE_PLM;
            break;

        case InvItemId_SteelPipe:
            fileIdx = FILE_ITEM_PIPE_PLM;
            break;

        case InvItemId_Hammer:
            fileIdx = FILE_ITEM_HAMMER_PLM;
            break;

        case InvItemId_Axe:
            fileIdx = FILE_ITEM_AXE_PLM;
            break;

        case InvItemId_Handgun:
            fileIdx = FILE_ITEM_HANDGUN_PLM;
            break;

        case InvItemId_HuntingRifle:
            fileIdx = FILE_ITEM_RIFLE_PLM;
            break;

        case InvItemId_Shotgun:
            fileIdx = FILE_ITEM_SHOTGUN_PLM;
            break;

        case InvItemId_CutscenePhone:
            fileIdx = FILE_ITEM_PHONE_PLM;
            break;

        case InvItemId_CutsceneFlauros:
            fileIdx = FILE_ITEM_FLAUROS_PLM;
            break;

        case InvItemId_CutsceneAglaophotis:
            fileIdx = FILE_ITEM_AGLA_PLM;
            break;

        case InvItemId_CutscenePlasticBottle:
            fileIdx = FILE_ITEM_BOTL_PLM;
            break;

        case InvItemId_CutsceneBaby:
            fileIdx = FILE_ITEM_BABY_PLM;
            break;

        case InvItemId_CutsceneBloodPack:
            fileIdx = FILE_ITEM_BLOOD_PLM;
            break;

        case InvItemId_Chainsaw:
            fileIdx = FILE_ITEM_CSAW_PLM;
            break;

        case InvItemId_HyperBlaster:
            fileIdx = FILE_ITEM_HPRGUN_PLM;
            break;

        case InvItemId_RockDrill:
            fileIdx = FILE_ITEM_DRILL_PLM;
            break;

        case InvItemId_Katana:
            fileIdx = FILE_ITEM_KATANA_PLM;
            break;
    }

    // Load model.
    if (fileIdx != NO_VALUE)
    {
#ifdef SH_PC_PORT
        heldItem->lmHdr = Pc_BigLm_Redirect(fileIdx, heldItem->lmHdr);
#endif
        heldItem->queueIdx = Fs_QueueStartRead(fileIdx, heldItem->lmHdr);
        return heldItem->queueIdx;
    }

    return 0;
}

void func_8003D01C(void) // 0x8003D01C
{
    g_WorldGfxWork.heldItem.bone.modelInfo.field_0 &= ~(1 << 31);
}

void func_8003D03C(void) // 0x8003D03C
{
    g_WorldGfxWork.heldItem.bone.modelInfo.field_0 |= 1 << 31;
}

void WorldGfx_HeldItemDraw(void) // 0x8003D058
{
    MATRIX         viewMat;
    MATRIX         worldMat;
    GsCOORDINATE2* coord;
    s_HeldItem*    heldItem;
    s_LmHeader*    lmHdr;

    // Check if held item is valid.
    heldItem = &g_WorldGfxWork.heldItem;
    if (heldItem->itemId == NO_VALUE)
    {
        return;
    }

    // Distinguish between left-handed and right-handed items.
    if (heldItem->itemId == InvItemId_CutscenePhone)
    {
        coord = &g_SysWork.playerBoneCoords[HarryBone_LeftHand];
    }
    else
    {
        coord = &g_SysWork.playerBoneCoords[HarryBone_RightHand];
    }

    if (Fs_QueueIsEntryLoaded(heldItem->queueIdx))
    {
        lmHdr = heldItem->lmHdr;
        if (!lmHdr->isLoaded)
        {
            LmHeader_FixOffsets(lmHdr);
#ifdef SH_PC_PORT
            /* Play-as: knife/hammer/axe/handgun/rifle/shotgun PLMs are
             * textured from HERO.TIM, but Harry's VRAM parcel now holds the
             * skin's sheet — bake against the virtual-slot copy instead.
             * Patched here (not at HeldItemSet) so it holds no matter which
             * load path filled the desc. */
            if (heldItem->textureName != NULL && strcmp(heldItem->textureName, "HERO") == 0)
            {
                Pc_PlayAs_HeldItemImageDesc(&heldItem->imageDesc);
            }
#endif
            Lm_MaterialFsImageApply1(lmHdr, heldItem->textureName, &heldItem->imageDesc, BlendMode_Additive);
            Lm_MaterialFlagsApply(lmHdr);
            Bone_ModelAssign(&heldItem->bone, heldItem->lmHdr, 0);
        }

        Vw_CoordToWorldAndViewMatrices(coord, &worldMat, &viewMat);
        func_80057090(&heldItem->bone.modelInfo, &g_OrderingTable0[g_ActiveBufferIdx], 1, &viewMat, &worldMat, 0);
    }
}

// ========================================
// CHARACTER LOAD AND DRAW
// ========================================

void WorldGfx_HarryCharaLoad(void) // 0x8003D160
{
    s_FsImageDesc   image;
    s32             queueIdx;
    s_WorldGfxWork* worldGfxWork;
    s_CharaModel*   harryModel;
    s_LmHeader*     harryLmHdr;

    harryLmHdr = HARRY_LM_BUFFER;

    Chara_FsImageCalc(&image, Chara_Harry, 0);

    worldGfxWork                                      = &g_WorldGfxWork;
    harryModel                                        = &worldGfxWork->harryModel;
    g_WorldGfxWork.registeredCharaModels[Chara_Harry] = harryModel;

#ifdef SH_PC_PORT
    harryLmHdr = Pc_BigLm_Redirect(CHARA_FILE_INFOS[Chara_Harry].modelFileIdx, harryLmHdr);
    /* A play-as retarget must never read a non-HERO ILM into the HERO-sized
     * slab (sector-granular reads overrun HELD_ITEM_LM_BUFFER). */
    harryLmHdr = (s_LmHeader*)Pc_PlayAs_PlayerLmRedirect(CHARA_FILE_INFOS[Chara_Harry].modelFileIdx, harryLmHdr);
    /* ...and a non-HERO player TIM must never land in the HERO-sized VRAM parcel:
     * it overruns onto the chara CLUT shelf below it. Mutating `image` here
     * covers both the upload and the material bake — they share this desc. */
    Pc_PlayAs_PlayerImageDesc(&image);
#endif
    Fs_QueueStartRead(CHARA_FILE_INFOS[Chara_Harry].modelFileIdx, harryLmHdr);
    queueIdx = Fs_QueueStartReadTim(CHARA_FILE_INFOS[Chara_Harry].textureFileIdx, FS_BUFFER_1, &image);

    g_WorldGfxWork.harryModel.charaId = Chara_Harry;
    harryModel->isLoaded              = false;
    harryModel->queueIdx              = queueIdx;
    harryModel->lmHdr                 = harryLmHdr;
    g_WorldGfxWork.harryModel.texture = image;
}

s32 WorldGfx_MapInitCharaLoad(s_MapOverlayHdr* mapHdr) // 0x8003D21C
{
    s_FsImageDesc image;
    bool          cond;
    s32           i;
    s32           j;
    s32           queueIdx;
    s32           curCharaId;
    s_CharaModel* curModel;

    for (queueIdx = 0, i = 0, g_WorldGfxWork.charaLmBuffer = MAP_CHARA_LM_BUFFER, cond = false;
         i < CHARA_GROUP_COUNT;
         i++)
    {
        curCharaId = mapHdr->charaGroupIds[i];
        curModel   = &g_WorldGfxWork.charaModels[i];

        if (curCharaId != Chara_None)
        {
            if (!cond)
            {
                if (curCharaId != curModel->charaId)
                {
                    cond = true;
                    for (j = i; j < ARRAY_SIZE(g_WorldGfxWork.charaModels); j++)
                    {
                        g_WorldGfxWork.charaModels[j].charaId = Chara_None;
                    }
                }
            }

            if (cond)
            {
                Chara_FsImageCalc(&image, curCharaId, i);
                queueIdx = WorldGfx_CharaModelLoad(curCharaId, i, (s_LmHeader*)g_WorldGfxWork.charaLmBuffer, &image);
            }

            WorldGfx_CharaLmBufferAdvance(&g_WorldGfxWork.charaLmBuffer, curCharaId);
        }
    }

    return queueIdx;
}

void WorldGfx_CharaLmBufferAdvance(u8** buf, e_CharaId charaId) // 0x8003D354
{
    s16 modelFileIdx;
    s32 fileSize;

    modelFileIdx = CHARA_FILE_INFOS[charaId].modelFileIdx;
    fileSize     = Fs_GetFileSize(modelFileIdx);

    Fs_GetFileSectorAlignedSize(modelFileIdx);
    *buf += (fileSize + 3) & ~0x3;
}

void Chara_FsImageCalc(s_FsImageDesc* image, s32 charaId, s32 modelIdx) // 0x8003D3BC
{
    s16 clutX;
    s16 clutY;
    s8  tPage;
    s8  v;
    s8  u;

    // TODO: Deoptimise.
    v = charaId < Chara_AirScreamer;
    if (charaId >= Chara_None && v)
    {
        tPage = 27;
        v     = 0;
        u     = 0;
        clutX = 736;
        clutY = 480;
    }
    else
    {
        clutY = 464;
        clutX = (modelIdx * 16) + 704;

        switch (modelIdx)
        {
            default:
                modelIdx = 0;

            case 0:
            case 1:
                tPage = 28;
                u     = 0;
                v     = modelIdx << 7;
                break;

            case 2:
            case 3:
                tPage = 29;
                u     = 0;
                v     = (modelIdx - 2) << 7;
                break;
        }
    }

    image->tPage[0] = 0;
    image->tPage[1] = tPage;
    image->u        = u;
    image->v        = v;
    image->clutX    = clutX;
    image->clutY    = clutY;
}

bool WorldGfx_IsCharaModelPresent(e_CharaId charaId) // 0x8003D444
{
    return g_WorldGfxWork.registeredCharaModels[charaId] != NULL;
}

void func_8003D460(void) {} // 0x8003D460

void WorldGfx_CharaModelTransparentSet(e_CharaId charaId, bool enableTransparency) // 0x8003D468
{
    s16           data[256];
    RECT          rect;
    s32           x;
    s32           i;
    s32           y;
    s_CharaModel* model;

    model = g_WorldGfxWork.registeredCharaModels[charaId];
    Lm_TransparentPrimSet(model->lmHdr, enableTransparency);

    rect.x = model->texture.clutX;
    rect.y = model->texture.clutY;
    rect.w = 16;
    rect.h = 16;

    DrawSync(SyncMode_Wait);
    StoreImage(&rect, &data);

    for (y = 0, i = 0; y < 16; y++)
    {
        for (x = 0; x < 16; x++, i++)
        {
            if (!enableTransparency)
            {
                data[i] &= SHRT_MAX;
            }
            else
            {
                data[i] |= 1 << 15;
            }
        }
    }

    LoadImage(&rect, &data);
}

void WorldGfx_CharaModelMaterialSet(s32 charaId, s32 blendMode) // 0x8003D550
{
    s_CharaModel* model;

    model = g_WorldGfxWork.registeredCharaModels[charaId];
    Lm_MaterialFileIdxApply(model->lmHdr, CHARA_FILE_INFOS[charaId].textureFileIdx, &model->texture, blendMode);
    Lm_MaterialFlagsApply(model->lmHdr);
}

void WorldGfx_CharaLmBufferAssign(s8 forceFree) // 0x8003D5B4
{
    u8            charaId;
    s32           i;
#ifdef SH_PC_PORT
    /* PC: tracking the largest end-of-LM-header address. On PSX these all
     * fit in 32 bits so a u32 sufficed. On x64 with 8-byte pointers, the
     * `(s32)curModel->lmHdr` cast TRUNCATES the high 32 bits, and the
     * subsequent compare/assign through a `u32` lmData drops them too.
     * Result: charaLmBuffer ends up at a low-address truncation of the
     * real value, and the next chara model load lands at the wrong VRAM
     * region. Use uintptr_t throughout so the full 64-bit pointer math
     * survives. */
    uintptr_t     lmData;
#else
    u32           lmData;
#endif
    s_CharaModel* curModel;

    for (i = 0; i < ARRAY_SIZE(g_WorldGfxWork.charaModels); i++)
    {
        curModel = &g_WorldGfxWork.charaModels[i];
        if ((forceFree >> i) & (1 << 0))
        {
            WorldGfx_CharaFree(curModel);
        }
    }

    i = 0;
    g_WorldGfxWork.charaLmBuffer = MAP_CHARA_LM_BUFFER;
    for (; i < ARRAY_SIZE(g_WorldGfxWork.charaModels); i++)
    {
        curModel = &g_WorldGfxWork.charaModels[i];

        charaId = curModel->charaId;
        if (charaId != Chara_None)
        {
#ifdef SH_PC_PORT
            {
                /* A big-LM lmHdr is a heap pointer: heap + fileSize would hijack
                 * the slab bump cursor and the next chara load would fread into
                 * unowned memory. Account with the slab pointer the redirect
                 * displaced so the packing matches vanilla exactly. */
                s_LmHeader* baseLm = curModel->lmHdr;

                if (Pc_BigLm_IsOwned(baseLm))
                {
                    baseLm = Pc_BigLm_NativeOf(baseLm);
                }
                if (baseLm != NULL)
                {
                    lmData = (uintptr_t)baseLm + Fs_GetFileSize(CHARA_FILE_INFOS[charaId].modelFileIdx);
                    if ((uintptr_t)g_WorldGfxWork.charaLmBuffer < lmData)
                    {
                        g_WorldGfxWork.charaLmBuffer = (u8*)lmData;
                    }
                }
            }
#else
            lmData = (s32)curModel->lmHdr + Fs_GetFileSize(CHARA_FILE_INFOS[charaId].modelFileIdx);
            if (g_WorldGfxWork.charaLmBuffer < lmData)
            {
                g_WorldGfxWork.charaLmBuffer = lmData;
            }
#endif
        }
    }
}

void WorldGfx_CharaFree(s_CharaModel* model) // 0x8003D6A4
{
    if (model->charaId != Chara_None)
    {
        g_WorldGfxWork.registeredCharaModels[model->charaId] = NULL;
        CharaModel_Free(model);
    }
}

void WorldGfx_CharaLoad(e_CharaId charaId, s32 modeIdx, s_LmHeader* lmHdr, s_FsImageDesc* tex) // 0x8003D6E0
{
    s_FsImageDesc image;
    s_LmHeader*   lmHdrBuf;

    // Set LM header.
    if (lmHdr != NULL)
    {
        lmHdrBuf = lmHdr;
    }
    else if (g_WorldGfxWork.charaModels[modeIdx].charaId != Chara_None)
    {
        lmHdrBuf = g_WorldGfxWork.charaModels[modeIdx].lmHdr;
    }
    else
    {
        lmHdrBuf = (s_LmHeader*)g_WorldGfxWork.charaLmBuffer;
        WorldGfx_CharaLmBufferAdvance(&g_WorldGfxWork.charaLmBuffer, charaId);
    }

    // Set texture UVs.
    if (tex != NULL)
    {
        image = *tex;
    }
    else
    {
        Chara_FsImageCalc(&image, charaId, modeIdx);
    }

    WorldGfx_CharaModelLoad(charaId, modeIdx, lmHdrBuf, &image);
}

s32 WorldGfx_CharaModelLoad(e_CharaId charaId, s32 modelIdx, s_LmHeader* lmHdr, s_FsImageDesc* tex) // 0x8003D7D4
{
    s32            queueIdx;
    s32            modelCharaId; // `e_CharaId`
    s_CharaModel*  model;
    s_FsImageDesc* modelTex;

    model        = &g_WorldGfxWork.charaModels[modelIdx];
    modelCharaId = model->charaId;
    modelTex     = &model->texture;

    // If character is invalid, set model as unused.
    if (charaId == Chara_None)
    {
        g_WorldGfxWork.registeredCharaModels[modelCharaId] = NULL;
        return 0;
    }

    // Register character model.
    if (modelCharaId != Chara_None)
    {
        if (charaId == modelCharaId)
        {
            if (lmHdr == model->lmHdr && memcmp(tex, modelTex, sizeof(s_FsImageDesc)) == 0)
            {
                return 0;
            }
        }

        g_WorldGfxWork.registeredCharaModels[modelCharaId] = NULL;
    }
    g_WorldGfxWork.registeredCharaModels[charaId] = model;

    // Load model and texture files.
#ifdef SH_PC_PORT
    /* Keyed by the CURRENT modelFileIdx — CHARA_FILE_INFOS rows are retargeted
     * at runtime (PAL/JPN Mumbler swap, pool beta retargets), so charaId is not
     * a stable key. Substitutes regardless of the incoming lmHdr: the slot-reuse
     * path above can hand a previous chara's redirected buffer to a new chara. */
    lmHdr = Pc_BigLm_Redirect(CHARA_FILE_INFOS[charaId].modelFileIdx, lmHdr);
#endif
    queueIdx = Fs_QueueStartRead(CHARA_FILE_INFOS[charaId].modelFileIdx, lmHdr);
    if (CHARA_FILE_INFOS[charaId].textureFileIdx != NO_VALUE)
    {
        queueIdx = Fs_QueueStartReadTim(CHARA_FILE_INFOS[charaId].textureFileIdx, FS_BUFFER_1, tex);
    }

    // Set loaded model data.
    model->charaId  = charaId;
    model->isLoaded = false;
    model->queueIdx = queueIdx;
    model->lmHdr    = lmHdr;
    model->texture  = *tex;
    return queueIdx;
}

void WorldGfx_PlayerModelProcessLoad(void) // 0x8003D938
{
    WorldGfx_CharaModelProcessLoad(&g_WorldGfxWork.harryModel);
#ifdef SH_PC_PORT
    Pc_PlayAs_OnPlayerModelLoaded();
#endif
}

void WorldGfx_CharaModelProcessAllLoads(void) // 0x8003D95C
{
    s32           i;
    s_CharaModel* model;

    for (i = 0; i < Chara_Count; i++)
    {
        if (i != Chara_Harry)
        {
            model = g_WorldGfxWork.registeredCharaModels[i];
            if (model != NULL)
            {
                WorldGfx_CharaModelProcessLoad(model);
            }
        }
    }
}

void WorldGfx_CharaModelProcessLoad(s_CharaModel* model) // 0x8003D9C8
{
    s_Skeleton* skel;

    if (!model->isLoaded && model->charaId != Chara_None && Fs_QueueIsEntryLoaded(model->queueIdx))
    {
        model->isLoaded = true;

        LmHeader_FixOffsets(model->lmHdr);
        Lm_MaterialFileIdxApply(model->lmHdr, CHARA_FILE_INFOS[model->charaId].textureFileIdx, &model->texture, CHARA_FILE_INFOS[model->charaId].materialBlendMode % 4);

        skel = &model->skeleton;

        Lm_MaterialFlagsApply(model->lmHdr);
#ifdef SH_PC_PORT
        {
            s_LmHeader* lm = model->lmHdr;
            SH_DBG("[CHARA-TEX] charaId=%d matCount=%d modelCount=%d",
                    model->charaId, lm->materialCount, lm->modelCount);
            for (int _mi = 0; _mi < lm->materialCount; _mi++) {
                s_Material* _m = &lm->materials[_mi];
                SH_DBG("[CHARA-TEX] mat[%d] name='%.8s' field_C=%d E=0x%02x F=0x%02x clut=0x%04x UV=0x%04x tex=%p",
                        _mi, _m->name.str, _m->field_C, _m->field_E, _m->field_F,
                        _m->field_10, _m->field_14.u16, (void*)_m->texture);
            }
            /* Log first prim's texture data from first model's first mesh */
            if (lm->modelCount > 0 && lm->modelHdrs[0].meshCount > 0) {
                s_MeshHeader* _mh = &lm->modelHdrs[0].meshHdrs[0];
                if (_mh->primitiveCount > 0) {
                    s_Primitive* _p = &_mh->primitives[0];
                    SH_DBG("[CHARA-TEX] prim0: f0=0x%04x(UV0) f2=0x%04x(clut) f4=0x%04x(UV1) f6=0x%04x(tpage) f8=0x%04x(UV2) fA=0x%04x(UV3)",
                            _p->field_0, _p->field_2, _p->field_4, _p->field_6.flags, _p->field_8, _p->field_A);
                }
            }
            /* Check texture descriptor */
            SH_DBG("[CHARA-TEX] texDesc: tPage=[%d,%d] u=%d v=%d clutXY=(%d,%d)",
                    model->texture.tPage[0], model->texture.tPage[1],
                    model->texture.u, model->texture.v,
                    model->texture.clutX, model->texture.clutY);
        }
#endif
        Skeleton_Init(skel, model->skeleton.bones_C, 56);
        func_8004506C(skel, model->lmHdr);
        func_800452EC(skel);
        func_800453E8(skel, true);
    }
#ifdef SH_PC_PORT
    else {
    }
#endif
}

#ifdef SH_PC_PORT
/* Console SCALE for the character about to be drawn, Q12. Set by
 * Pc_Pick_CharaPreDraw and consumed by this draw, so a draw with no preceding
 * set -- the save/load screen Harry -- cannot inherit the last one. */
s32 g_PcCharaDrawScale = Q12(1.0f);
#endif

void func_8003DA9C(e_CharaId charaId, GsCOORDINATE2* boneCoords, s32 arg2, q3_12 timer, s32 arg4) // 0x8003DA9C
{
    CVECTOR tintColor = { 0 };
    s16     ret;

    // Check if character is valid.
    if (charaId == Chara_None)
    {
        return;
    }

    timer = CLAMP(timer, Q12(0.0f), Q12(1.0f));

    // Something to do with items held by player.
    if (charaId == Chara_Harry)
    {
#ifdef SH_PC_PORT
        /* Harry's held item/weapon is a separate model from his skeleton (drawn
         * further below), so it needs its own no-cast flag — otherwise his gun/
         * pipe/flashlight throws a flashlight shadow even though his body doesn't. */
        { extern int g_PsyX_NoShadowCast; g_PsyX_NoShadowCast = 1; }
#endif
        WorldGfx_HeldItemDraw();
#ifdef SH_PC_PORT
        { extern int g_PsyX_NoShadowCast; g_PsyX_NoShadowCast = 0; }
#endif
    }

    ret = func_8003DD74(charaId, arg4);

    if (timer != Q12(0.0f))
    {
        tintColor = g_WorldEnvWork.worldTintColor;

        func_80055330(g_WorldEnvWork.field_0, g_WorldEnvWork.field_20, g_WorldEnvWork.field_3,
                      Q12_MULT_PRECISE(Q12(1.0f) - timer, g_WorldEnvWork.worldTintColor.r) << 5,
                      Q12_MULT_PRECISE(Q12(1.0f) - timer, g_WorldEnvWork.worldTintColor.g) << 5,
                      Q12_MULT_PRECISE(Q12(1.0f) - timer, g_WorldEnvWork.worldTintColor.b) << 5,
                      g_WorldEnvWork.screenBrightness);

#ifdef SH_PC_PORT
        /* This IS the vanish for a Larval Stalker: timer is its timer_C6, and
         * at Q12(1.0) the scaling above drives the world tint AND the per-vertex
         * light matrix to zero, so the model should light to nothing. A capture
         * shows the state machine completing (timer_C6 4096/4096, health -1) with
         * the creature still plainly visible, so the question is whether the
         * values really arrive at zero here or the PC lighting path lights it
         * anyway. Logs the fade only near its end, once per second. */
        {
            static q19_12 s_next = 0;
            static s32    s_lines = 0;
            s_next -= g_DeltaTime;
            if (timer > Q12(0.5f) && s_lines < 24 && s_next <= 0)
            {
                s_next = Q12(1.0f);
                s_lines++;
                SH_DBG("[FADE] chara=%d timer=%d/%d tintIn=(%d,%d,%d) tintOut=(%d,%d,%d) light00=%d mode=%d fog=%d",
                       (int)charaId, (int)timer, (int)Q12(1.0f),
                       (int)tintColor.r, (int)tintColor.g, (int)tintColor.b,
                       (int)g_WorldEnvWork.worldTintColor.r, (int)g_WorldEnvWork.worldTintColor.g,
                       (int)g_WorldEnvWork.worldTintColor.b,
                       (int)g_WorldEnvWork.field_2C.m[0][0],
                       (int)g_WorldEnvWork.field_0, (int)g_WorldEnvWork.isFogEnabled);
            }
        }
#endif
    }

#ifdef SH_PC_PORT
    if (g_WorldGfxWork.registeredCharaModels[charaId] == NULL) {
        return;
    }
    { extern int g_PcFpsCam, g_PcHideHarryFpsBody, g_PcFpsSwingHeadShow;
      /* Hide Harry's head only during interactive FPS gameplay. Cutscenes (a
       * GameState_InGame substate, flagged by sysFlags/border) and load screens
       * (separate GameStates) use scripted cameras that frame him normally, so
       * keep his head there — a headless Harry in those looks wrong.
       *
       * SysState_Gameplay gate: on room entry the state passes through
       * event/load substates that DRAW the world with the game's own
       * (non-FPS) camera zooming toward Harry before control is handed over.
       * The FPS eye override (Pc_TpsCamera_Apply) only runs in the Gameplay
       * state, so only there is the view actually through Harry's eyes. Gating
       * on Gameplay keeps his head until the player is in full control at the
       * FPS spot — no more headless Harry during the room-entry camera zoom.
       *
       * g_PcFpsSwingHeadShow: while the melee arm-clearance dolly has pulled
       * the camera back behind the head, draw the head — the pulled swing
       * reads as a brief third-person beat instead of a headless body. */
      /* _atEye: the SysState_Gameplay gate flips before the game's room-entry
       * camera ease finishes, so the view can still be GLIDING toward the eye
       * with the head already hidden (headless Harry drifting into frame on
       * every room load). Only hide once the view has actually arrived. */
      int _atEye = 0;
      { VECTOR3 _vp;
        VECTOR3 _hp;
        vwGetViewPosition(&_vp);
        /* Compare against the live HEAD BONE, not g_PcFpsEyePos: the eye
         * global is written only while the FPS override runs and holds the
         * PREVIOUS room's value during the entry glide — often within
         * tolerance of the new spawn, so the head hid anyway. The bone is
         * always current. */
        vcMakeHeroHeadPos(&_hp);
        _atEye = (ABS(_vp.vx - _hp.vx) < Q12(0.55f) &&
                  ABS(_vp.vy - _hp.vy) < Q12(0.55f) &&
                  ABS(_vp.vz - _hp.vz) < Q12(0.55f)); }
      g_PcHideHarryFpsBody = (g_PcFpsCam && charaId == Chara_Harry
          && !g_PcFpsSwingHeadShow
          && _atEye
          && g_GameWork.gameState == GameState_InGame
          && g_SysWork.sysState == SysState_Gameplay
          && !(g_SysWork.sysFlags & SysFlag_CutsceneActive)
          && g_SysWork.cutsceneBorderState == CutsceneBorderState_None); }
    /* Harry doesn't cast a flashlight shadow — his own body between the light and
     * the scene looked odd. Flag his skeleton verts as non-casters for the depth
     * pre-pass (monsters still cast). Set here (build time) so the GTE captures it
     * per-vertex; cleared right after. */
    { extern int g_PsyX_NoShadowCast; g_PsyX_NoShadowCast = (charaId == Chara_Harry) ? 1 : 0; }
    /* Hand the same fade the block above applied to this character's LIGHTING to
     * the per-pixel flashlight, which adds its light on top of the TEXTURE and so
     * would otherwise relight a character the game has already faded to nothing.
     * That is a Larval Stalker's whole vanish: it fades out, and on Classic (no
     * per-pixel light) it duly disappears, while every Modern/shadow mode kept it
     * lit and standing there forever. Rides the view-space FIFO per vertex. */
    { extern float g_PsyX_CharaFade; g_PsyX_CharaFade = (float)timer / 4096.0f; }
    /* [CHARAPRIM]: the draw chain below (func_80057090 -> func_8005AC50) only ever
     * sees a model header, never a chara, so the probe's subject is stamped here —
     * the one place both are in scope. */
    { extern int g_PcCharaPrimProbe, g_PcCharaPrimProbeActive;
      g_PcCharaPrimProbeActive = (g_PcCharaPrimProbe != 0 && charaId == g_PcCharaPrimProbe); }
#endif
    func_80045534(&g_WorldGfxWork.registeredCharaModels[charaId]->skeleton, &g_OrderingTable0[g_ActiveBufferIdx], arg2,
                  boneCoords, Q8_TO_Q12(CHARA_FILE_INFOS[charaId].field_6), ret, CHARA_FILE_INFOS[charaId].field_8);

#ifdef SH_PC_PORT
    g_PcCharaDrawScale = Q12(1.0f);
#endif
#ifdef SH_PC_PORT
    { extern int g_PcCharaPrimProbeActive; g_PcCharaPrimProbeActive = 0; }
    { extern int g_PcHideHarryFpsBody; g_PcHideHarryFpsBody = 0; }
    { extern int g_PsyX_NoShadowCast; g_PsyX_NoShadowCast = 0; }
    { extern float g_PsyX_CharaFade; g_PsyX_CharaFade = 0.0f; }
#endif

    if (timer != Q12(0.0f))
    {
        func_80055330(g_WorldEnvWork.field_0, g_WorldEnvWork.field_20, g_WorldEnvWork.field_3, tintColor.r << 5, tintColor.g << 5, tintColor.b << 5, g_WorldEnvWork.screenBrightness);
    }
}

s32 func_8003DD74(e_CharaId charaId, s32 arg1) // 0x8003DD74
{
    return ((s32)arg1 << 10) & 0xFC00;
}

// ========================================
// ITEM ATTACHMENT
// ========================================

void WorldGfx_HeldItemAttach(e_CharaId charaId, s32 arg1) // 0x8003DD80
{
    s_CharaModel* model;

    model = g_WorldGfxWork.registeredCharaModels[charaId];

#ifdef SH_PC_PORT
    /* Model may not be loaded yet (async CD read pending). Skip attachment — it
     * will be re-invoked once the model is resident. */
    if (model == NULL) return;
#endif

    switch (charaId)
    {
        case Chara_Harry:
#ifdef SH_PC_PORT
            /* func_8003DE60's hand-variant lists are hard-coded HERO part
             * indices — on a play-as skin every equip would hide/show the
             * wrong meshes. Re-assert the skin's own table instead. */
            if (Pc_PlayAs_SuppressHarryHandVariants())
            {
                Pc_PlayAs_ApplySkinVisibility();
                break;
            }
#endif
            func_8003DE60(&model->skeleton, arg1);
            break;

        case Chara_Stalker:
            func_8003E388(&model->skeleton, arg1);
            break;

        case Chara_Cybil:
        case Chara_EndingCybil:
            func_8003DF84(&model->skeleton, arg1);
            break;

        case Chara_MonsterCybil:
            func_8003E08C(&model->skeleton, arg1);
            break;

        case Chara_Dahlia:
        case Chara_EndingDahlia:
            func_8003E194(&model->skeleton, arg1);
            break;

        case Chara_Kaufmann:
        case Chara_EndingKaufmann:
            func_8003E238(&model->skeleton, arg1);
            break;

        case Chara_SplitHead:
            func_8003E414(&model->skeleton, arg1);
            break;

        case Chara_PuppetNurse:
            func_8003E4A0(&model->skeleton, arg1);
            break;

        case Chara_PuppetDoctor:
            func_8003E544(&model->skeleton, arg1);
            break;
    }
}

void func_8003DE60(s_Skeleton* skel, s32 arg1) // 0x8003DE60
{
    s32 idx;

    static s32 D_800A9ECC = 0xFE16FD13;
    static s32 D_800A9ED0 = 0x0000FE13;
    static s32 D_800A9ED4 = 0x0000FE14;
    static s32 D_800A9ED8 = 0x0000FE15;
    static s32 D_800A9EDC = 0x0000FE16;
    static s32 D_800A9EE0 = 0x000000FE;
    static s32 D_800A9EE4 = 0x00FE1211;
    static s32 D_800A9EE8 = 0x0000FE11;
    static s32 D_800A9EEC = 0x0000FE12;

    // Process first masked value.
    idx = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (idx != 0)
    {
        func_80045468(skel, &D_800A9ECC, false);

        switch (idx)
        {
            case 1:
                func_80045468(skel, &D_800A9ED0, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9ED4, true);
                break;

            case 3:
                func_80045468(skel, &D_800A9ED8, true);
                break;

            case 4:
                func_80045468(skel, &D_800A9EDC, true);
                break;

            case 5:
                func_80045468(skel, &D_800A9EE0, true);
                break;
        }
    }

    // Process second masked value.
    idx = MODEL_BONE_IDX_1_GET(arg1);
    if (idx != 0)
    {
        func_80045468(skel, &D_800A9EE4, false);

        switch (idx)
        {
            case 1 << 4:
                func_80045468(skel, &D_800A9EE8, true);
                break;

            case 2 << 4:
                func_80045468(skel, &D_800A9EEC, true);
                break;
        }
    }
}

void func_8003DF84(s_Skeleton* skel, s32 arg1) // 0x8003DF84
{
    s32 idx;

    static s32 D_800A9EF0 = 0x0000FE14;
    static s32 D_800A9EF4 = 0x00FE1514;
    static s32 D_800A9EF8 = 0x0000FE12;
    static s32 D_800A9EFC = 0x00FE1312;

    idx = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (idx != 0)
    {
        switch (idx)
        {
            case 1:
                func_80045468(skel, &D_800A9EF4, false);
                func_80045468(skel, &D_800A9EF0, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9EF0, false);
                func_80045468(skel, &D_800A9EF4, true);
                break;
        }
    }

    idx = MODEL_BONE_IDX_1_GET(arg1);
    if (idx != 0)
    {
        switch (idx)
        {
            case 1 << 4:
                func_80045468(skel, &D_800A9EFC, false);
                func_80045468(skel, &D_800A9EF8, true);
                break;

            case 2 << 4:
                func_80045468(skel, &D_800A9EF8, false);
                func_80045468(skel, &D_800A9EFC, true);
                break;
        }
    }
}

void func_8003E08C(s_Skeleton* skel, s32 arg1) // 0x8003E08C
{
    s32 maskedVal;

    static s32 D_800A9F00 = 0x0000FE02;
    static s32 D_800A9F04 = 0x0000FE03;
    static s32 D_800A9F08 = 0x0000FE00;
    static s32 D_800A9F0C = 0x00FE0100;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal != 0)
    {
        switch (maskedVal)
        {
            case 1:
                func_80045468(skel, &D_800A9F04, false);
                func_80045468(skel, &D_800A9F00, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9F00, false);
                func_80045468(skel, &D_800A9F04, true);
                break;
        }
    }

    maskedVal = MODEL_BONE_IDX_1_GET(arg1);
    if (maskedVal != 0)
    {
        switch (maskedVal)
        {
            case 1 << 4:
                func_80045468(skel, &D_800A9F0C, false);
                func_80045468(skel, &D_800A9F08, true);
                break;

            case 2 << 4:
                func_80045468(skel, &D_800A9F08, false);
                func_80045468(skel, &D_800A9F0C, true);
                break;
        }
    }
}

void func_8003E194(s_Skeleton* skel, s32 arg1) // 0x8003E194
{
    s32 maskedVal;

    static s32 D_800A9F10 = 0xFE03FD00;
    static s32 D_800A9F14 = 0x0000FE00;
    static s32 D_800A9F18 = 0x00FE0201;
    static s32 D_800A9F1C = 0x0000FE03;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal != 0)
    {
        func_80045468(skel, &D_800A9F10, false);

        switch (maskedVal)
        {
            case 1:
                func_80045468(skel, &D_800A9F14, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9F18, true);
                break;

            case 3:
                func_80045468(skel, &D_800A9F1C, true);
                break;
        }
    }
}

void func_8003E238(s_Skeleton* skel, s32 arg1) // 0x8003E238
{
    s32 maskedVal;

    /* Kaufmann's hide list has the same cross-static terminator as the nurse's
     * (see func_8003E4A0). It currently survives an optimizing build only
     * because the static the linker happens to place next starts with a byte
     * this list already hides -- an accident, not a guarantee. */
    static s32 D_800A9F20[2] = { 0x06050403, 0x000000FE };
    static s32 D_800A9F28 = 0x0000FE03;
    static s32 D_800A9F2C = 0x0000FE04;
    static s32 D_800A9F30 = 0x00FE0504;
    static s32 D_800A9F34 = 0x00FE0603;
    static s32 D_800A9F38 = 0xFE020100;
    static s32 D_800A9F3C = 0x0000FE00;
    static s32 D_800A9F40 = 0x0000FE01;
    static s32 D_800A9F44 = 0x00FE0201;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal != 0)
    {
        func_80045468(skel, D_800A9F20, false);

        switch (maskedVal)
        {
            case 1:
                func_80045468(skel, &D_800A9F28, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9F2C, true);
                break;

            case 3:
                func_80045468(skel, &D_800A9F30, true);
                break;

            case 4:
                func_80045468(skel, &D_800A9F34, true);
                break;
        }
    }


    maskedVal = MODEL_BONE_IDX_1_GET(arg1);
    if (maskedVal != 0)
    {
        func_80045468(skel, &D_800A9F38, false);

        switch (maskedVal)
        {
            case 1 << 4:
                func_80045468(skel, &D_800A9F3C, true);
                break;

            case 2 << 4:
                func_80045468(skel, &D_800A9F40, true);
                break;

            case 3 << 4:
                func_80045468(skel, &D_800A9F44, true);
                break;
        }
    }
}

void func_8003E388(s_Skeleton* skel, s32 arg1) // 0x8003E388
{
    s32 maskedVal;

    static s32 D_800A9F48 = 0x0000FE05;
    static s32 D_800A9F4C = 0x0000FE06;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal != 0)
    {
        switch (maskedVal)
        {
            case 1:
                func_80045468(skel, &D_800A9F4C, false);
                func_80045468(skel, &D_800A9F48, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9F48, false);
                func_80045468(skel, &D_800A9F4C, true);
                break;
        }
    }
}

void func_8003E414(s_Skeleton* skel, s32 arg1) // 0x8003E414
{
    s32 maskedVal;

    static s32 D_800A9F50 = 0xFE19FD11;
    static s32 D_800A9F54 = 0xFE22FD1A;

    maskedVal = arg1 & 0x3;
    if (maskedVal == 0)
    {
        return;
    }

    switch (maskedVal)
    {
        case 1:
            func_80045468(skel, &D_800A9F50, false);
            func_80045468(skel, &D_800A9F54, true);
            break;

        case 2:
            func_80045468(skel, &D_800A9F54, false);
            func_80045468(skel, &D_800A9F50, true);
            break;
    }
}

void func_8003E4A0(s_Skeleton* skel, s32 arg1) // 0x8003E4A0
{
    s32 maskedVal;

    /* One byte stream, not two words: `Bone_ModelIdxGet` walks bytes forward
     * from the pointer it is given and only stops on -2, so the terminator for
     * this list lives in the word the PSX linker placed immediately after it.
     * Nothing names that second word, so an optimizing build drops it and
     * reorders what is left -- the walk then runs off the end of this list into
     * whatever static landed next (measured: Split Head's 0xFE22FD1A, which
     * hides bones 26-34 and took the nurse's back parasite with it). An array
     * makes the adjacency a language guarantee instead of a linker accident;
     * the emitted bytes are the PSX ones in the PSX order. */
    static s32 D_800A9F58[2] = { 0x05040302, 0x00FE0706 };
    static s32 D_800A9F60 = 0x00FE0502;
    static s32 D_800A9F64 = 0x00FE0603;
    static s32 D_800A9F68 = 0x00FE0704;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal != 0)
    {
        func_80045468(skel, D_800A9F58, false);

        switch (maskedVal)
        {
            case 1:
                func_80045468(skel, &D_800A9F60, true);
                break;

            case 2:
                func_80045468(skel, &D_800A9F64, true);
                break;

            case 3:
                func_80045468(skel, &D_800A9F68, true);
                break;
        }
    }
}

void func_8003E544(s_Skeleton* skel, s32 arg1) // 0x8003E544
{
    s32 maskedVal;

    /* Same cross-static byte stream as the nurse above -- kept contiguous by
     * the array so the terminator cannot be optimized away. */
    static s32 D_800A9F6C[2] = { 0x05040302, 0x00FE0706 };
    static s32 D_800A9F74 = 0x00FE0502;
    static s32 D_800A9F78 = 0x00FE0603;
    static s32 D_800A9F7C = 0x00FE0704;

    maskedVal = MODEL_BONE_MESH_VARIANT_IDX_GET(arg1);
    if (maskedVal == 0)
    {
        return;
    }

    func_80045468(skel, D_800A9F6C, false);

    switch (maskedVal)
    {
        case 1:
            func_80045468(skel, &D_800A9F74, true);
            break;

        case 2:
            func_80045468(skel, &D_800A9F78, true);
            break;

        case 3:
            func_80045468(skel, &D_800A9F7C, true);
            break;
    }
}

const s32 pad_rodata_80025BB0 = 0;
