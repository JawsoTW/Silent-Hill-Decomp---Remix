﻿#include "game.h"
#ifdef SH_PC_PORT
#include "sh_log.h"
#include <stdio.h>
#endif

#include <psyq/libetc.h>
#include <psyq/libpad.h>
#include <psyq/strings.h>

#include "bodyprog/bodyprog.h"
#include "bodyprog/game_boot/fs_chara_anim.h"
#include "bodyprog/demo.h"
#include "bodyprog/events/bodyprog_data_800A99B4.h"
#include "bodyprog/events/npc_main.h"
#include "bodyprog/events/radio.h"
#include "bodyprog/math/math.h"
#include "bodyprog/player.h"
#include "bodyprog/screen/screen_data.h"
#include "bodyprog/sound/sound_system.h"
#include "main/fsqueue.h"

#ifdef SH_PC_PORT
#include "pc_config.h"
static s32 Camera_Distance2dGet(const VECTOR3* pos);
extern int g_DebugAnimKfView;
extern int g_DebugViewNpcSlot;
void Pc_KeyframeViewerPoseNpc(s_AnmHeader* anmHdr, GsCOORDINATE2* boneCoords);
#include "pc_pick.h"
#endif

void Savegame_EnemyStateUpdate(s_SubCharacter* chara) // 0x80037DC4
{
#ifdef SH_PC_PORT
    /* Console/pool spawns reuse field_40 as their npc slot index, which here
     * would permanently dead-flag an UNRELATED native spawn row of the
     * current map in the savegame. Debug spawns carry no savegame identity. */
    {
        extern u8 g_PcNpcDebugSpawned[NPC_COUNT_MAX];
        s32       slot = chara - g_SysWork.npcs;

        if (slot >= 0 && slot < NPC_COUNT_MAX && g_PcNpcDebugSpawned[slot])
        {
            return;
        }
    }
#endif

    if (g_SavegamePtr->gameDifficulty <= GameDifficulty_Normal || Rng_RandQ12() >= Q12_ANGLE(108.0f))
    {
        g_SavegamePtr->ovlEnemyStates[g_SavegamePtr->mapIdx] &= ~(1 << chara->field_40);
    }
}

void Chara_DamagedFlagUpdate(s_SubCharacter* chara) // 0x80037E40
{
    if (chara->damage.amount > Q12(0.0f))
    {
        chara->flags |= CharaFlag_Damaged;
    }
    else
    {
        chara->flags &= ~CharaFlag_Damaged;
    }
}

void func_80037E78(s_SubCharacter* chara) // 0x80037E78
{
    s8  idx;
    s32 cond;

    // TODO: Strange `chara->headingAngle` access.
    if (chara->health <= Q12(0.0f) && (*(s32*)&chara->headingAngle & 0x600000) == 0x200000)
    {
        idx = chara->attackReceived;
        if (idx < 39) // TODO: What weapon attack?
        {
            cond = D_800AD4C8[idx].field_10 == 3;
            func_800914C4(cond, func_8009146C(cond) + 1);
        }

        chara->flags |= CharaFlag_Dead;
    }
}

void Game_NpcRoomInitSpawn(bool cond) // 0x80037F24
{
    s_CollisionSurface     coll;
    s32             groupCharaId0;
    s32             groupCharaId1;
    s32             npcIdx;
    s32             i;
    s32*            ovlEnemiesStatePtr;
    s_SpawnInfo*    curCharaSpawn;
    s_SubCharacter* chara;
    VECTOR3*        pos;

    npcIdx             = 0;
    curCharaSpawn      = g_MapOverlayHdr.charaSpawnInfos[0];
    ovlEnemiesStatePtr = &g_SavegamePtr->ovlEnemyStates[g_SavegamePtr->mapIdx];

    /* NOTE: a PC band-aid here used to force-clear SysFlag_NoEnemySpawn every
     * frame on non-tutorial maps ("streets enemy-less" during level-select
     * testing). That was VANILLA behavior — map2_s00 suppresses street
     * enemies pre-WaterWorks and clears the flag from its own events. The
     * blanket clear broke every cutscene that sets the flag to keep the
     * 3-slot NPC cap free: the map6_s04 Cybil boss cutscene's post-scene
     * Chara_Spawn found the cap filled by regular enemies and the boss
     * never spawned. Do not re-add. */

    if (cond == false)
    {
        func_80037154();

        if (g_MapOverlayHdr.npcSpawnEvent != NULL)
        {
            g_MapOverlayHdr.npcSpawnEvent();
        }
    }

    groupCharaId0 = g_MapOverlayHdr.charaGroupIds[0];
    groupCharaId1 = g_MapOverlayHdr.charaGroupIds[1];

#ifdef SH_PC_PORT
    /* Spawn diagnostic state. _spawnNearLogged[] holds the last logged
     * near/far state per slot (1=far, 2=near). On map change we reset it
     * so the new map's spawns log fresh on first encounter, and we keep
     * a periodic "closest spawn distance" tick so we can see if the
     * player is approaching ANY spawn at all over time. */
    static u8  _spawnNearLogged[64] = { 0 };
    static s8  _spawnLastMapId      = -1;
    static u32 _spawnTickCounter    = 0;
    if (_spawnLastMapId != g_SavegamePtr->mapIdx) {
        memset(_spawnNearLogged, 0, sizeof(_spawnNearLogged));
        _spawnLastMapId = g_SavegamePtr->mapIdx;
        _spawnTickCounter = 0;
    }
    /* Tick-throttled "closest spawn" log every ~5s so we can observe player
     * approach. Computed during the loop below â€” capture nearest distance. */
    s32 _closestDist  = 0x7FFFFFFF;
    s32 _closestSlot  = -1;
    s32 _closestX     = 0;
    s32 _closestZ     = 0;
    s8  _closestFlags = 0;
    int _shouldTickLog = (++_spawnTickCounter % 300 == 0); /* ~5s @60fps */

    /* Unlimited-enemies mode: override the map's per-room concurrent cap so
     * natural spawns can fill every npcs[] slot (the console SPAWN command
     * already bypasses the cap). Applied every frame AFTER the map's room-init
     * sets/increments npcFlagsId. Off = the map's original balance stands. */
    {
        extern int g_PcUnlimitedEnemies;
        if (g_PcUnlimitedEnemies)
            g_SysWork.npcFlagsId = NPC_COUNT_MAX;
    }
#endif

    for (i = 0; i < 32 && g_VBlanks < 4; i++, curCharaSpawn++)
    {
#ifdef SH_PC_PORT
        /* npcFlagsId can now reach 32 (NPC_COUNT_MAX); (1 << 32) is UB, so
         * saturate the "all slots occupied" mask to full when it does. */
        if ((u32)g_SysWork.npcFlags ==
            (g_SysWork.npcFlagsId >= 32 ? 0xFFFFFFFFu : ((1u << g_SysWork.npcFlagsId) - 1u)))
#else
        if (g_SysWork.npcFlags == ((1 << g_SysWork.npcFlagsId) - 1)) // TODO: Macro for this check?
#endif
        {
#ifdef SH_PC_PORT
            /* Hit the concurrent-NPC cap. Throttled log so we know if
             * this is the bottleneck. */
            static u32 _lastCapLog = 0;
            if (_spawnTickCounter - _lastCapLog > 300) {
                _lastCapLog = _spawnTickCounter;
            }
#endif
            break;
        }

#ifdef SH_PC_PORT
        /* CRITICAL: s_SpawnInfo is 12 bytes on PSX but 16 bytes on MinGW
         * x86-64. The s32:4 bitfield (gameDifficultyMin) forces gcc to
         * allocate a new s32 storage unit at offset 8, pushing positionZ
         * to offset 12. STATIC_ASSERT_SIZEOF is a no-op on PC so this size
         * change went silent. The old `pos = (VECTOR3*)curCharaSpawn` cast
         * made pos->vz read the bitfield slot (â‰ˆ0 for Easy) instead of
         * positionZ â€” every distance check saw Z=0, firing spawns at
         * coordinates totally unrelated to the actual spawn point. Build
         * a proper VECTOR3 with the correctly-typed fields and use that. */
        VECTOR3 spawnPos = { curCharaSpawn->positionX, 0, curCharaSpawn->positionZ };
        pos = &spawnPos;
#else
        pos = (VECTOR3*)curCharaSpawn;
#endif

#ifdef SH_PC_PORT
        /* Per-spawn diagnostic â€” log non-empty slots when conditions change
         * (especially when player gets close enough that distance gate
         * could pass). Logs once per (slot, near/far transition) to avoid
         * spam while still capturing the moment a spawn would activate. */
        if (curCharaSpawn->flags != 0) {
            VECTOR3* pp = &g_SysWork.playerWork.player.position;
            int gate7 = !Math_Distance2dCheck(pp, pos, Q12(22.0f));
            /* Track closest non-empty slot for the periodic tick log. */
            s32 dx = pp->vx - curCharaSpawn->positionX;
            s32 dz = pp->vz - curCharaSpawn->positionZ;
            /* Q12 squared-distance â€” keep it as squared to avoid sqrt cost. */
            s32 distSq = (s32)(((s64)dx * dx + (s64)dz * dz) >> 12);
            if (distSq < _closestDist) {
                _closestDist  = distSq;
                _closestSlot  = i;
                _closestX     = curCharaSpawn->positionX;
                _closestZ     = curCharaSpawn->positionZ;
                _closestFlags = curCharaSpawn->flags;
            }
            /* Only re-log on transitions: farâ†’near (gate7 went 0â†’1) or
             * if first time this slot ever evaluated. */
            u8 prevState = _spawnNearLogged[i];
            u8 curState = (gate7 ? 2 : 1); /* 1=far, 2=near */
            if (prevState != curState) {
                int gate1 = !(g_SysWork.sysFlags & SysFlag_NoEnemySpawn);
                int gate2 = HAS_FLAG(ovlEnemiesStatePtr, i) ? 1 : 0;
                int gate3 = !HAS_FLAG(g_SysWork.field_228C, i) ? 1 : 0;
                int gate5 = (g_SavegamePtr->gameDifficulty >= curCharaSpawn->gameDifficultyMin);
                int gate6 = func_8008F914(curCharaSpawn->positionX, curCharaSpawn->positionZ) ? 1 : 0;
                int gate8 = (!cond || Math_Distance2dCheck(pp, pos, Q12(20.0f)));
                _spawnNearLogged[i] = curState;
            }
        }
#endif

#ifdef SH_PC_PORT
        /* Mirror the spawn condition exactly so we can see WHICH gate is
         * the actual blocker. Diagnoses the case where SPAWN-GATE shows
         * all gates passing (g1..g8 = 1) but no NPC_SPAWN follows â€” the
         * difference must be a re-evaluation race, an aliasing issue,
         * or the npcFlags-full break above the loop. Logs once per slot
         * per second when the slot looks spawnable. */
        if (curCharaSpawn->flags != 0) {
            int dbg_g1 = !(g_SysWork.sysFlags & SysFlag_NoEnemySpawn);
            int dbg_g2 = HAS_FLAG(ovlEnemiesStatePtr, i) ? 1 : 0;
            int dbg_g3 = !HAS_FLAG(g_SysWork.field_228C, i) ? 1 : 0;
            int dbg_g5 = (g_SavegamePtr->gameDifficulty >= curCharaSpawn->gameDifficultyMin);
            int dbg_g6 = func_8008F914(curCharaSpawn->positionX, curCharaSpawn->positionZ) ? 1 : 0;
            int dbg_g7 = !Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(22.0f));
            int dbg_g8 = (!cond || Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(20.0f)));
            int allPass = dbg_g1 && dbg_g2 && dbg_g3 && dbg_g5 && dbg_g6 && dbg_g7 && dbg_g8;
            int npcFlagsFull = (g_SysWork.npcFlags == ((1 << g_SysWork.npcFlagsId) - 1));
            if (allPass) {
                static u32 _allPassTick[64] = { 0 };
                if (_allPassTick[i] == 0 || (_spawnTickCounter - _allPassTick[i]) > 60) {
                    SH_DBG("[SPAWN-FIRE?] slot=%d allPass! npcFlags=0x%x flagsId=%d full=%d vblanks=%d ABOUT TO TRY SPAWN",
                           i, (unsigned)g_SysWork.npcFlags, (int)g_SysWork.npcFlagsId,
                           npcFlagsFull, (int)g_VBlanks);
                    _allPassTick[i] = _spawnTickCounter;
                }
            }
        }
#endif

#ifdef SH_PC_PORT
        /* Per-slot post-spawn cooldown. Without it the spawn loop and the
         * Game_NpcUpdate despawn check (line ~439, despawn at >40u) form
         * an oscillator on PC: spawn fires while player is <22u, despawn
         * fires same frame because of how player position evaluates against
         * the npc->position chain on PC, NPC slot is freed, next frame
         * spawns again. Repeats thousands of times â†’ eventually corrupts
         * downstream state and crashes after Player_UpperBodyUpdate.
         *
         * Fix: once a slot has spawned, hold off re-spawning it for 60
         * ticks (~1s @60fps). Enough to break the same-frame oscillator
         * but short enough to preserve vanilla PSX spawn density â€” the
         * original 600-tick value was suppressing town enemies way more
         * than the original game. Despawn still works to clear the slot;
         * the cooldown just prevents the immediate respawn race. */
        static u32 _slotSpawnCooldown[64] = { 0 };
        if (_slotSpawnCooldown[i] > 0) {
            _slotSpawnCooldown[i]--;
        }
        /* Log when cooldown is blocking a slot that otherwise wants to spawn. */
        if (curCharaSpawn->flags != 0 && _slotSpawnCooldown[i] > 0 &&
            !HAS_FLAG(g_SysWork.field_228C, i)) {
            /* Quick mirror of the distance gate to know if cooldown is the
             * actual blocker (player IS in range but cooldown gates). */
            int near22 = !Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(22.0f));
            if (near22) {
                static u32 _cdLog[64] = { 0 };
                if (_cdLog[i] == 0 || (_spawnTickCounter - _cdLog[i]) > 60) {
                    _cdLog[i] = _spawnTickCounter;
                }
            }
        }
#endif

        if (!(g_SysWork.sysFlags & SysFlag_NoEnemySpawn) &&
            HAS_FLAG(ovlEnemiesStatePtr, i) && !HAS_FLAG(g_SysWork.field_228C, i) &&
            curCharaSpawn->flags != 0 &&
            g_SavegamePtr->gameDifficulty >= curCharaSpawn->gameDifficultyMin &&
            func_8008F914(curCharaSpawn->positionX, curCharaSpawn->positionZ) &&
#ifdef SH_PC_PORT
            /* The PSX spawn ring (20..22u) sits inside the fog. With the fog
             * thinned the ring is in plain sight, so spawn anywhere out of the
             * camera's view instead, nearer or further than the ring. */
            (Pc_LongViewActive()
                 ? (!Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(30.0f)) &&
                    (!cond || (Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(12.0f)) &&
                               !Pc_WorldPointInView(curCharaSpawn->positionX, curCharaSpawn->positionZ))))
                 : (!Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(22.0f)) &&
                    (!cond || Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(20.0f)))))
            && _slotSpawnCooldown[i] == 0
#else
            !Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(22.0f)) &&
            (!cond || Math_Distance2dCheck(&g_SysWork.playerWork.player.position, pos, Q12(20.0f)))
#endif
            )
        {
#ifdef SH_PC_PORT
            SH_DBG("[SPAWN-FIRE!] slot=%d gates passed â†’ entering spawn block, npcIdx will be assigned", i);
            _slotSpawnCooldown[i] = 60;  /* ~1s @60fps -- minimal oscillator guard */
#endif
            while (HAS_FLAG(&g_SysWork.npcFlags, npcIdx))
            {
                npcIdx++;
            }

            bzero(&g_SysWork.npcs[npcIdx], sizeof(s_SubCharacter));

#ifdef SH_PC_PORT
            /* Native spawn reuses this slot: a stale debug-spawn flag here
             * would make Savegame_EnemyStateUpdate skip THIS enemy's
             * kill-record write (permadeath bit) for the whole map session. */
            {
                extern u8 g_PcNpcDebugSpawned[NPC_COUNT_MAX];
                g_PcNpcDebugSpawned[npcIdx] = 0;
            }
#endif

            if (curCharaSpawn->charaId > Chara_None)
            {
                g_SysWork.npcs[npcIdx].model.charaId = curCharaSpawn->charaId;
            }
            else
            {
                g_SysWork.npcs[npcIdx].model.charaId = (i < 16) ? groupCharaId0 : groupCharaId1;
            }

            g_SysWork.npcs[npcIdx].field_40           = i;
            g_SysWork.npcs[npcIdx].model.controlState = 0;
            g_SysWork.npcs[npcIdx].model.stateStep    = curCharaSpawn->flags;
#ifdef SH_PC_PORT
            /* Remix enemies: this spawn row's monster type for the seed. */
            {
                extern int  Pc_Remix_EnemiesOn(void);
                extern void Pc_Remix_EnemyReroll(s32 row, s8* charaId, u8* stateStep);
                if (Pc_Remix_EnemiesOn())
                    Pc_Remix_EnemyReroll(i, &g_SysWork.npcs[npcIdx].model.charaId,
                                         &g_SysWork.npcs[npcIdx].model.stateStep);
            }
#endif
#ifdef SH_PC_PORT
            SH_DBG("[SPAWN] slot=%d -> npc[%d] charaId=%d stateStep=%d pos=(%d,%d)",
                   i, npcIdx, (int)g_SysWork.npcs[npcIdx].model.charaId,
                   (int)curCharaSpawn->flags,
                   FP_FROM(curCharaSpawn->positionX, Q12_SHIFT),
                   FP_FROM(curCharaSpawn->positionZ, Q12_SHIFT));
#endif
            g_SysWork.npcs[npcIdx].position.vx        = curCharaSpawn->positionX;
            g_SysWork.npcs[npcIdx].position.vz        = curCharaSpawn->positionZ;

            Collision_SurfaceGet(&coll, curCharaSpawn->positionX, curCharaSpawn->positionZ);

            g_SysWork.npcs[npcIdx].position.vy = coll.groundHeight;
            g_SysWork.npcs[npcIdx].rotation.vy = Q8_TO_Q12(curCharaSpawn->rotationY);

            SET_FLAG(&g_SysWork.npcFlags, npcIdx);
            SET_FLAG(g_SysWork.field_228C, i);

            chara                    = &g_SysWork.npcs[npcIdx];
            chara->model.anim.flags |= AnimFlag_Visible;
        }
    }

#ifdef SH_PC_PORT
    /* Periodic tick log: every ~5 seconds, dump player position and the
     * closest non-empty spawn slot. Lets us trace whether the player is
     * actually approaching ANY spawn while wandering, even when no slot
     * crosses the 22u trigger. Helps diagnose "streets are empty" â€” if
     * closestDist stays > 22 forever, the player just hasn't walked
     * close enough yet (or is blocked from doing so). */
    if (_shouldTickLog && _closestSlot >= 0) {
        VECTOR3* pp = &g_SysWork.playerWork.player.position;
        /* _closestDist is squared in Q12 already; rough sqrt for log
         * readability â€” log it as squared too so we don't pull in
         * SquareRoot12 from here. */
    }
#endif
}

#ifdef SH_PC_PORT
/* Spawned cutscene actors (charaId >= Chara_Cybil) have no AI update func in a
 * foreign map, so Game_NpcUpdate's render-only fallback poses keyframe 0 and they
 * freeze. For the human actors whose standing-idle clip (anim index 1) range is
 * known, the fallback loops it instead of freezing. Ranges transcribed from the
 * per-map-overlay *_ANIM_INFOS (those symbols aren't linked into other maps):
 *   Cybil    (26) cybil.h:88    kf 0..15
 *   Dahlia   (30) dahlia.h:76   kf 0..15
 *   Lisa     (32) lisa.h:67     kf 0..9
 *   Kaufmann (38) kaufmann.h:70 kf 0..5
 * Non-human render-only ids in the same band (Cat, Alessa, Flauros, Incubator,
 * Parasite, …) are EXCLUDED — anim 1 there is a walk/attack, not an idle. Cheryl
 * and the ending/bloody variants use different ANM files / unverified ranges, so
 * they keep the static pose until their idle range is confirmed. */
static bool Pc_ActorIdleClipGet(s32 charaId, s16* outStartKf, s16* outEndKf, q19_12* outDur)
{
    s16 s, e;
    switch (charaId)
    {
        case Chara_Cybil:    s = 0; e = 15; break;
        case Chara_Dahlia:   s = 0; e = 15; break;
        case Chara_Lisa:     s = 0; e = 9;  break;
        case Chara_Kaufmann: s = 0; e = 5;  break;
        default: return false;
    }
    *outStartKf = s;
    *outEndKf   = e;
    *outDur     = Q12(5.0f);
    return true;
}
#endif

// Un-nested from Game_NpcUpdate: Clang has no GCC nested-function extension, so
// every Apple toolchain rejects the original form. The captured parent locals
// (field_0[], field_40) are threaded through explicitly, which is why field_40
// arrives by pointer — func_800382EC writes to it. The typedef moves out with
// them because both signatures name it.
typedef struct
{
    s8      bitIdx_0;
    u8      unk_1[3];
    s32     field_4;
    VECTOR3 field_8;
} s_func_800382EC_0;

static s32 func_800382B0(const s_func_800382EC_0* field_0, s32 arg0)
{
    s32 i;

    for (i = 0; i < 2; i++)
    {
        if (arg0 == field_0[i].bitIdx_0)
        {
            return i;
        }
    }

    return NO_VALUE;
}

static s32 func_800382EC(const s_func_800382EC_0* field_0, u32* field_40)
{
    s32 i;

    for (i = 0; i < 2; i++)
    {
        if (field_0[i].bitIdx_0 == NO_VALUE)
        {
            break;
        }

        if ((*field_40 & (1 << field_0[i].bitIdx_0)) == 0)
        {
            *field_40 |= (1 << field_0[i].bitIdx_0);
            return i;
        }
    }

    return NO_VALUE;
}

void Game_NpcUpdate(void) // 0x80038354
{
    s_func_800382EC_0  field_0[3];
    u32                field_40;
    s32                posZShift6;
    s32                posXShift6;
    s32                temp_t1;
    s32                m;
    u8                 var_a2_2;
    s32                j;
    s32                var_s3;
    s32                k;
    s32                var_t5;
    s32                var_v0_4;
    s32                var_v1_3;
    s32                temp_s0_2;
    s32                temp_s0_4;
    s8                 temp_s1;
    s32                temp_v0_4;
    s32                var_v0_5;
    u32                temp_t3;
    u8                 temp_a2;
    u32                new_var;
    s32                l;
    s32                animDataInfoIdx;
    s32                temp2;
    GsCOORDINATE2*     boneCoords;
    s_SubCharacter*    npc;
    s_func_800382EC_0* temp_s0_3;

    posXShift6 = Q12_TO_Q6(g_SysWork.playerWork.player.position.vx);
    posZShift6 = Q12_TO_Q6(g_SysWork.playerWork.player.position.vz);

    Demo_DemoRandSeedBackup();
    Demo_DemoRandSeedRestore();

    for (j = 0; j < ARRAY_SIZE(field_0); j++)
    {
        field_0[j].bitIdx_0   = NO_VALUE;
        field_0[j].field_4    = Q12(0.25f);
        field_0[j].field_8.vy = 0;
    }

    for (k = 0, npc = g_SysWork.npcs; k < ARRAY_SIZE(g_SysWork.npcs); k++, npc++)
    {
        if (npc->model.charaId != Chara_None && npc->model.charaId != Chara_Padlock)
        {
            if (npc->model.charaId <= Chara_MonsterCybil)
            {
                temp_t3 = Q12_SQUARE_PRECISE(Q12_TO_Q6(npc->position.vx) - posXShift6) +
                          Q12_SQUARE_PRECISE(Q12_TO_Q6(npc->position.vz) - posZShift6);
                var_t5 = 0;

                if (g_MapOverlayHdr.mapInfo->flags & MapFlag_Interior)
                {
                    var_t5 = (g_MapOverlayHdr.mapInfo->flags & (MapFlag_OneActiveChunk | MapFlag_TwoActiveChunks)) > 0;
                }

#ifdef SH_PC_PORT
                /* Once-per-second per-NPC tracking trace. Logs why an alive
                 * NPC is or isn't being inserted into field_0[] (the radio's
                 * NPC tracker). Helps diagnose silent radio: if temp_t3
                 * stays > 1024 the NPC is out of radio range; if health
                 * stays <=0 the NPC never got Init'd; etc. */
                {
                    static u32 _trkTick[6] = { 0 };
                    static u32 _trkCounter = 0;
                    if (k == 0) _trkCounter++;
                    if (k < 6 && (_trkCounter - _trkTick[k]) > 60) {
                        _trkTick[k] = _trkCounter;
                    }
                }
#endif

                for (j = 0; j < 3; j++)
                {
#ifdef SH_PC_PORT
                    /* Use health < 0 (strictly negative) rather than <= 0.
                     * NPCs spawn with health=0 before Ai_Init runs on the
                     * same frame; excluding them at health==0 caused the radio
                     * to miss the spawn-frame window. Dead NPCs (took damage)
                     * have negative health, so they stop being tracked and the
                     * radio static stops when the monster dies. */
                    if (npc->health < Q12(0.0f) || npc->flags & CharaFlag_NoRadioStatic || temp_t3 >= field_0[j].field_4)
                    {
                        continue;
                    }
#else
                    if (npc->health <= Q12(0.0f) || npc->flags & CharaFlag_NoRadioStatic || temp_t3 >= field_0[j].field_4)
                    {
                        continue;
                    }
#endif

                    if (var_t5 != 0)
                    {
                        s32 playerCell = (g_SysWork.playerWork.player.position.vx + (CHUNK_CELL_SIZE * 4)) / CHUNK_CELL_SIZE;
                        s32 npcCell    = (npc->position.vx                        + (CHUNK_CELL_SIZE * 4)) / CHUNK_CELL_SIZE;
                        if (npcCell != playerCell)
                        {
                            continue;
                        }

                        // TODO: Unique vars for these.
                        playerCell = (g_SysWork.playerWork.player.position.vz + (CHUNK_CELL_SIZE * 4)) / CHUNK_CELL_SIZE;
                        npcCell    = (npc->position.vz                        + (CHUNK_CELL_SIZE * 4)) / CHUNK_CELL_SIZE;
                        if (npcCell != playerCell)
                        {
                            continue;
                        }
                    }

                    for (m = 2; j < m; m--)
                    {
                        field_0[m].bitIdx_0   = field_0[m - 1].bitIdx_0;
                        field_0[m].field_4    = field_0[m - 1].field_4;
                        field_0[m].field_8.vx = field_0[m - 1].field_8.vx;
                        field_0[m].field_8.vz = field_0[m - 1].field_8.vz;
                    }

                    temp_t1 = (uintptr_t)npc - (uintptr_t)g_SysWork.npcs;
                    temp2   = ((((temp_t1 * 0x7E8) - (temp_t1 * 0xFD)) * 4) + temp_t1) * -0x3FFFF;

#ifdef SH_PC_PORT
                    /* The MIPS-compiler reciprocal-multiply above computes
                     * `temp_t1 / sizeof(s_SubCharacter)` to recover the NPC
                     * array index k. The constants (0x7E8, 0xFD, -0x3FFFF)
                     * are baked for PSX struct sizes; on PC s_SubCharacter
                     * is larger so the formula gives garbage. Just use k
                     * directly â€” it IS the array index. */
                    field_0[j].bitIdx_0   = (s8)k;
#else
                    field_0[j].bitIdx_0   = temp2 >> 3;
#endif
                    field_0[j].field_4    = temp_t3;
                    field_0[j].field_8.vx = npc->position.vx;
                    field_0[j].field_8.vz = npc->position.vz;
                    break;
                }

                new_var = temp_t3;

#ifdef SH_PC_PORT
                /* Thinned fog: despawn only out of view, and alive ones further
                 * out than the 30u spawn reach. 80u frees the slot regardless. */
                if (Pc_LongViewActive()
                        ? (new_var > SQUARE(80) ||
                           (new_var > ((var_t5 == 0 && npc->health < Q12(0.0f)) ? SQUARE(24) : SQUARE(48)) &&
                            !Pc_WorldPointInView(npc->position.vx, npc->position.vz)))
                        : (new_var > ((var_t5 == 0 && npc->health < Q12(0.0f)) ? SQUARE(24) : SQUARE(40))))
#else
                if (new_var > ((var_t5 == 0 && npc->health < Q12(0.0f)) ? SQUARE(24) : SQUARE(40)))
#endif
                {
                    npc->model.charaId = Chara_None;
                    SysWork_NpcFlagClear(k);
                    CLEAR_FLAG(g_SysWork.field_228C, npc->field_40);
#ifdef SH_PC_PORT
                    /* Slot freed: drop any debug-spawn flag with it (its own
                     * Savegame_EnemyStateUpdate already ran at kill time). */
                    {
                        extern u8 g_PcNpcDebugSpawned[NPC_COUNT_MAX];
                        g_PcNpcDebugSpawned[k] = 0;
                    }
#endif
                    continue;
                }

#ifdef SH_PC_PORT
                /* The 15u hide is the fog's edge; past it a thinned fog would
                 * show monsters blinking out mid-street. */
                if (!Pc_LongViewActive() &&
                    ((g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & 0x2 && temp_t3 > SQUARE(15)) ||
                     (!(g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & 0x2) &&
                      Camera_Distance2dGet(&npc->position) > SQUARE(15))))
#else
                if ((g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & 0x2 && temp_t3 > SQUARE(15)) ||
                    (!(g_SysWork.field_2388.field_154.effectsInfo_0.field_0.s_field_0.field_0 & 0x2) &&
                     Camera_Distance2dGet(&npc->position) > SQUARE(15)))
#endif
                {
                    npc->model.anim.flags &= ~AnimFlag_Visible;
                }
                else
                {

                    npc->model.anim.flags |= AnimFlag_Visible;
                }
            }

            npc->model.anim.flags |= AnimFlag_Unlocked;

            animDataInfoIdx = g_CharaAnimDataIdxs[npc->model.charaId];
#ifdef SH_PC_PORT
            /* On PC only Cheryl's NPC AI is safe to run. All other NPCs
             * (Cybil, monsters, grey children) have AI that crashes due to
             * unsupported subsystems (collision, PSX-specific state).
             * Also skip if anim data not loaded yet (idx==0xFF) or update
             * function pointer is NULL (sanitized out by map overlay loader). */
            {
                bool animLoaded  = ((s8)animDataInfoIdx != (s8)0xFF);
                bool hasUpdateFn = (npc->model.charaId < (e_CharaId)ARRAY_SIZE(g_MapOverlayHdr.charaUpdateFuncs) &&
                                    g_MapOverlayHdr.charaUpdateFuncs[npc->model.charaId] != NULL);
                /* Whitelist RETIRED (batch 3). It existed because early-port
                 * NPC AI crashed on missing data; the extraction sweep fixed
                 * the causes, and the per-id list kept silently KILLING every
                 * unlisted spawn (charaId = Chara_None) — invisible school
                 * cat, missing Mumbler/NightFlutter/Wormhead, missing ending
                 * cutscene actors. Every chara now runs full AI; the safety
                 * fallbacks below still apply (wait for anim load,
                 * render-only when the update func is NULL). If a specific
                 * chara crashes, add a TARGETED skip for that id here. */
                bool isFullAiNpc = true;
                /* No render-only set â€” kept as opt-out for any future NPC that
                 * really only needs the model and not the full AI dispatch. */
                bool isRenderOnlyNpc = false;

                /* NOTE: a per-frame `flags |= AnimFlag_Visible` force-set for
                 * charaId > Chara_MonsterCybil used to live here. Chara_Spawn
                 * already sets the flag at spawn (chara_spawn.c), and the
                 * authentic per-frame distance show/hide only covers ids <= 24
                 * — high ids are meant to keep their spawn-time flag until
                 * game code hides/shows them explicitly. The force-set fought
                 * every legitimate hide (cutscene actors, scripted reveals). */

                if (!animLoaded || !isFullAiNpc)
                {
                    if (isFullAiNpc && !animLoaded)
                    {
                        /* Anim data not loaded yet (Chara_Spawn just happened this
                         * frame, async ANM read still pending). Do NOT kill the
                         * NPC â€” the slot would get wiped and game code expecting
                         * npcs[slot] to hold this chara (e.g. map0_s01 BIRD
                         * fly-by) would dereference an empty slot and crash.
                         * Just skip AI this tick and wait for load to complete. */
                        static u32 _animWaitLogged = 0;
                        if (!(_animWaitLogged & (1u << (npc->model.charaId & 31)))) {
                            _animWaitLogged |= (1u << (npc->model.charaId & 31));
                        }
                    }
                    else if (isRenderOnlyNpc)
                    {
                        /* Keep render-only NPCs alive even while ANM is still loading. */
                        if (animLoaded && (npc->model.anim.flags & AnimFlag_Visible)) {
#ifdef SH_PC_PORT
                            Pc_Pick_CharaPreDraw(npc, (int)(npc - g_SysWork.npcs),
                                                 g_CharaModelAnimsData[animDataInfoIdx].boneCoords);
#endif
                            func_8003DA9C(npc->model.charaId,
                                          g_CharaModelAnimsData[animDataInfoIdx].boneCoords,
                                          1, npc->timer_C6,
                                          (s8)npc->model.paletteIdx);
                        }
                    }
                    else
                    {
                        /* Fully unsafe NPC â€” remove so it doesn't keep firing. */
                        npc->model.charaId = Chara_None;
                    }
                    continue;
                }
                if (!hasUpdateFn)
                {
                    /* Map overlay's charaUpdateFunc was NULL (likely sanitized
                     * out by map_overlay_loader for an un-decompiled stub).
                     * Don't kill the NPC â€” keep it alive so the model can
                     * render even without AI driving it. */
                    static u32 _noUpdateFnLogged = 0;
                    if (!(_noUpdateFnLogged & (1u << (npc->model.charaId & 31)))) {
                        _noUpdateFnLogged |= (1u << (npc->model.charaId & 31));
                    }
                    if (animLoaded && (npc->model.anim.flags & AnimFlag_Visible)) {
                        s_AnmHeader*   statueHdr = g_CharaModelAnimsData[animDataInfoIdx].activeAnmHdr;
                        GsCOORDINATE2* statueBc  = g_CharaModelAnimsData[animDataInfoIdx].boneCoords;

                        /* Statue pose: an AI update func normally poses the
                         * skeleton AND writes the NPC's world transform into
                         * the root coord — without it the model renders at
                         * the world origin (invisible in practice). Pose
                         * keyframe 0 and place the root every frame (same
                         * recipe as the cutscene actors' update funcs). */
                        if (statueHdr != NULL) {
#ifdef SH_PC_PORT
                            s16    idleStart, idleEnd;
                            q19_12 idleDur;
                            if (Pc_ActorIdleClipGet(npc->model.charaId, &idleStart, &idleEnd, &idleDur)) {
                                /* Loop the standing-idle clip so spawned human actors
                                 * breathe instead of freezing at keyframe 0.
                                 * Anim_PlaybackLoop reads only this stack info and poses
                                 * bones 1+; the root placement below still applies (it
                                 * never writes bone 0). model.anim.time is per-npc and was
                                 * zeroed at spawn; AnimFlag_Unlocked is already set above. */
                                s_AnimInfo idle;
                                idle.playbackFunc        = Anim_PlaybackLoop;
                                idle.status              = 0;
                                idle.hasVariableDuration = 0;
                                idle.linkStatus          = 0;
                                idle.duration.constant   = idleDur;
                                idle.startKeyframeIdx    = idleStart;
                                idle.endKeyframeIdx      = idleEnd;
                                Anim_PlaybackLoop(&npc->model, statueHdr, statueBc, &idle);
                            } else
#endif
                            Anim_BoneUpdate(statueHdr, statueBc, 0, 0, Q12(0.0f));
                            Math_RotMatrixZxyNegGte(&npc->rotation, &statueBc->coord);
                            statueBc->coord.t[0] = Q12_TO_Q8(npc->position.vx);
                            statueBc->coord.t[1] = Q12_TO_Q8(npc->position.vy);
                            statueBc->coord.t[2] = Q12_TO_Q8(npc->position.vz);
                            statueBc->flg = 0;
                        }
#ifdef SH_PC_PORT
                        Pc_Pick_CharaPreDraw(npc, (int)(npc - g_SysWork.npcs),
                                             g_CharaModelAnimsData[animDataInfoIdx].boneCoords);
#endif
                        func_8003DA9C(npc->model.charaId,
                                      g_CharaModelAnimsData[animDataInfoIdx].boneCoords,
                                      1, npc->timer_C6,
                                      (s8)npc->model.paletteIdx);
                    }
                    continue;
                }
            }
            /* Reset stateStep only on the first frame after spawn so
             * Model_AnimStatusSet can fire once.  Don't reset every frame
             * or anim status transitions (blendâ†’playback) get stuck. */
            if (npc->model.charaId == Chara_Cheryl)
            {
                static bool _cherylInitDone = false;
                if (!_cherylInitDone) {
                    npc->model.stateStep = 0;
                    _cherylInitDone = true;
                }
            }
            /* Same spawn-init pattern for Cybil/AirScreamer: reset stateStep
             * once on first AI tick so Model_AnimStatusSet fires and the NPC
             * actually enters its state machine. Without this the NPC appears
             * loaded but never animates.  Per-slot guard keyed on charaId so
             * a second spawn after the first dies re-inits.
             *
             * NOT applied to GreyChild/Stalker: their AI uses stateStep as
             * an init-switch selector (stateStep_5 / _6 / _7 etc map to
             * different StalkerControl_X states).  map0_s00_2.c rewrites
             * controlState=Uninitialized + stateStep=6 after the corpse
             * cutscene to make them aggressive; resetting stateStep to 0
             * here would break that handoff and leave them stuck in the
             * Init->switch-no-match->Init loop forever. */
            else if (npc->model.charaId == Chara_Cybil ||
                     npc->model.charaId == Chara_AirScreamer)
            {
                /* Per-slot latch â€” fire ONCE per spawn, not every frame
                 * the NPC happens to be at controlState==None.
                 *
                 * Original code stomped stateStep=0 every frame
                 * controlState was 0, which broke the cutsceneâ†’combat
                 * handoff: Air Screamer's intro sets controlState=None
                 * + stateStep=7 to transition into Control_46 (combat
                 * dive); the next NpcUpdate would then immediately
                 * stomp stateStep back to 0, killing the handoff and
                 * leaving the AS in StandIdle forever. Same family
                 * also affects Cybil combat in later levels.
                 *
                 * Latch resets when the slot is cleared (charaId â†’
                 * Chara_None on death/despawn) so a respawn re-arms. */
                static u8 _spawnInitDone[3]   = { 0, 0, 0 };
                static u8 _lastInitCharaId[3] = { 0xFF, 0xFF, 0xFF };
                if (k < 3) {
                    /* Re-arm latch if the slot's charaId changed
                     * (despawn/respawn cycle, including a new NPC
                     * occupying the same slot). */
                    if (npc->model.charaId != _lastInitCharaId[k]) {
                        _spawnInitDone[k] = 0;
                        _lastInitCharaId[k] = npc->model.charaId;
                    }
                    if (!_spawnInitDone[k] && npc->model.controlState == 0) {
                        npc->model.stateStep = 0;
                        _spawnInitDone[k] = 1;
                    }
                }
            }
#endif
            boneCoords      = g_CharaModelAnimsData[animDataInfoIdx].boneCoords;

            Chara_Flag8Clear(npc);
            Chara_DamagedFlagUpdate(npc);
            Collision_FlagsLocationUpdate(npc);

#ifdef SH_PC_PORT
            /* Guard against NULL animFile for any NPC: the playback function
             * always dereferences animHdr for bone data, so NULL crashes.
             * Cheryl logs details; other NPCs (e.g. grey children) just wait
             * until Chara_ProcessLoads() completes their ANM read. */
            if (g_CharaModelAnimsData[animDataInfoIdx].activeAnmHdr == NULL) {
                if (npc->model.charaId == Chara_Cheryl) {
                } else {
                }
                continue;
            }
#endif
#ifdef SH_PC_PORT
            if (Pc_Pick_NpcTick(npc, (int)(npc - g_SysWork.npcs)))
            {
                /* Console FREEZE: no AI tick, so the bones keep last frame's
                 * pose and the enemy neither moves nor attacks. */
            }
            else if (g_DebugAnimKfView && g_DebugViewNpcSlot == k)
            {
                /* Keyframe viewer is inspecting this NPC: pose it from the
                 * inspector (freeze/loop) instead of running its AI + per-frame
                 * housekeeping, so it holds still for inspection. The draw below
                 * still renders the posed skeleton. */
                Pc_KeyframeViewerPoseNpc(g_CharaModelAnimsData[animDataInfoIdx].activeAnmHdr, boneCoords);
            }
            else
#endif
            {
#ifdef SH_PC_PORT
                /* Remix enemies: sounds this AI plays are its monster's. */
                extern int  Pc_RemixSfx_On(void);
                extern void Pc_RemixSfx_Updating(const void* npc);
                if (Pc_RemixSfx_On())
                    Pc_RemixSfx_Updating(npc);
#endif
                g_MapOverlayHdr.charaUpdateFuncs[npc->model.charaId](npc, g_CharaModelAnimsData[animDataInfoIdx].activeAnmHdr, boneCoords);
#ifdef SH_PC_PORT
                Pc_RemixSfx_Updating(NULL);
#endif

                Collision_FlagsUpdate();
                func_80037E78(npc);
                func_8008A3AC(npc);
            }

            if (npc->model.anim.flags & AnimFlag_Visible)
            {
#ifdef SH_PC_PORT
                Pc_Pick_CharaPreDraw(npc, (int)(npc - g_SysWork.npcs), boneCoords);
#endif
                func_8003DA9C(npc->model.charaId, boneCoords, 1, npc->timer_C6, (s8)npc->model.paletteIdx);
            }
        }
    }

    for (k = 2; k >= 0; k--)
    {
        if (field_0[k].bitIdx_0 != NO_VALUE)
        {
            break;
        }
    }

    g_RadioPitchState = k + 1;

    if (!(g_SavegamePtr->itemToggleFlags & ItemToggleFlag_RadioOn))
    {
        return;
    }

    field_40 = 0;

    for (l = 0; l < ARRAY_SIZE(D_800BCDA8); l++)
    {
        temp_s0_2 = D_800BCDA8[l].field_1;
        if (temp_s0_2 == NO_VALUE)
        {
            var_v0_4 = NO_VALUE;
        }
        else
        {
            var_v0_4 = func_800382B0(field_0, temp_s0_2);
        }

        if (var_v0_4 >= 0)
        {
            D_800BCDA8[l].field_2 = var_v0_4;
            field_40             |= 1 << temp_s0_2;
        }
        else
        {
            D_800BCDA8[l].field_1 = NO_VALUE;
        }
    }

    for (l = 0; l < ARRAY_SIZE(D_800BCDA8); l++)
    {
        temp_s1 = D_800BCDA8[l].field_1;
        if (temp_s1 == NO_VALUE)
        {
            temp_v0_4 = func_800382EC(field_0, &field_40);
            if (temp_v0_4 != temp_s1)
            {
                var_v0_5 = field_0[temp_v0_4].bitIdx_0;
            }
            else
            {
                var_v0_5 = NO_VALUE;
            }

            D_800BCDA8[l].field_2 = temp_v0_4;
            D_800BCDA8[l].field_1 = var_v0_5;
        }
    }

    for (l = 0; l < ARRAY_SIZE(D_800BCDA8); l++)
    {
        if (D_800BCDA8[l].field_0 == NO_VALUE)
        {
            if (D_800BCDA8[l].field_1 >= 0)
            {
                SD_Call((u16)(Sfx_RadioInterferenceLoop + l));
            }
        }
        else
        {
            var_s3 = 0;
            if (!(g_MapOverlayHdr.mapInfo->flags & MapFlag_Interior) ||
                !(g_MapOverlayHdr.mapInfo->flags & (MapFlag_OneActiveChunk | MapFlag_TwoActiveChunks)))
            {
                var_s3 = 1;
            }

            if (D_800BCDA8[l].field_1 >= 0)
            {
                temp_s0_3 = &field_0[D_800BCDA8[l].field_2];
                temp_s0_4 = Vc_StereoBalanceGet(&temp_s0_3->field_8);

                var_v1_3 = SquareRoot12(temp_s0_3->field_4 << Q12_SHIFT) >> 8;
                if (var_s3 != 0)
                {
                    var_v1_3 >>= 1;
                }

                var_a2_2 = CLAMP(var_v1_3, 0, 0xFF);

                Sd_SfxAttributesUpdate(Sfx_RadioInterferenceLoop + l, temp_s0_4, var_a2_2, 0);
            }
            else
            {
                Sd_SfxStop(Sfx_RadioInterferenceLoop + l);
            }
        }

        D_800BCDA8[l].field_0 = D_800BCDA8[l].field_1;
    }
}

bool Math_Distance2dCheck(const VECTOR3* from, const VECTOR3* to, q19_12 radius) // 0x80038A6C
{
    q19_12 deltaX;
    q19_12 deltaZ;
    q19_12 radiusSqr;
    q19_12 sum;

    // Check rough radius intersection on X axis.
    deltaX = from->vx - to->vx;
    if (radius < deltaX)
    {
        return true;
    }
    if (radius < -deltaX)
    {
        return true;
    }

    // Check rough radius intersection on Z axis.
    deltaZ = from->vz - to->vz;
    if (radius < deltaZ)
    {
        return true;
    }
    if (radius < -deltaZ)
    {
        return true;
    }

    // Check distance.
    sum       = Q12_MULT_PRECISE(deltaX, deltaX) + Q12_MULT_PRECISE(deltaZ, deltaZ);
    radiusSqr = Q12_MULT_PRECISE(radius, radius);
    return sum > radiusSqr;
}

/** @brief Computes the squared 2D distance on the XZ plane from the reference position to the camera.
 *
 * @param pos Reference position (Q19.12).
 * @return 2D distance to the camera. TODO: Does it stay in Q25.6?
 */
static s32 Camera_Distance2dGet(const VECTOR3* pos) // 0x80038B44
{
    VECTOR3 camPos; // Q19.12
    q25_6   deltaX;
    q25_6   deltaZ;

    vwGetViewPosition(&camPos);
    deltaX = Q12_TO_Q6(camPos.vx - pos->vx);
    deltaZ = Q12_TO_Q6(camPos.vz - pos->vz);
    return Q12_MULT_PRECISE(deltaX, deltaX) + Q12_MULT_PRECISE(deltaZ, deltaZ);
}
