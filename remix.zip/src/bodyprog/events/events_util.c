#include "game.h"
#include "inline_no_dmpsx.h"

#include <psyq/libpad.h>
#include <psyq/strings.h>

#include "bodyprog/bodyprog.h"
#include "bodyprog/events/bodyprog_data_800A99B4.h"
#include "bodyprog/events/events_util.h"
#include "bodyprog/screen/screen_data.h"
#include "bodyprog/screen/screen_draw.h"
#include "bodyprog/screen/background_draw.h"
#include "bodyprog/item_screens.h"
#include "bodyprog/math/math.h"
#include "bodyprog/sound/sound_system.h"
#include "main/fsqueue.h"

#ifdef SH_PC_PORT
#include "sh_log.h"
/* The upstream merge moved the paper-map state machines here from
 * bodyprog_80085D78.c (Event_MapTake/func_800867B4, same PSX addresses);
 * the PC fixes below must live in THIS copy — the old one is dead code.
 * See PaperMap_ReuploadTimToVram_PC in bodyprog_80085D78.c for why the
 * TIM must be re-uploaded every tick (framebuffer-store CLUT clobber),
 * and game_main.c MainLoop for the g_PcMapScreenActive horplus gate
 * (without it the 320-wide map renders pillarboxed with garbage bars). */
void PaperMap_ReuploadTimToVram_PC(void);
extern int g_PcMapScreenActive;
extern int g_PcMapMsgGameVoiced;

/* Set when Event_DisplayMapMsgWithAudio drops an out-of-range voice cmd, so
 * the subtitle voice-wait in Gfx_MapMsg_Draw knows no voice is coming for the
 * page and can render immediately instead of waiting out the 1s fail-open. */
int g_PcMapMsgVoiceDropped = 0;

/* Set by Gfx_MapMsg_Draw when the Finish it just returned is a spurious PC
 * re-display of the SAME line that already completed on the previous scene
 * step (resume-not-restart; see map_msg_display.c). Event_DisplayMapMsgWithAudio
 * skips the voice fire + shared-index bump for it, matching PSX. */
int g_PcMapMsgReDisplaySetup = 0;
#endif

/** @brief EVENT AND INTERACTION HELPERS
 *
 * The following are helper functions for map events.
 * Most are designed to be called once per tick and track their own progress across ticks.
 *
 * Map events use a state machine driven by `sysStateSteps[0]` (or `sysStateSteps[1]` for sub-steps).
 * Each tick, the game re-enters the map event function and runs the case matching the current step.
 * The helper called within that case does its work and only advances `sysStateSteps` when
 * complete, allowing the next tick to move on to the next case.
 *
 * Example map event code:
 *
 * switch (g_SysWork.sysStateSteps[0])
 * {
 *   case 0:
 *       Event_WaitTimer(Q12(5.0f), false); // Called every tick until 5 seconds have elapsed.
 *       break;                             // Once elapsed, `Event_WaitTimer` handles incrementing `sysStateSteps[0]` to 1.
 *
 *   case 1:
 *       Event_WaitPlayerStop();            // Called every tick until player has stopped.
 *       break;                             // Once stopped, `Event_WaitPlayerStop` handles incrementing `sysStateSteps[0]` to 2.
 *
 *   case 2:
 *       DoSomething();                     // Only reached after both previous steps have completed.
 *       break;
 * }
 *
 * This pattern allows sequential, blocking-style code to be written without actually blocking the game's main loop.
 * The helpers above "wait" by simply returning without advancing the step, and "complete" by incrementing the step counter.
 * The animation/inventory item/map message functions work similarly, being called every tick and "waiting" by simply not advancing the step.
 * TODO: Describe the "Auto" commands that use `sysStateSteps[2]`. Need to check how map events use that.
 */

VECTOR3 g_Event_PathWaypoints[2][8];
q3_12   g_Event_PathWaypointHeadingAngles[8]; // TODO: should only have 2 entries, 1 for each character slot?
q19_12  g_Event_TweenTimers[6];

void Event_SysStateStepIncrement(bool incSubStep) // 0x80085D78
{
    if (incSubStep)
    {
        SysWork_StateStepIncrement(1);
    }
    else
    {
        SysWork_StateStepIncrement(0);
    }
}

void Event_SysStateStepSet(bool setSubStep, s32 sysStateStep) // 0x80085DC0
{
    if (setSubStep)
    {
        SysWork_StateStepSet(1, sysStateStep);
    }
    else
    {
        SysWork_StateStepSet(0, sysStateStep);
    }
}

void Event_WaitPlayerStop(void) // 0x80085DF0
{
    g_SysWork.timer_2C += g_DeltaTimeRaw;
    if (g_MapOverlayHdr.playerMoveSpeedIsZero() || g_SysWork.timer_2C > Q12(1.0f))
    {
        SysWork_StateStepIncrement(0);
    }
}

void Event_WaitTimer(q19_12 delay, bool incSubStep) // 0x80085E6C
{
    g_SysWork.timer_2C += g_DeltaTimeRaw;
    if (delay < g_SysWork.timer_2C)
    {
        Event_SysStateStepIncrement(incSubStep);
    }
}

void Event_CharaAnimCmdExecute(e_CharaAnimCmd cmd, s_SubCharacter* chara, s32 animState, bool incSubStep) // 0x80085EB8
{
    s32  playbackState;

    #define isPlayer (chara == &g_SysWork.playerWork.player)

    switch (cmd)
    {
        case CharaAnimCmd_SetState:
            if (isPlayer)
            {
                g_MapOverlayHdr.playerAnimStateSet(animState);
            }
            else
            {
                g_MapOverlayHdr.charaAnimStateSet(chara, animState);
            }
            break;

        case CharaAnimCmd_AwaitAnimEnd:
            if (isPlayer)
            {
                playbackState = g_MapOverlayHdr.playerAnimPlaybackStateGet();
                if (playbackState == AnimPlaybackState_End)
                {
                    Event_SysStateStepIncrement(incSubStep);
                }
            }
            else
            {
                playbackState = g_MapOverlayHdr.charaAnimPlaybackStateGet(chara);
                if (playbackState == AnimPlaybackState_End)
                {
                    Event_SysStateStepIncrement(incSubStep);
                }
            }
            break;

        case CharaAnimCmd_AnimLock:
            if (isPlayer)
            {
                g_MapOverlayHdr.playerAnimLock();
            }
            else
            {
                g_MapOverlayHdr.charaAnimLock(chara);
            }
            break;

        case CharaAnimCmd_AnimUnlock:
            if (isPlayer)
            {
                g_MapOverlayHdr.playerAnimUnlock();
            }
            else
            {
                g_MapOverlayHdr.charaAnimUnlock(chara);
            }
            break;

        case CharaAnimCmd_AnimReset:
            if (isPlayer)
            {
                g_MapOverlayHdr.playerAnimUnlock();
                g_MapOverlayHdr.playerAnimReset();
            }
            else
            {
                g_MapOverlayHdr.charaAnimReset(chara);
            }
            break;
    }

    #undef isPlayer
}

void Event_SysStateBranchOnFlag(e_EventFlag eventFlagIdx, s32 stepTrue, s32 stepFalse, bool setSubStep) // 0x8008605C
{
    if (!Savegame_EventFlagGet(eventFlagIdx))
    {
        Event_SysStateStepSet(setSubStep, stepFalse);
    }
    else
    {
        Event_SysStateStepSet(setSubStep, stepTrue);
    }
}

void Event_DisplayMapMsg(bool hasSelection, s32 mapMsgIdx, s32 step0, s32 step1, s32 step2, bool incSubStep) // 0x800860B0
{
    s32 mapMsgState;

    mapMsgState = Gfx_MapMsg_Draw(mapMsgIdx);
    if (mapMsgState <= MapMsgState_Idle)
    {
        return;
    }

    if (!hasSelection)
    {
        Event_SysStateStepIncrement(incSubStep);
        return;
    }

    if (mapMsgState == MapMsgState_SelectEntry0)
    {
        Event_SysStateStepSet(incSubStep, step0);
    }
    if (mapMsgState == MapMsgState_SelectEntry1)
    {
        Event_SysStateStepSet(incSubStep, step1);
    }
    if (mapMsgState == MapMsgState_SelectEntry2)
    {
        Event_SysStateStepSet(incSubStep, step2);
    }
}

void Event_ScreenFadeCmd(e_ScreenFadeCmd cmd, bool fadeOut, e_ScreenFadeType fadeType, q19_12 fadeTimestep, bool incSubStep) // 0x8008616C
{
    e_ScreenFadeCmd activeCmd;

    // If `cmd == ScreenFadeCmd_Auto`, `sysStateSteps[2]` dictates the command. This field is manipulated often in map event functions.
    if (cmd != ScreenFadeCmd_Auto)
    {
        activeCmd = cmd;
    }
    else
    {
        activeCmd = g_SysWork.sysStateSteps[2];
    }

    switch (activeCmd)
    {
        case ScreenFadeCmd_Start:
            if (fadeType != ScreenFadeType_ScreenBorders)
            {
                g_ScreenFadeTimestep = fadeTimestep;
            }

            if (fadeOut)
            {
                if (fadeType == ScreenFadeType_Black)
                {
                    ScreenFade_Start(false, false, false);
                }
                else if (fadeType == ScreenFadeType_White)
                {
                    ScreenFade_Start(false, false, true);
                }
                else
                {
                    CutsceneBorder_FadeInStart();

                    if (fadeType == ScreenFadeType_CutsceneBorders)
                    {
                        g_SysWork.sysFlags |= SysFlag_CutsceneActive;
                    }
                }
            }
            else
            {
                if (fadeType == ScreenFadeType_Black)
                {
                    ScreenFade_Start(false, true, false);
                }
                else if (fadeType == ScreenFadeType_White)
                {
                    ScreenFade_Start(false, true, true);
                }
                else
                {
                    CutsceneBorder_FadeOutStart();
                }
            }

            if (cmd != ScreenFadeCmd_Start) // `cmd` will only be different if `ScreenFadeCmd_Auto` was passed.
            {
                SysWork_StateStepIncrement(2);
            }
            break;

        case ScreenFadeCmd_Wait:
            if (fadeType < ScreenFadeType_ScreenBorders) // `fadeType == ScreenFadeType_Black || fadeType == ScreenFadeType_White`
            {
                if ((fadeOut == false && ScreenFade_IsNone()) ||
                    (fadeOut == true  && ScreenFade_IsFinished()))
                {
                    Event_SysStateStepIncrement(incSubStep);
                }
            }
            else if ((fadeOut == false && g_SysWork.cutsceneBorderState == CutsceneBorderState_None) ||
                     (fadeOut == true  && g_SysWork.cutsceneBorderState == CutsceneBorderState_Shown))
            {
                Event_SysStateStepIncrement(incSubStep);
            }

            break;
    }
}

const RECT D_8002AB10 =  // 0x8002AB10 .rodata
{
    SCREEN_POSITION_X(100.0f), 256,
    (SCREEN_WIDTH / 5) * 3, SCREEN_HEIGHT
};

void Event_BgTextureCmd(e_BgTextureCmd cmd, e_FsFile textureFileIdx, bool incSubStep) // 0x800862F8
{
    e_BgTextureCmd activeCmd;

    if (cmd == BgTextureCmd_Auto)
    {
        activeCmd = g_SysWork.sysStateSteps[2];
    }
    else
    {
        activeCmd = cmd;
        if (activeCmd == BgTextureCmd_8)
        {
            activeCmd = BgTextureCmd_AwaitLoad;
            if (g_SysWork.sysStateSteps[2] == 0)
            {
                activeCmd = BgTextureCmd_QueueReadSecondary;
            }
        }
    }

    switch (activeCmd)
    {
        case BgTextureCmd_QueueRead:
            Fs_QueueStartReadTim(textureFileIdx, FS_BUFFER_1, &g_ItemInspectionImg);

            if (cmd != BgTextureCmd_QueueRead)
            {
                SysWork_StateStepIncrement(2);

                if (Fs_QueueChunksLoad())
                {
                    Event_SysStateStepIncrement(incSubStep);
                }
            }
            break;

        case BgTextureCmd_AwaitLoad:
            if (Fs_QueueChunksLoad())
            {
                Event_SysStateStepIncrement(incSubStep);
            }
            break;

        case BgTextureCmd_Draw:
            Screen_BackgroundImgDrawAlt(&g_ItemInspectionImg);
            break;

        case BgTextureCmd_StoreVram:
            DrawSync(SyncMode_Wait);
            StoreImage(&D_8002AB10, IMAGE_BUFFER_2);
            DrawSync(SyncMode_Wait);
            break;

        case BgTextureCmd_QueueReadSecondary:
            Fs_QueueStartReadTim(textureFileIdx, FS_BUFFER_1, &D_800A9A04);

            if (cmd == BgTextureCmd_8)
            {
                SysWork_StateStepSet(2, BgTextureCmd_AwaitLoad);
            }
            break;

        case BgTextureCmd_DrawSecondary:
            Screen_BackgroundImgDrawAlt(&D_800A9A04);
            break;

        case BgTextureCmd_RestoreVram:
            LoadImage(&D_8002AB10, IMAGE_BUFFER_2);
            DrawSync(SyncMode_Wait);
            break;
    }
}

void Event_InvItemCmd(e_InvItemCmd cmd, e_InvItemId itemId, s32 itemCount, bool incSubStep) // 0x80086470
{
    // This func does weird remapping of the input `cmd` to `activeCmd`.
    // `cmd` is also `u32` while `activeCmd` is `s32`, added internal enum here to help func make more sense.
    typedef enum _InvItemCmdInternal
    {
        InvItemCmdInternal_QueueLoad = 0,
        InvItemCmdInternal_AwaitLoad = 1,
        InvItemCmdInternal_AddItem   = 2, // Remapped from `InvItemCmd_AddItem` (3)
        InvItemCmdInternal_Nop       = 3, // Remapped from `InvItemCmd_Nop` (2)
        InvItemCmdInternal_Hack      = -1
    } e_InvItemCmdInternal;

    e_InvItemCmdInternal activeCmd;

    if (cmd == InvItemCmd_6 && g_SysWork.sysStateSteps[2] == 0)
    {
        SysWork_StateStepSet(2, InvItemCmdInternal_AddItem);
    }

    activeCmd = cmd;
    if (cmd >= InvItemCmd_Nop)
    {
        if (cmd == InvItemCmd_Nop)
        {
            activeCmd = InvItemCmdInternal_Nop;
        }
        else if (cmd == InvItemCmd_AddItem)
        {
            activeCmd = InvItemCmdInternal_AddItem;
        }
        else
        {
            activeCmd = g_SysWork.sysStateSteps[2];
        }
    }

    switch (activeCmd)
    {
        case InvItemCmdInternal_QueueLoad:
            GameFs_UniqueItemModelLoad(itemId);

            if (cmd == InvItemCmd_QueueLoad)
            {
                SysWork_StateStepIncrement(1);
                g_SysWork.sysStateSteps[1]--;
            }

            SysWork_StateStepIncrement(2);

        case InvItemCmdInternal_AwaitLoad:
            if (!Fs_QueueChunksLoad())
            {
                break;
            }

            func_80054A04(itemId);

            if (cmd == InvItemCmd_AwaitLoad || cmd == InvItemCmd_4)
            {
                Event_SysStateStepIncrement(incSubStep);
                break;
            }

            SysWork_StateStepIncrement(2);

        case InvItemCmdInternal_AddItem:
            SysWork_StateStepSet(2, 0);

            if (cmd == InvItemCmd_AddItem || cmd == InvItemCmd_6)
            {
#ifdef SH_PC_PORT
                /* Remix weapons: Cybil's handgun becomes your starting gun; a gun
                 * you already carry gives its ammo. No-op unless remix_weapons. */
                {
                    extern void Pc_Remix_RemapAddItem(s32* itemId, s32* itemCount);
                    s32 _id = itemId, _cnt = itemCount;
                    Pc_Remix_RemapAddItem(&_id, &_cnt);
                    itemId    = (e_InvItemId)_id;
                    itemCount = _cnt;
                }
#endif
                Inventory_AddSpecialItem(itemId, itemCount);
            }
            break;
    }
}

void Event_PathWaypointSet(bool isAbs, s32 charaSlotIdx, s32 waypointIdx, q3_12 headingAngle, q19_12 posX, q19_12 posZ) // 0x800865FC
{
    if (isAbs == false)
    {
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vx = g_SysWork.playerWork.player.position.vx + posX;
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vy = g_SysWork.playerWork.player.position.vy;
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vz = g_SysWork.playerWork.player.position.vz + posZ;

        // @bug `headingAngle` is stored per `charaSlotIdx`, not per waypoint.
        // Event code often calls `Event_PathWaypointSet` multiple times in a single tick
        // with different `headingAngle` values, but the same `charaSlot`.
        // Only the last written `headingAngle` is retained and other values are silently discarded.
        // Unlikely this was intentional, but doesn't seem to break things visually at least.
        // Maybe pathfinding code doesn't rely on this angle value that much?
        g_Event_PathWaypointHeadingAngles[charaSlotIdx] = headingAngle;
    }
    else if (isAbs == true)
    {
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vx = posX;
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vy = g_SysWork.playerWork.player.position.vy;
        g_Event_PathWaypoints[charaSlotIdx][waypointIdx].vz = posZ;

        g_Event_PathWaypointHeadingAngles[charaSlotIdx] = headingAngle;
    }
}

void Event_PathWaypointExecutePlayer(s32 animId, s32 waypointCount, bool incSubStep) // 0x800866D4
{
    if (g_MapOverlayHdr.playerPathWaypointExecute(animId, &g_Event_PathWaypoints[0][0], g_Event_PathWaypointHeadingAngles[0], waypointCount) == true)
    {
        Event_SysStateStepIncrement(incSubStep);
    }
}

void Event_PathWaypointExecuteChara(s_SubCharacter* chara, s32 animId, s32 waypointCount, bool incSubStep) // 0x80086728
{
    if (g_MapOverlayHdr.charaPathWaypointExecute(chara, animId, &g_Event_PathWaypoints[1][0], g_Event_PathWaypointHeadingAngles[1], waypointCount) == true)
    {
        Event_SysStateStepIncrement(incSubStep);
    }
}

void Event_PathWaypointExecuteCharaNoWait(s_SubCharacter* chara, s32 animId, s32 waypointCount) // 0x8008677C
{
    g_MapOverlayHdr.charaPathWaypointExecute(chara, animId, &g_Event_PathWaypoints[1][0], g_Event_PathWaypointHeadingAngles[1], waypointCount);
}

void Event_PaperMapCmd(e_PaperMapCmd cmd, s32 paperMapIdx) // 0x800867B4
{
    switch (cmd)
    {
        case PaperMapCmd_Load:
            DrawSync(SyncMode_Wait);
            StoreImage(&D_8002AB10, IMAGE_BUFFER_2);
            DrawSync(SyncMode_Wait);

            Fs_QueueStartReadTim(FILE_TIM_MP_0TOWN_TIM + g_PaperMapFileIdxs[paperMapIdx], FS_BUFFER_2, &g_PaperMapImg);
            Fs_QueueStartReadTim(FILE_TIM_MR_0TOWN_TIM + g_PaperMapMarkingFileIdxs[paperMapIdx], FS_BUFFER_1, &g_PaperMapMarkingAtlasImg);

            Screen_Init(SCREEN_WIDTH, true);
            GsSwapDispBuff();
            Fs_QueueWaitForEmpty();
#ifdef SH_PC_PORT
            g_PcMapScreenActive = 1;
#endif
            break;

        case PaperMapCmd_Draw:
#ifdef SH_PC_PORT
            PaperMap_ReuploadTimToVram_PC();
#endif
            Screen_BackgroundImgDraw(&g_PaperMapImg);
            break;

        case PaperMapCmd_Unload:
            LoadImage(&D_8002AB10, IMAGE_BUFFER_2);
            DrawSync(SyncMode_Wait);
            Screen_Init(SCREEN_WIDTH, false);
#ifdef SH_PC_PORT
            g_PcMapScreenActive = 0;
#endif
            break;
    }
}

void Event_TweenReset(s32 timerIdx) // 0x800868DC
{
    #define tweenTimer g_Event_TweenTimers[timerIdx]

    tweenTimer = Q12(0.0f);

    #undef tweenTimer
}

q19_12 Event_TweenLinear(q19_12 target, q19_12 duration, s32 timerIdx) // 0x800868F4
{
    #define tweenTimer g_Event_TweenTimers[timerIdx]

    tweenTimer += g_DeltaTime;
    tweenTimer  = (duration < tweenTimer) ? duration : tweenTimer;
    return (target * tweenTimer) / duration;

    #undef tweenTimer
}

q19_12 Event_TweenSine(q19_12 amp, q3_12 startAngle, q3_12 sweepAngle, q19_12 duration, s32 timerIdx) // 0x8008694C
{
    #define tweenTimer g_Event_TweenTimers[timerIdx]

    tweenTimer += g_DeltaTime;
    tweenTimer  = (duration < tweenTimer) ? duration : tweenTimer;
    return Q12_MULT(amp, Math_Sin(startAngle + ((sweepAngle * tweenTimer) / duration)));

    #undef tweenTimer
}

void Event_DisplayMapMsgWithAudio(s32 mapMsgIdx, u8* audioIdx, const u16* audioCmds) // 0x800869E4
{
    s32 mapMsgState;

    g_SysWork.bgmStatusFlags |= BgmStatusFlag_VoiceDialog;

#ifdef SH_PC_PORT
    g_PcMapMsgGameVoiced = 1;
#endif
    mapMsgState = Gfx_MapMsg_Draw(mapMsgIdx);
#ifdef SH_PC_PORT
    g_PcMapMsgGameVoiced = 0;
#endif
    if (mapMsgState == MapMsgState_SelectEntry0)
    {
        SysWork_StateStepIncrement(0);
    }
    else if (mapMsgState == MapMsgState_Finish)
    {
#ifdef SH_PC_PORT
        /* Cybil basement scene (map4_s01): some message consumes more
         * page-finishes than authored, so the audio index overruns into
         * neighboring tables (valid-looking 0x1xxx cmds = wrong scene's
         * lines) and then into non-voice data. Range-guard the cmd so the
         * overrun turns into silence instead of playing garbage.
         *
         * When the cmd is dropped, tell the subtitle voice-wait
         * (Gfx_MapMsg_Draw) that no voice is coming for this page, so the
         * text renders immediately instead of eating the 1s fail-open
         * delay — a dropped line already desynced the audio; delaying its
         * subtitle a further second on top just compounds it. */
        /* Resume-not-restart: a setup-Finish that is a spurious PC re-display
         * of the line that JUST completed on the previous scene step (same msg
         * index, e.g. map6_s04 case7->case9 both showing msg47) fired an EXTRA
         * voice on PC — PSX resumes that display and fires nothing. Skip the
         * SD_Call AND the index bump so the shared voice index stays in lockstep
         * with PSX (otherwise every later line plays the next clip one beat
         * early — the Flauros "scream" ~7.8s ahead). The subtitle text was
         * already set up by Gfx_MapMsg_Draw; only the audio is suppressed. */
        if (g_PcMapMsgReDisplaySetup)
        {
            g_PcMapMsgReDisplaySetup = 0;
        }
        else
        {
            u16 _cmd = audioCmds[*audioIdx];
            if (_cmd >= 0x1000 && _cmd < 0x1700)
            {
                g_PcMapMsgVoiceDropped = 0;
                SD_Call(_cmd);
            }
            else
            {
                static int s_dropLogN = 0;
                g_PcMapMsgVoiceDropped = 1;
                if (s_dropLogN < 20)
                {
                    SH_DBG("[MSGVOICE] dropped out-of-range voice cmd 0x%04X at audioIdx=%d (msg %d) — table overrun?",
                           _cmd, (int)*audioIdx, (int)mapMsgIdx);
                    s_dropLogN++;
                }
            }
            *audioIdx += 1;
        }
#else
        SD_Call(audioCmds[*audioIdx]);
        *audioIdx += 1;
#endif
    }
}

void Event_CameraPositionSet(VECTOR3* pos, q19_12 offsetOrPosX, q19_12 offsetOrPosY, q19_12 offsetOrPosZ,
                             q19_12 accelXz, q19_12 accelY, q19_12 speedXzMax, q19_12 speedYMax,
                             bool warp) // 0x80086A94
{
    VECTOR3         posTarget;
    VC_CAM_MV_PARAM camMoveParams;

    // Set position target.
    if (pos != NULL)
    {
        posTarget.vx = pos->vx + offsetOrPosX;
        posTarget.vy = pos->vy + offsetOrPosY;
        posTarget.vz = pos->vz + offsetOrPosZ;
    }
    else
    {
        posTarget.vx = offsetOrPosX;
        posTarget.vy = offsetOrPosY;
        posTarget.vz = offsetOrPosZ;
    }

    // Set acceleration on XZ plane.
    if (accelXz == Q12(0.0f))
    {
        camMoveParams.accel_xz = cam_mv_prm_user.accel_xz;
    }
    else
    {
        camMoveParams.accel_xz = accelXz;
    }

    // Set acceleration on Y axis.
    if (accelY == Q12(0.0f))
    {
        camMoveParams.accel_y = cam_mv_prm_user.accel_y;
    }
    else
    {
        camMoveParams.accel_y = accelY;
    }

    // Set max speed on XZ plane.
    if (speedXzMax == Q12(0.0f))
    {
        camMoveParams.max_spd_xz = cam_mv_prm_user.max_spd_xz;
    }
    else
    {
        camMoveParams.max_spd_xz = speedXzMax;
    }

    // Set max speed on Y axis.
    if (speedYMax == Q12(0.0f))
    {
        camMoveParams.max_spd_y = cam_mv_prm_user.max_spd_y;
    }
    else
    {
        camMoveParams.max_spd_y = speedYMax;
    }

    // Set camera position target.
    vcUserCamTarget(&posTarget, &camMoveParams, warp);
}

void Event_CameraLookAtSet(VECTOR3* lookAt, q19_12 lookAtOffsetOrPosX, q19_12 lookAtOffsetOrPosY, q19_12 lookAtOffsetOrPosZ,
                           q19_12 angularAccelX, q19_12 angularAccelY, q19_12 angularSpeedXMax, q19_12 angularSpeedYMax,
                           bool warp) // 0x80086B70
{
    VECTOR3           lookAtTarget;
    VC_WATCH_MV_PARAM camLookAtMoveParams;

    // Set look-at target.
    if (lookAt != NULL)
    {
        lookAtTarget.vx = lookAt->vx + lookAtOffsetOrPosX;
        lookAtTarget.vy = lookAt->vy + lookAtOffsetOrPosY;
        lookAtTarget.vz = lookAt->vz + lookAtOffsetOrPosZ;
    }
    else
    {
        lookAtTarget.vx = lookAtOffsetOrPosX;
        lookAtTarget.vy = lookAtOffsetOrPosY;
        lookAtTarget.vz = lookAtOffsetOrPosZ;
    }

    // Set angular acceleration on X axis.
    if (angularAccelX == Q12_ANGLE(0.0f))
    {
        camLookAtMoveParams.ang_accel_x = deflt_watch_mv_prm.ang_accel_x;
    }
    else
    {
        camLookAtMoveParams.ang_accel_x = angularAccelX;
    }

    // Set angular acceleration on Y axis.
    if (angularAccelY == Q12_ANGLE(0.0f))
    {
        camLookAtMoveParams.ang_accel_y = deflt_watch_mv_prm.ang_accel_y;
    }
    else
    {
        camLookAtMoveParams.ang_accel_y = angularAccelY;
    }

    // Set max angular speed on X axis.
    if (angularSpeedXMax == Q12_ANGLE(0.0f))
    {
        camLookAtMoveParams.max_ang_spd_x = deflt_watch_mv_prm.max_ang_spd_x;
    }
    else
    {
        camLookAtMoveParams.max_ang_spd_x = angularSpeedXMax;
    }

    // Set max angular speed on Y axis.
    if (angularSpeedYMax == Q12_ANGLE(0.0f))
    {
        camLookAtMoveParams.max_ang_spd_y = deflt_watch_mv_prm.max_ang_spd_y;
    }
    else
    {
        camLookAtMoveParams.max_ang_spd_y = angularSpeedYMax;
    }

    // Set camera flags and rotation target.
    vcWorkSetFlags(0, VC_VISIBLE_CHARA_F);
    vcUserWatchTarget(&lookAtTarget, &camLookAtMoveParams, warp);
}

void Event_CharaAnimPlayToEnd(s_SubCharacter* chara, s32 animState) // 0x80086C58
{
    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            Event_CharaAnimCmdExecute(CharaAnimCmd_SetState, chara, animState, false);
            SysWork_StateStepIncrement(1);
            break;

        case 1:
            Event_CharaAnimCmdExecute(CharaAnimCmd_AwaitAnimEnd, chara, 0, true);
            break;

        default:
            SysWork_StateStepIncrement(0);
            break;
    }
}

void Event_CharaAnimUnlockPlayToEnd(s_SubCharacter* chara) // 0x80086D04
{
    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            Event_CharaAnimCmdExecute(CharaAnimCmd_AnimUnlock, chara, 0, false);
            SysWork_StateStepIncrement(1);
            break;

        case 1:
            Event_CharaAnimCmdExecute(CharaAnimCmd_AwaitAnimEnd, chara, 0, true);
            break;

        default:
            SysWork_StateStepIncrement(0);
            break;
    }
}

void Event_BgTextureLoadFadeIn(e_FsFile textureFileIdx, q19_12 fadeTimestep) // 0x80086DA8
{
    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, true, 0, fadeTimestep, false);
            SysWork_StateStepIncrement(1);

        case 1:
            Event_BgTextureCmd(BgTextureCmd_Auto, textureFileIdx, true);
            break;

        default:
            Event_ScreenFadeCmd(ScreenFadeCmd_Wait, true, 0, Q12(0.0f), false);
            break;
    }
}

void Event_BgTextureFadeIn(e_FsFile textureFileIdx, q19_12 fadeTimestep0, q19_12 fadeTimestep1) // 0x80086E50
{
    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, true, 0, fadeTimestep0, false);
            SysWork_StateStepIncrement(1);

        case 1:
            Event_BgTextureCmd(BgTextureCmd_Auto, textureFileIdx, true);
            break;

        case 2:
            Event_ScreenFadeCmd(ScreenFadeCmd_Wait, true, 0, Q12(0.0f), true);
            break;

        default:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, false, 0, fadeTimestep1, false);
    }
}

void Event_BgTextureFadeOut(q19_12 fadeTimestepFromBlack, q19_12 fadeTimestepToBlack) // 0x80086F44
{
    if (g_SysWork.sysStateSteps[1] == 0)
    {
        Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
        Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, fadeTimestepToBlack, true);
        return;
    }

    Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, fadeTimestepFromBlack, false);
    SysWork_StateStepIncrement(0);
}

void Event_DisplayMapMsgWithSfx(s32 mapMsgIdx, e_SfxId sfxId, VECTOR3* sfxPos) // 0x80086FE8
{
    s32 i;

    if (!(g_SysWork.sysFlags & SysFlag_5))
    {
        // Run through NPCs.
        for (i = 0; i < ARRAY_SIZE(g_SysWork.npcs); i++)
        {
            if (g_SysWork.npcs[i].model.charaId >= Chara_Harry &&
                g_SysWork.npcs[i].model.charaId <= Chara_MonsterCybil &&
                g_SysWork.npcs[i].health > Q12(0.0f))
            {
                break;
            }
        }

        if (i != ARRAY_SIZE(g_SysWork.npcs))
        {
            g_DeltaTime = Q12(0.0f);
        }
    }

    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            g_MapOverlayHdr.playerControlFreeze();
            Sfx_WithFlagsPlay(sfxId, sfxPos, Q8(0.5f), SfxFlag_None);
            SysWork_StateStepIncrement(1);

        case 1:
            Event_WaitTimer(Q12(0.2f), true);
            break;

        case 2:
            Event_DisplayMapMsg(false, mapMsgIdx, 0, 0, 0, true);
            break;

        default:
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}

void Event_DisplayBgTexture(e_FsFile textureFileIdx, q19_12 fadeTimestep0, q19_12 fadeTimestep1) // 0x8008716C
{
    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            g_MapOverlayHdr.playerControlFreeze();
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, true, 0, fadeTimestep0, false);
            SysWork_StateStepIncrement(1);

        case 1:
            Event_BgTextureCmd(BgTextureCmd_Auto, textureFileIdx, true);
            break;

        case 2:
            Event_ScreenFadeCmd(ScreenFadeCmd_Wait, true, 0, Q12(0.0f), true);
            break;

        case 3:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, false, 0, fadeTimestep1, true);
            break;

        case 4:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);

            if (g_Controller0->clickedBtnFlags & (g_GameWorkPtr->config.controllerConfig.enter |
                                                 g_GameWorkPtr->config.controllerConfig.cancel))
            {
                SysWork_StateStepIncrement(1);
            }
            break;

        case 5:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, fadeTimestep1, true);
            break;

        default:
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, fadeTimestep0, false);
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}

void Event_DisplayMapMsgWithBg(e_FsFile textureFileIdx, q19_12 fadeTimestep0, q19_12 fadeTimestep1, s32 mapMsgIdx) // 0x80087360
{
    // TODO: Name these.
    typedef enum _EventStates
    {
        EventStates_Initialize = 0,
        EventStates_1          = 1,
        EventStates_2          = 2,
        EventStates_3          = 3,
        EventStates_4          = 4,
        EventStates_5          = 5,
        EventStates_6          = 6
    } e_EventStates;

    switch (g_SysWork.sysStateSteps[1])
    {
        case EventStates_Initialize:
            // Freeze player control.
            g_MapOverlayHdr.playerControlFreeze();

            Event_ScreenFadeCmd(ScreenFadeCmd_Start, true, 0, fadeTimestep0, false);
            SysWork_StateStepIncrement(1);

        case EventStates_1:
            Event_BgTextureCmd(BgTextureCmd_Auto, textureFileIdx, true);
            break;

        case EventStates_2:
            Event_ScreenFadeCmd(ScreenFadeCmd_Wait, true, 0, Q12(0.0f), true);
            break;

        case EventStates_3:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, false, 0, fadeTimestep1, true);
            break;

        case EventStates_4:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_DisplayMapMsg(false, mapMsgIdx, 0, 0, 0, true);
            break;

        case EventStates_5:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, fadeTimestep1, true);
            break;

        default: // `EventStates_6`
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, fadeTimestep0, false);

            // Restore player control.
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}

void Event_DisplayMapMsgWithDimmedBg(e_FsFile textureFileIdx, q19_12 fadeTimestep0, q19_12 fadeTimestep1, s32 mapMsgIdx0, s32 mapMsgIdx1) // 0x80087540
{
    // TODO: Name these.
    typedef enum _EventStates
    {
        EventStates_Initialize = 0,
        EventStates_1          = 1,
        EventStates_2          = 2,
        EventStates_3          = 3,
        EventStates_4          = 4,
        EventStates_5          = 5,
        EventStates_6          = 6,
        EventStates_7          = 7
    } e_EventStates;

    switch (g_SysWork.sysStateSteps[1])
    {
        case EventStates_Initialize:
            // Freeze player control.
            g_MapOverlayHdr.playerControlFreeze();

            Event_ScreenFadeCmd(ScreenFadeCmd_Start, true, 0, fadeTimestep0, false);
            SysWork_StateStepIncrement(1);

        case EventStates_1:
            Event_BgTextureCmd(BgTextureCmd_Auto, textureFileIdx, true);
            break;

        case EventStates_2:
            Event_ScreenFadeCmd(ScreenFadeCmd_Wait, true, 0, Q12(0.0f), true);
            break;

        case EventStates_3:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, false, 0, fadeTimestep1, true);
            break;

        case EventStates_4:
            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);

            if (mapMsgIdx0 != MapMsgCode_None)
            {
                Event_DisplayMapMsg(false, mapMsgIdx0, 0, 0, 0, true);
                break;
            }

            // Check for "continue" input.
            if (g_Controller0->clickedBtnFlags & (g_GameWorkPtr->config.controllerConfig.enter |
                                                  g_GameWorkPtr->config.controllerConfig.cancel))
            {
                SysWork_StateStepIncrement(1);
            }
            break;

        case EventStates_5:
            g_Screen_BackgroundImgGamma = Q8(6.0f / 32.0f);

            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_DisplayMapMsg(false, mapMsgIdx1, 0, 0, 0, true);
            break;

        case EventStates_6:
            g_Screen_BackgroundImgGamma = Q8(6.0f / 32.0f);

            Event_BgTextureCmd(BgTextureCmd_Draw, 0, false);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, fadeTimestep1, true);
            break;

        default: // `EventStates_7`
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, fadeTimestep0, false);
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}

void Event_ItemTake(e_InvItemId itemId, s32 itemCount, e_EventFlag eventFlagIdx, s32 mapMsgIdx) // 0x800877B8
{
    typedef enum _EventState
    {
        EventState_Initialize      = 0,
        EventState_LoadItemModel   = 1,
        EventState_SelectionDialog = 2,
        EventState_TakeItem        = 3,
        EventState_DontTakeItem    = 4
    } e_EventState;

    s32 i            = itemId;
    s32 mapMsgIdxCpy = mapMsgIdx;

#ifdef SH_PC_PORT
    /* Randomizer weapons: the Handgun in place of your starting gun's pickup,
     * and a gun you already carry gives its ammo. Keyed on eventFlagIdx and
     * decided once, because this function is a state machine re-entered every
     * frame. No-op unless remix_weapons. */
    {
        extern void Pc_Remix_RemapItemTake(s32* itemId, s32* itemCount, s32 eventFlagIdx, s32* mapMsgIdx);
        s32 _id = itemId, _cnt = itemCount, _msg = mapMsgIdxCpy;
        Pc_Remix_RemapItemTake(&_id, &_cnt, eventFlagIdx, &_msg);
        itemId       = (e_InvItemId)_id;
        itemCount    = _cnt;
        mapMsgIdxCpy = _msg;
    }
#endif

    if (!(g_SysWork.sysFlags & SysFlag_5))
    {
        // Run through NPCs.
        for (i = 0; i < ARRAY_SIZE(g_SysWork.npcs); i++)
        {
            if (g_SysWork.npcs[i].model.charaId >= Chara_Harry        &&
                g_SysWork.npcs[i].model.charaId <= Chara_MonsterCybil &&
                g_SysWork.npcs[i].health > Q12(0.0f))
            {
                break;
            }
        }

        if (i != ARRAY_SIZE(g_SysWork.npcs))
        {
            g_DeltaTime = Q12(0.0f);
        }
    }

    switch (g_SysWork.sysStateSteps[1])
    {
        case EventState_Initialize:
            // Freeze player and start loading item model.
            g_MapOverlayHdr.playerControlFreeze();
            Event_InvItemCmd(InvItemCmd_QueueLoad, itemId, 0, false);

            SysWork_StateStepIncrement(1);

        case EventState_LoadItemModel:
#ifdef SH_PC_PORT
            /* Engage the world-pickup freeze the instant the interaction starts,
             * not when Gfx_PickupItemAnimate first runs several frames later (once
             * the model finishes its async load). Otherwise the world keeps
             * rendering live through the load window, and vcMoveAndSetCamera
             * (game_sys_states.c, gated on !BgmStatusFlag_Pause) eases the fixed
             * camera toward its target across those frames; the freeze then
             * snapshots the camera MID-EASE, so the take-screen backdrop shows a
             * shifted, "stuck" angle. Pausing here holds the pre-examine frame the
             * player was already looking at. The load still completes — the Fs pump
             * (Fs_QueueChunksLoad) runs outside the pause gate. OT0 is empty while
             * paused-and-not-yet-loaded, so arming g_PcPickupItemActive early only
             * makes the release edge (game_main.c) cover the whole interaction; the
             * see-through depth bracket has no item prims to touch until the model
             * actually draws in Gfx_PickupItemAnimate, so that fix never reaches the
             * world. Common (Event_ItemTake) pickups only — the special key pickups
             * play a scripted reach animation first and keep their own timing. */
            {
                extern int g_PsxPresentLastFrame;
                extern int g_PcPickupItemActive;
                g_SysWork.bgmStatusFlags |= BgmStatusFlag_Pause;
                g_PsxPresentLastFrame     = 1;
                g_PcPickupItemActive      = 1;
            }
#endif
            Event_InvItemCmd(InvItemCmd_AwaitLoad, itemId, 0, true);
            break;

        case EventState_SelectionDialog:
            // `Gfx_PickupItemAnimate` increases model scale and returns `false`, then starts rotating it and returns `true`.
            if (Gfx_PickupItemAnimate(itemId))
            {
                Event_DisplayMapMsg(true, mapMsgIdxCpy, 3, NO_VALUE, 0, true); // 3 is "Yes", `NO_VALUE` is "No".
            }

            // Flag pickup item as collected.
            Savegame_EventFlagSet(eventFlagIdx);
            break;

        case EventState_TakeItem:
            // "Yes" selected.
            Event_InvItemCmd(InvItemCmd_AddItem, itemId, itemCount, false);
            SysWork_StateStepIncrement(1);

        default: // `EventState_DontTakeItem`
            // Flag pickup item as uncollected. Selecting 'No' sets `field_10` to `NO_VALUE`.
            if (g_SysWork.sysStateSteps[1] == NO_VALUE)
            {
                Savegame_EventFlagClear(eventFlagIdx);
            }

            // Restore player control.
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}

void Event_CommonItemTake(u32 pickupType, e_EventFlag eventFlagIdx) // 0x800879FC
{
    #define EASY_DIFFICULTY_AMMO_COUNT_MULT_MIN 2

    s32 ammoCountMult;

    // Compute ammo count multiplier.
    ammoCountMult = g_GameWork.config.extraBulletAdjust + 1;
    if (g_SavegamePtr->gameDifficulty == GameDifficulty_Easy)
    {
        ammoCountMult = CLAMP(ammoCountMult, EASY_DIFFICULTY_AMMO_COUNT_MULT_MIN, ammoCountMult);
    }

#ifdef SH_PC_PORT
    /* Remix items: the spot's health or ammo type, as drawn (pc_remix.c). */
    {
        extern u32 Pc_Remix_CommonType(u32 pickupType, s32 flag);
        pickupType = Pc_Remix_CommonType(pickupType, eventFlagIdx);
    }
#endif

    // Handle item pickup.
    switch (pickupType)
    {
        case CommonPickupItemId_FirstAidKit:
            Event_ItemTake(InvItemId_FirstAidKit, DEFAULT_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_FirstAidSelect);
            break;

        case CommonPickupItemId_HealthDrink:
            Event_ItemTake(InvItemId_HealthDrink, DEFAULT_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_HealthDrinkSelect);
            break;

        case CommonPickupItemId_Ampoule:
            Event_ItemTake(InvItemId_Ampoule, DEFAULT_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_AmpouleSelect);
            break;

        case CommonPickupItemId_HandgunBullets:
            Event_ItemTake(InvItemId_HandgunBullets, ammoCountMult * HANDGUN_AMMO_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_HandgunAmmoSelect);
            break;

        case CommonPickupItemId_ShotgunShells:
            Event_ItemTake(InvItemId_ShotgunShells, ammoCountMult * SHOTGUN_AMMO_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_ShotgunAmmoSelect);
            break;

        case CommonPickupItemId_RifleShells:
            Event_ItemTake(InvItemId_RifleShells, ammoCountMult * RIFLE_AMMO_PICKUP_ITEM_COUNT, eventFlagIdx, MapMsgIdx_RifleAmmoSelect);
            break;
    }

    #undef EASY_DIFFICULTY_AMMO_COUNT_MULT_MIN
}

void Event_PaperMapTake(s32 paperMapFlagIdx, e_EventFlag eventFlagIdx, s32 mapMsgIdx) // 0x80087AF4
{
    static const RECT RECT = {
        SCREEN_POSITION_X(100.0f), 256,
        SCREEN_WIDTH / 2, SCREEN_HEIGHT
    };

    s32 paperMapFlagIdxCpy;

    g_DeltaTime        = Q12(0.0f);
    paperMapFlagIdxCpy = paperMapFlagIdx;

    switch (g_SysWork.sysStateSteps[1])
    {
        case 0:
            // Freeze player control.
            g_MapOverlayHdr.playerControlFreeze();

            Fs_QueueStartSeek(FILE_TIM_MP_0TOWN_TIM + g_PaperMapFileIdxs[paperMapFlagIdx]);
            SysWork_StateStepIncrement(1);

        case 1:
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, Q12(0.0f), true);
            break;

        case 2:
            DrawSync(SyncMode_Wait);
            StoreImage(&RECT, IMAGE_BUFFER);
            DrawSync(SyncMode_Wait);
            Fs_QueueStartReadTim(FILE_TIM_MP_0TOWN_TIM + g_PaperMapFileIdxs[paperMapFlagIdx], FS_BUFFER_2, &g_PaperMapImg);
            Screen_Init(SCREEN_WIDTH, true);
#ifdef SH_PC_PORT
            g_PcMapScreenActive = 1;
#endif

            g_IntervalVBlanks = 1;

            GsSwapDispBuff();
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, Q12(0.0f), false);
            Fs_QueueWaitForEmpty();

            SysWork_StateStepIncrement(1);

        case 3:
            g_Screen_BackgroundImgGamma = Q8(11.0f / 32.0f);

#ifdef SH_PC_PORT
            PaperMap_ReuploadTimToVram_PC();
#endif
            Screen_BackgroundImgDraw(&g_PaperMapImg);
            Event_DisplayMapMsg(true, mapMsgIdx, 4, 5, 0, true); // 4 is "No", 5 is "Yes".
            break;

        case 4:
            paperMapFlagIdxCpy                                         = paperMapFlagIdx >> 5;
            ((s32*)&g_SavegamePtr->paperMapFlags)[paperMapFlagIdxCpy] |= 1 << (paperMapFlagIdx & 0x1F); // TODO: Maybe union?

            // TODO: Demagic paper map flags with an enum.
            switch (paperMapFlagIdx)
            {
                case 6:
                    g_SavegamePtr->paperMapFlags |= (1 << 5) | (1 << 7) | (1 << 8) | (1 << 9) |
                                                    (1 << 10) | (1 << 11) | (1 << 12);
                    break;

                case 17:
                    g_SavegamePtr->paperMapFlags |= 1 << 18;
                    g_SavegamePtr->paperMapFlags |= 1 << 19;
                    g_SavegamePtr->paperMapFlags |= 1 << 21;
                    g_SavegamePtr->paperMapFlags |= 1 << 22;
                    g_SavegamePtr->paperMapFlags |= 1 << 23;
                    break;

                case 16:
                    g_SavegamePtr->paperMapFlags |= 1 << 20;
                    break;

                case 13:
                    g_SavegamePtr->paperMapFlags |= 1 << 14;
                    break;

                case 2:
                    g_SavegamePtr->paperMapFlags |= 1 << 3;
                    break;
            }

            Savegame_EventFlagSet(eventFlagIdx);
            SysWork_StateStepIncrement(1);

        case 5:
            g_Screen_BackgroundImgGamma = Q8(11.0f / 32.0f);

#ifdef SH_PC_PORT
            PaperMap_ReuploadTimToVram_PC();
#endif
            Screen_BackgroundImgDraw(&g_PaperMapImg);
            Event_ScreenFadeCmd(ScreenFadeCmd_Auto, true, 0, Q12(0.0f), true);
            break;

        default:
            LoadImage(&RECT, IMAGE_BUFFER);
            DrawSync(SyncMode_Wait);
            Screen_Init(SCREEN_WIDTH, false);
#ifdef SH_PC_PORT
            g_PcMapScreenActive = 0;
#endif
            Event_ScreenFadeCmd(ScreenFadeCmd_Start, false, 0, Q12(0.0f), false);

            // Restore player control.
            g_MapOverlayHdr.playerControlUnfreeze(false);
            SysWork_StateSetNext(SysState_Gameplay);
            break;
    }
}
